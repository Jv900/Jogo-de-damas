import React, { useState, useEffect, useRef, useCallback } from 'react';
import { BoardPiece, GameMode, GameSettings, HistoryEntry, MoveOption, PlayerColor, Position, PuzzleChallenge } from './types/game';
import { applyMoveToBoard, checkGameEnd, cloneBoard, createInitialBoard, formatMoveNotation, getAllValidMovesForPlayer, getBoardPositionHash, getValidMovesForSquare } from './rules/damasEngine';
import { getBestMoveForAI } from './rules/aiPlayer';
import { PUZZLE_CHALLENGES } from './rules/puzzleLibrary';
import { sound } from './utils/audio';

import { Header } from './components/Header';
import { ScoreBoard } from './components/ScoreBoard';
import { CheckersBoard } from './components/CheckersBoard';
import { Controls } from './components/Controls';
import { MoveHistory } from './components/MoveHistory';
import { RulesModal } from './components/RulesModal';
import { SettingsModal } from './components/SettingsModal';
import { GameStatusModal } from './components/GameStatusModal';
import { PuzzleSelector } from './components/PuzzleSelector';

const DEFAULT_SETTINGS: GameSettings = {
  enforceMajorityRule: true, // Lei da Maioria 100% ativa por padrão (Regra Oficial da FBD)
  showValidMoves: true,
  soundEnabled: true,
  aiDifficulty: 'medium',
  aiPlayerColor: 'black',
  boardTheme: 'classic',
  pieceStyle: 'classic_ivory_ebony',
  timerMode: 'none',
  autoFlipBoard: false,
};

export default function App() {
  const [gameMode, setGameMode] = useState<GameMode>('ai');
  const [settings, setSettings] = useState<GameSettings>(DEFAULT_SETTINGS);

  const [board, setBoard] = useState<(BoardPiece | null)[][]>(() => createInitialBoard());
  const [currentTurn, setCurrentTurn] = useState<PlayerColor>('white');
  const [selectedPos, setSelectedPos] = useState<Position | null>(null);
  
  const [multiCaptureInProgress, setMultiCaptureInProgress] = useState<boolean>(false);
  const [activePiecePos, setActivePiecePos] = useState<Position | null>(null);
  const [capturedInTurn, setCapturedInTurn] = useState<Position[]>([]);

  const [gameStatus, setGameStatus] = useState<'idle' | 'playing' | 'paused' | 'won' | 'draw'>('playing');
  const [winner, setWinner] = useState<PlayerColor | null>(null);
  const [winReason, setWinReason] = useState<string | null>(null);

  const [halfMoveClock, setHalfMoveClock] = useState<number>(0);
  const [positionHistory, setPositionHistory] = useState<string[]>([]);
  const [moveHistory, setMoveHistory] = useState<HistoryEntry[]>([]);

  // Undo Stack (stores previous state snapshots)
  const [undoStack, setUndoStack] = useState<{
    board: (BoardPiece | null)[][];
    turn: PlayerColor;
    halfMoveClock: number;
    positionHistory: string[];
    moveHistory: HistoryEntry[];
    timers: { white: number; black: number };
  }[]>([]);

  // Modals
  const [isRulesOpen, setIsRulesOpen] = useState<boolean>(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);
  const [activeChallenge, setActiveChallenge] = useState<PuzzleChallenge | null>(null);

  // Timers
  const [timers, setTimers] = useState<{ white: number; black: number }>({ white: 600, black: 600 });
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Initialize/Reset timers based on timerMode
  useEffect(() => {
    let initialSeconds = 600;
    if (settings.timerMode === 'blitz_3m') initialSeconds = 180;
    if (settings.timerMode === 'rapid_10m') initialSeconds = 600;
    if (settings.timerMode === 'classic_20m') initialSeconds = 1200;
    setTimers({ white: initialSeconds, black: initialSeconds });
  }, [settings.timerMode]);

  // Timer Tick
  useEffect(() => {
    if (gameStatus === 'playing' && settings.timerMode !== 'none') {
      timerRef.current = setInterval(() => {
        setTimers(prev => {
          const newTime = { ...prev };
          newTime[currentTurn] = Math.max(0, newTime[currentTurn] - 1);
          if (newTime[currentTurn] === 0) {
            // Time expired
            setGameStatus('won');
            const winningColor = currentTurn === 'white' ? 'black' : 'white';
            setWinner(winningColor);
            setWinReason(`Vitória por Tempo Esgotado (${currentTurn === 'white' ? 'Brancas' : 'Pretas'} esgotaram seu tempo no relógio)`);
            sound.playVictory(settings.soundEnabled);
          }
          return newTime;
        });
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [gameStatus, settings.timerMode, currentTurn, settings.soundEnabled]);

  // Restart game
  const restartGame = useCallback(() => {
    if (gameMode === 'puzzle' && activeChallenge) {
      setBoard(cloneBoard(activeChallenge.boardSetup));
      setCurrentTurn(activeChallenge.initialTurn);
    } else {
      setBoard(createInitialBoard());
      setCurrentTurn('white');
    }
    setSelectedPos(null);
    setMultiCaptureInProgress(false);
    setActivePiecePos(null);
    setCapturedInTurn([]);
    setGameStatus('playing');
    setWinner(null);
    setWinReason(null);
    setHalfMoveClock(0);
    setPositionHistory([]);
    setMoveHistory([]);
    setUndoStack([]);

    let initialSeconds = 600;
    if (settings.timerMode === 'blitz_3m') initialSeconds = 180;
    if (settings.timerMode === 'rapid_10m') initialSeconds = 600;
    if (settings.timerMode === 'classic_20m') initialSeconds = 1200;
    setTimers({ white: initialSeconds, black: initialSeconds });
  }, [gameMode, activeChallenge, settings.timerMode]);

  // Handle switching game mode
  const handleSelectMode = (mode: GameMode) => {
    setGameMode(mode);
    if (mode === 'puzzle') {
      setActiveChallenge(PUZZLE_CHALLENGES[0]);
    } else {
      setActiveChallenge(null);
    }
    setTimeout(() => {
      restartGame();
    }, 50);
  };

  // Compute all valid moves for current player
  const allAllowedMoves = React.useMemo(() => {
    return getAllValidMovesForPlayer(board, currentTurn, settings.enforceMajorityRule);
  }, [board, currentTurn, settings.enforceMajorityRule]);

  // Compute valid moves for currently selected piece
  const validMovesForSelected = React.useMemo(() => {
    if (!selectedPos) return [];
    if (multiCaptureInProgress && activePiecePos) {
      // If multi-capture in progress, only allowed moves originating from activePiecePos
      if (selectedPos.row !== activePiecePos.row || selectedPos.col !== activePiecePos.col) {
        return [];
      }
    }
    return getValidMovesForSquare(allAllowedMoves, selectedPos.row, selectedPos.col);
  }, [selectedPos, allAllowedMoves, multiCaptureInProgress, activePiecePos]);

  // Check Game End conditions whenever board or turn changes
  useEffect(() => {
    if (gameStatus !== 'playing') return;

    const endCheck = checkGameEnd(
      board,
      currentTurn,
      allAllowedMoves,
      positionHistory,
      halfMoveClock
    );

    if (endCheck.isEnd) {
      if (endCheck.winner) {
        setGameStatus('won');
        setWinner(endCheck.winner);
        setWinReason(endCheck.winReason);
        sound.playVictory(settings.soundEnabled);
      } else {
        setGameStatus('draw');
        setWinner(null);
        setWinReason(endCheck.winReason);
        sound.playVictory(settings.soundEnabled); // Play celebratory chime on draw too
      }
    }
  }, [board, currentTurn, allAllowedMoves, positionHistory, halfMoveClock, gameStatus, settings.soundEnabled]);

  // AI Turn Execution (Instant / Very Fast, without any waiting text or screens)
  useEffect(() => {
    if (
      gameStatus === 'playing' &&
      gameMode === 'ai' &&
      currentTurn === settings.aiPlayerColor &&
      !multiCaptureInProgress
    ) {
      const aiTimer = setTimeout(() => {
        const bestMove = getBestMoveForAI(board, currentTurn, settings.aiDifficulty, settings.enforceMajorityRule);
        if (bestMove) {
          executeFullMove(bestMove);
        }
      }, 50); // 50ms almost instant response

      return () => clearTimeout(aiTimer);
    }
  }, [gameStatus, gameMode, currentTurn, settings.aiPlayerColor, board, multiCaptureInProgress, settings.aiDifficulty, settings.enforceMajorityRule]);

  // Execute a move completely
  const executeFullMove = (move: MoveOption) => {
    // Save state to undo stack
    setUndoStack(prev => [
      ...prev,
      {
        board: cloneBoard(board),
        turn: currentTurn,
        halfMoveClock,
        positionHistory: [...positionHistory],
        moveHistory: [...moveHistory],
        timers: { ...timers },
      },
    ]);

    const { newBoard, movedPiece, wasPromoted } = applyMoveToBoard(board, move);

    // Audio effects
    if (wasPromoted) {
      sound.playPromote(settings.soundEnabled);
    } else if (move.isCapture) {
      sound.playCapture(settings.soundEnabled);
    } else {
      sound.playMove(settings.soundEnabled);
    }

    // Update half-move clock (reset if capture or pedra move)
    let nextHalfMoveClock = halfMoveClock + 1;
    if (move.isCapture || movedPiece.type === 'pedra') {
      nextHalfMoveClock = 0;
    }
    setHalfMoveClock(nextHalfMoveClock);

    // Update position hash history
    const nextTurn = currentTurn === 'white' ? 'black' : 'white';
    const newHash = getBoardPositionHash(newBoard, nextTurn);
    const nextPosHistory = [...positionHistory, newHash];
    setPositionHistory(nextPosHistory);

    // Add to move history
    const notation = formatMoveNotation(move);
    const historyEntry: HistoryEntry = {
      id: `${moveHistory.length + 1}-${Math.random()}`,
      turnNumber: Math.floor(moveHistory.length / 2) + 1,
      color: currentTurn,
      from: move.from,
      to: move.to,
      notation,
      capturedCount: move.captureCount,
      wasKing: movedPiece.type === 'dama' && !wasPromoted,
      promoted: wasPromoted,
      boardSnapshot: cloneBoard(newBoard),
    };
    setMoveHistory(prev => [...prev, historyEntry]);

    // Update state
    setBoard(newBoard);
    setCurrentTurn(nextTurn);
    setSelectedPos(null);
    setMultiCaptureInProgress(false);
    setActivePiecePos(null);
    setCapturedInTurn([]);
  };

  // Handle Square Click
  const handleSquareClick = (row: number, col: number) => {
    if (gameStatus !== 'playing') return;
    if (gameMode === 'ai' && currentTurn === settings.aiPlayerColor) return; // Ignore clicks during AI turn

    const clickedPiece = board[row][col];

    // Case 1: Multi-Capture sequence is actively happening
    if (multiCaptureInProgress && activePiecePos) {
      // Must only select valid move step from activePiecePos
      const matchMove = validMovesForSelected.find(m => m.to.row === row && m.to.col === col);
      if (matchMove) {
        executeFullMove(matchMove);
      } else if (row === activePiecePos.row && col === activePiecePos.col) {
        // Clicking active piece just keeps it selected
        setSelectedPos({ row, col });
      } else {
        sound.playError(settings.soundEnabled);
      }
      return;
    }

    // Case 2: Clicking on a piece of the current player
    if (clickedPiece && clickedPiece.color === currentTurn) {
      // Check if there is mandatory capture
      const hasCaptures = allAllowedMoves.some(m => m.isCapture);
      if (hasCaptures) {
        const canThisPieceCapture = allAllowedMoves.some(m => m.from.row === row && m.from.col === col && m.isCapture);
        if (!canThisPieceCapture) {
          // This piece cannot capture when mandatory captures exist elsewhere!
          sound.playError(settings.soundEnabled);
          return;
        }
      }

      setSelectedPos({ row, col });
      sound.playClick(settings.soundEnabled);
      return;
    }

    // Case 3: Clicking on an empty square when a piece is already selected
    if (selectedPos && !clickedPiece) {
      const matchMove = validMovesForSelected.find(m => m.to.row === row && m.to.col === col);
      if (matchMove) {
        executeFullMove(matchMove);
      } else {
        // Deselect or play error if invalid square
        setSelectedPos(null);
      }
      return;
    }

    // Otherwise click did nothing relevant
    setSelectedPos(null);
  };

  // Undo last move
  const handleUndo = () => {
    if (undoStack.length === 0 || gameStatus !== 'playing') return;

    let stepsToPop = 1;
    // In AI mode, if it's currently the player's turn, popping 1 goes back to AI turn, so we pop 2 to get back to player's previous choice!
    if (gameMode === 'ai' && currentTurn === (settings.aiPlayerColor === 'black' ? 'white' : 'black') && undoStack.length >= 2) {
      stepsToPop = 2;
    }

    const targetIndex = undoStack.length - stepsToPop;
    const previousState = undoStack[targetIndex];

    setBoard(cloneBoard(previousState.board));
    setCurrentTurn(previousState.turn);
    setHalfMoveClock(previousState.halfMoveClock);
    setPositionHistory(previousState.positionHistory);
    setMoveHistory(previousState.moveHistory);
    setTimers(previousState.timers);

    setUndoStack(prev => prev.slice(0, targetIndex));
    setSelectedPos(null);
    setMultiCaptureInProgress(false);
    setActivePiecePos(null);
    setCapturedInTurn([]);
  };

  // Hint button: highlight the best move for current turn
  const handleHint = () => {
    if (gameStatus !== 'playing') return;
    const hintMove = getBestMoveForAI(board, currentTurn, 'master', settings.enforceMajorityRule);
    if (hintMove) {
      setSelectedPos(hintMove.from);
      sound.playClick(settings.soundEnabled);
    }
  };

  // Offer Draw button
  const handleOfferDraw = () => {
    if (gameStatus !== 'playing') return;
    if (window.confirm('Ambos os jogadores concordam em declarar o empate nesta partida?')) {
      setGameStatus('draw');
      setWinner(null);
      setWinReason('Empate por Mútuo Acordo entre os dois jogadores');
      sound.playVictory(settings.soundEnabled);
    }
  };

  // Export PGN / Notation
  const handleExportPGN = () => {
    const lines = [
      '[Event "Damas Oficial - Federação Brasileira de Damas (FBD 64)"]',
      `[Date "${new Date().toISOString().split('T')[0]}"]`,
      `[White "${gameMode === 'ai' && settings.aiPlayerColor === 'white' ? 'Robô IA' : 'Brancas'}"]`,
      `[Black "${gameMode === 'ai' && settings.aiPlayerColor === 'black' ? 'Robô IA' : 'Pretas'}"]`,
      `[Result "${status === 'won' ? (winner === 'white' ? '1-0' : '0-1') : status === 'draw' ? '1/2-1/2' : '*'}"]`,
      '',
    ];

    let currentTurnLine = '';
    moveHistory.forEach((entry, idx) => {
      if (idx % 2 === 0) {
        currentTurnLine = `${entry.turnNumber}. ${entry.notation}`;
      } else {
        currentTurnLine += `  ${entry.notation}`;
        lines.push(currentTurnLine);
        currentTurnLine = '';
      }
    });
    if (currentTurnLine) lines.push(currentTurnLine);

    navigator.clipboard.writeText(lines.join('\n'));
    alert('Notação da partida copiada para a área de transferência com sucesso!');
  };

  // Select board snapshot from history review
  const handleSelectSnapshot = (snapshot: (BoardPiece | null)[][]) => {
    setBoard(cloneBoard(snapshot));
    // Temporarily pause game while reviewing
    if (gameStatus === 'playing') {
      setGameStatus('paused');
    }
  };

  // Update Settings
  const handleUpdateSettings = (newSettings: Partial<GameSettings>) => {
    setSettings(prev => ({ ...prev, ...newSettings }));
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between selection:bg-amber-500/30">
      {/* Header Bar */}
      <Header
        gameMode={gameMode}
        onSelectMode={handleSelectMode}
        settings={settings}
        onUpdateSettings={handleUpdateSettings}
        onOpenRules={() => setIsRulesOpen(true)}
        onOpenSettings={() => setIsSettingsOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-2 sm:p-4 md:p-6">
        {gameMode === 'puzzle' && !activeChallenge ? (
          <PuzzleSelector
            onSelectChallenge={challenge => {
              setActiveChallenge(challenge);
              setBoard(cloneBoard(challenge.boardSetup));
              setCurrentTurn(challenge.initialTurn);
              setGameStatus('playing');
            }}
            activeChallengeId={undefined}
            onExitPuzzleMode={() => handleSelectMode('ai')}
          />
        ) : (
          <div className="grid grid-cols-1 xl:grid-cols-[minmax(0,1fr)_360px] gap-6 items-start">
            
            {/* Left Column: Board + Score & Controls */}
            <div className="space-y-4 flex flex-col items-center w-full">
              
              {/* Scoreboard Panel */}
              <ScoreBoard
                board={board}
                currentTurn={currentTurn}
                gameMode={gameMode}
                settings={settings}
                onUpdateSettings={handleUpdateSettings}
                mandatoryMoves={allAllowedMoves.filter(m => m.isCapture)}
                multiCaptureInProgress={multiCaptureInProgress}
                timers={timers}
              />

              {/* Interactive Checkers Board */}
              <div className="w-full relative flex justify-center">
                <CheckersBoard
                  board={board}
                  currentTurn={currentTurn}
                  selectedPos={selectedPos}
                  validMovesForSelected={validMovesForSelected}
                  allMandatoryMoves={allAllowedMoves}
                  capturedInCurrentTurn={capturedInTurn}
                  onSquareClick={handleSquareClick}
                  boardTheme={settings.boardTheme}
                  pieceStyle={settings.pieceStyle}
                  showValidMoves={settings.showValidMoves}
                />

                {/* Paused Overlay */}
                {gameStatus === 'paused' && (
                  <div className="absolute inset-0 bg-black/80 backdrop-blur-md rounded-3xl z-30 flex flex-col items-center justify-center p-6 text-center animate-fadeIn max-w-[660px] sm:max-w-[720px] md:max-w-[780px] lg:max-w-[820px] w-full aspect-square mx-auto my-2 sm:my-4">
                    <div className="w-16 h-16 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center mb-4">
                      <span className="text-2xl">⏸️</span>
                    </div>
                    <h3 className="text-xl font-bold text-white font-serif-title mb-1">
                      Partida Pausada
                    </h3>
                    <p className="text-xs text-slate-400 mb-6 max-w-xs">
                      Sua partida está pausada. Você pode rever lances anteriores ou continuar a qualquer momento.
                    </p>
                    <button
                      onClick={() => setGameStatus('playing')}
                      className="px-6 py-3 rounded-2xl bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-bold text-xs shadow-lg shadow-amber-500/20"
                    >
                      Retomar Partida
                    </button>
                  </div>
                )}
              </div>

              {/* Controls Toolbar */}
              <Controls
                gameStatus={gameStatus}
                gameMode={gameMode}
                onRestart={restartGame}
                onPauseToggle={() => setGameStatus(prev => (prev === 'playing' ? 'paused' : 'playing'))}
                onExit={() => {
                  if (gameMode === 'puzzle') {
                    setActiveChallenge(null);
                  } else {
                    restartGame();
                  }
                }}
                onUndo={handleUndo}
                onHint={handleHint}
                onOfferDraw={handleOfferDraw}
                canUndo={undoStack.length > 0 && gameStatus === 'playing'}
              />
            </div>

            {/* Right Column: Move History & Puzzle Info */}
            <div className="space-y-4 h-full">
              {gameMode === 'puzzle' && activeChallenge && (
                <div className="p-4 rounded-2xl bg-slate-900 border border-amber-500/40 shadow-lg space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-amber-400 px-2.5 py-0.5 rounded-full bg-amber-500/10 border border-amber-500/20">
                      {activeChallenge.difficulty}
                    </span>
                    <button
                      onClick={() => setActiveChallenge(null)}
                      className="text-xs text-slate-400 hover:text-white underline"
                    >
                      Trocar Desafio
                    </button>
                  </div>
                  <h3 className="text-sm font-bold text-white">{activeChallenge.title}</h3>
                  <p className="text-xs text-slate-300 leading-relaxed">{activeChallenge.description}</p>
                  <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-amber-200 font-mono">
                    <strong>Objetivo:</strong> {activeChallenge.objective}
                  </div>
                </div>
              )}

              {/* Move History Panel */}
              <MoveHistory
                history={moveHistory}
                onSelectSnapshot={handleSelectSnapshot}
                onExportPGN={handleExportPGN}
              />
            </div>
          </div>
        )}
      </main>

      {/* Footer Info */}
      <footer className="border-t border-slate-800/80 bg-slate-950 py-4 px-4 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>Damas Oficial — Federação Brasileira de Damas (FBD 64)</span>
          <span className="flex items-center gap-2">
            <span>•</span>
            <span>Tabuleiros 8x8 nas casas escuras</span>
            <span>•</span>
            <span>Captura Obrigatória e Lei da Maioria</span>
          </span>
        </div>
      </footer>

      {/* Modals */}
      <RulesModal isOpen={isRulesOpen} onClose={() => setIsRulesOpen(false)} />
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={settings}
        onUpdateSettings={handleUpdateSettings}
      />

      {(gameStatus === 'won' || gameStatus === 'draw') && (
        <GameStatusModal
          status={gameStatus}
          winner={winner}
          winReason={winReason}
          gameMode={gameMode}
          totalMoves={moveHistory.length}
          onPlayAgain={restartGame}
          onReviewBoard={() => setGameStatus('paused')}
          onChangeMode={() => {
            setGameStatus('playing');
            setIsSettingsOpen(true);
          }}
        />
      )}
    </div>
  );
}
