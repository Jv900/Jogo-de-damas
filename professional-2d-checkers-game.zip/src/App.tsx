import { useState, useEffect, useRef } from "react";
import {
  Trophy,
  Users,
  Cpu,
  RotateCcw,
  Volume2,
  VolumeX,
  Eye,
  EyeOff,
  BookOpen,
  ArrowRight,
  Sparkles,
  Play,
  Pause,
  LogOut,
  ShieldCheck,
  AlertCircle,
} from "lucide-react";
import {
  Board,
  Player,
  Position,
  Move,
  MoveStep,
  createInitialBoard,
  getValidMoves,
  executeMoveOnBoard,
  checkGameOver,
  getPositionNotation,
} from "./utils/checkersRules";
import { getAIMove, evaluateBoard } from "./utils/checkersAI";
import { sound } from "./utils/checkersSound";
import GameBoard from "./components/GameBoard";
import RulesModal from "./components/RulesModal";

// Helper to serialize board for 3-fold repetition detection
function serializeBoardState(board: Board, player: Player): string {
  let serialized = "";
  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      const piece = board[r][c];
      if (!piece) {
        serialized += ".";
      } else {
        serialized += `${piece.player}${piece.isQueen ? "Q" : "P"}`;
      }
    }
  }
  return `${serialized}_${player}`;
}

export default function App() {
  // --- VIEWS STATE ---
  const [screen, setScreen] = useState<"menu" | "game">("menu");

  // --- GAMEPLAY STATE ---
  const [board, setBoard] = useState<Board>(createInitialBoard);
  const [turn, setTurn] = useState<Player>(1); // 1 = Brancas (starts), 2 = Pretas
  const [selectedPiece, setSelectedPiece] = useState<Position | null>(null);
  
  // Multi-step capture tracking
  const [currentSteps, setCurrentSteps] = useState<MoveStep[]>([]);
  const [ghosts, setGhosts] = useState<Set<string>>(new Set());

  // Game configuration
  const [gameMode, setGameMode] = useState<"robot" | "p2p">("robot");
  const [aiDifficulty, setAiDifficulty] = useState<"facil" | "medio" | "dificil" | "mestre">("medio");
  const [aiColor, setAiColor] = useState<Player>(2); // AI is Pretas (2) by default
  const [theme, setTheme] = useState<"wood" | "green" | "slate" | "cyber">("green"); // "green" is standard official tournament theme
  
  // Display settings
  const [showSuggestions, setShowSuggestions] = useState(true);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [paused, setPaused] = useState(false);
  const [rulesModalOpen, setRulesModalOpen] = useState(false);
  
  // Game state tracking
  const [lastMove, setLastMove] = useState<Move | null>(null);
  const [drawTurnCount, setDrawTurnCount] = useState(0); // consecutive Queen moves without capture
  const [positionHistory, setPositionHistory] = useState<string[]>([]);
  const [moveHistory, setMoveHistory] = useState<{ notation: string; player: Player }[]>([]);
  
  const [gameEnded, setGameEnded] = useState(false);
  const [winner, setWinner] = useState<Player | null>(null);
  const [endReason, setEndReason] = useState("");
  const [isAiThinking, setIsAiThinking] = useState(false);

  // Active moves allowed in this turn (recalculated when turn begins)
  const [validMoves, setValidMoves] = useState<Move[]>([]);

  // Ref to automatically scroll the move log
  const moveLogEndRef = useRef<HTMLDivElement>(null);

  // Synchronize sound manager mute setting
  useEffect(() => {
    sound.setMuted(!soundEnabled);
  }, [soundEnabled]);

  // Scroll to bottom of move history whenever it changes
  useEffect(() => {
    if (screen === "game") {
      moveLogEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }
  }, [moveHistory, screen]);

  // --- INITIALIZE / RESTART GAME ---
  const handleStartGame = (mode: "robot" | "p2p") => {
    const freshBoard = createInitialBoard();
    const firstTurn: Player = 1;
    const initialMoves = getValidMoves(freshBoard, firstTurn);
    
    setBoard(freshBoard);
    setTurn(firstTurn);
    setSelectedPiece(null);
    setCurrentSteps([]);
    setGhosts(new Set());
    setLastMove(null);
    setDrawTurnCount(0);
    setPositionHistory([serializeBoardState(freshBoard, firstTurn)]);
    setMoveHistory([]);
    setGameEnded(false);
    setWinner(null);
    setEndReason("");
    setIsAiThinking(false);
    setPaused(false);
    setValidMoves(initialMoves);
    setGameMode(mode);
    setScreen("game");
  };

  // Quick reset in-game
  const handleRestart = () => {
    handleStartGame(gameMode);
  };

  // Exit game to return to Menu
  const handleExitGame = () => {
    const confirm = window.confirm("Deseja realmente sair da partida? Seu progresso atual será perdido.");
    if (confirm) {
      setScreen("menu");
    }
  };

  // --- AI MOVE TRIGGER ---
  useEffect(() => {
    if (
      screen === "game" &&
      gameMode === "robot" &&
      turn === aiColor &&
      !gameEnded &&
      !paused &&
      !isAiThinking &&
      currentSteps.length === 0
    ) {
      setIsAiThinking(true);

      // Instantly calculate and execute the move (e.g., 80ms delay for ultra fast response)
      const delay = 80;

      const timer = setTimeout(() => {
        const move = getAIMove(board, turn, aiDifficulty);
        if (move) {
          executeAIMove(move);
        } else {
          // If no move, AI is blocked and loses
          const otherPlayer: Player = turn === 1 ? 2 : 1;
          setWinner(otherPlayer);
          setGameEnded(true);
          setEndReason(`Robô (${turn === 2 ? "Pretas" : "Brancas"}) não possui movimentos válidos e foi bloqueado!`);
          sound.playWin();
          setIsAiThinking(false);
        }
      }, delay);

      return () => clearTimeout(timer);
    }
  }, [board, turn, gameMode, aiColor, aiDifficulty, gameEnded, paused, screen, currentSteps]);

  // Execute the pre-calculated move by the AI
  const executeAIMove = (move: Move) => {
    const { newBoard, promoted } = executeMoveOnBoard(board, move);
    
    // Play sound based on move action
    if (move.isCapture) {
      sound.playCapture();
    } else if (promoted) {
      sound.playPromote();
    } else {
      sound.playMove();
    }

    // Format move notation
    const notation = formatMoveNotation(move);
    setMoveHistory((prev) => [...prev, { notation, player: turn }]);

    // Update draw counters (reset on any pawn move or capture)
    const isPawnMove = !board[move.start.row][move.start.col]?.isQueen;
    const shouldResetDrawCount = move.isCapture || isPawnMove;
    const nextDrawCount = shouldResetDrawCount ? 0 : drawTurnCount + 1;
    setDrawTurnCount(nextDrawCount);

    // Switch Turn
    const nextPlayer: Player = turn === 1 ? 2 : 1;
    setLastMove(move);
    setBoard(newBoard);
    setSelectedPiece(null);

    // Repetition check
    const serialized = serializeBoardState(newBoard, nextPlayer);
    const updatedPosHistory = [...positionHistory, serialized];
    setPositionHistory(updatedPosHistory);

    const occurrences = updatedPosHistory.filter((x) => x === serialized).length;

    // Check game over
    const status = checkGameOver(newBoard, nextPlayer, nextDrawCount);
    
    if (occurrences >= 3) {
      setWinner(null);
      setGameEnded(true);
      setEndReason("Empate técnico! A mesma posição se repetiu 3 vezes no tabuleiro.");
      sound.playLoss();
    } else if (status.winner !== null || status.isDraw) {
      setWinner(status.winner);
      setGameEnded(true);
      setEndReason(status.reason);
      if (status.isDraw) {
        sound.playLoss();
      } else {
        // If human won, celebrate!
        if (gameMode === "robot") {
          if (status.winner === aiColor) {
            sound.playLoss();
          } else {
            sound.playWin();
          }
        } else {
          sound.playWin();
        }
      }
    } else {
      // Game continues, calculate valid moves for next player
      setTurn(nextPlayer);
      setValidMoves(getValidMoves(newBoard, nextPlayer));
    }

    setIsAiThinking(false);
  };

  // Helper to format algebraic notation for historical logging
  const formatMoveNotation = (move: Move): string => {
    const startSq = getPositionNotation(move.start.row, move.start.col);
    const endSq = getPositionNotation(move.end.row, move.end.col);
    return move.isCapture ? `${startSq}x${endSq}` : `${startSq}-${endSq}`;
  };

  // --- HUMAN MOVE HANDLER ---
  const handleCellClick = (row: number, col: number) => {
    if (paused || gameEnded || isAiThinking) return;
    
    // Block input if it is the Robot's turn
    if (gameMode === "robot" && turn === aiColor) return;

    const piece = board[row][col];
    const isFriendly = piece && piece.player === turn;

    // If no piece is currently selected, select one
    if (selectedPiece === null) {
      if (isFriendly) {
        // Verify if this piece is allowed to move according to "Lei da Maioria"
        const hasAvailableMoves = validMoves.some(
          (m) => m.start.row === row && m.start.col === col
        );

        if (hasAvailableMoves) {
          setSelectedPiece({ row, col });
        } else {
          const hasCaptures = validMoves.some((m) => m.isCapture);
          if (hasCaptures) {
            alert(
              "⚠️ CAPTURA OBRIGATÓRIA!\n\nPela Lei da Maioria das regras oficiais, você é obrigado a capturar o maior número de peças possíveis nesta rodada. Selecione uma peça participante da captura máxima (destacadas ou piscando)."
            );
          } else {
            alert("Esta peça não possui nenhum movimento legal disponível!");
          }
        }
      }
    } else {
      // Piece IS selected
      const isStartSame = selectedPiece.row === row && selectedPiece.col === col;

      // Allow switching piece ONLY if we haven't started a multiple capture chain yet
      if (isFriendly && currentSteps.length === 0) {
        if (isStartSame) {
          setSelectedPiece(null);
        } else {
          const hasAvailableMoves = validMoves.some(
            (m) => m.start.row === row && m.start.col === col
          );
          if (hasAvailableMoves) {
            setSelectedPiece({ row, col });
          } else {
            alert("Esta peça não possui movimentos válidos sob as regras vigentes.");
          }
        }
        return;
      }

      // Handle clicking a square to make a movement
      // Verify if the clicked cell is a valid destination
      const validDests = getValidDestinationsForSelected();
      const isDestinationValid = validDests.some((d) => d.row === row && d.col === col);

      if (isDestinationValid) {
        executeHumanStep(row, col);
      } else {
        // If click is invalid and we are not in a chain, deselect
        if (currentSteps.length === 0 && !isFriendly) {
          setSelectedPiece(null);
        }
      }
    }
  };

  // Get valid destinations for the currently selected piece
  const getValidDestinationsForSelected = (): Position[] => {
    if (!selectedPiece) return [];

    const destinations: Position[] = [];

    if (currentSteps.length === 0) {
      // Find normal moves or first-step captures starting from selectedPiece
      const pieceMoves = validMoves.filter(
        (m) => m.start.row === selectedPiece.row && m.start.col === selectedPiece.col
      );

      for (const move of pieceMoves) {
        if (move.isCapture && move.steps.length > 0) {
          destinations.push(move.steps[0].to);
        } else {
          destinations.push(move.end);
        }
      }
    } else {
      // Mid-chain capture: Filter allowed moves matching the prefix steps made so far
      const matchingMoves = validMoves.filter((move) => {
        if (move.steps.length <= currentSteps.length) return false;
        for (let i = 0; i < currentSteps.length; i++) {
          const s1 = move.steps[i];
          const s2 = currentSteps[i];
          if (
            s1.from.row !== s2.from.row ||
            s1.from.col !== s2.from.col ||
            s1.to.row !== s2.to.row ||
            s1.to.col !== s2.to.col
          ) {
            return false;
          }
        }
        return true;
      });

      for (const move of matchingMoves) {
        const nextStep = move.steps[currentSteps.length];
        destinations.push(nextStep.to);
      }
    }

    return destinations;
  };

  // Perform a single step of movement/jump
  const executeHumanStep = (destRow: number, destCol: number) => {
    if (!selectedPiece) return;

    // Find the step definition
    let step: MoveStep | null = null;
    let fullMoveObj: Move | null = null;

    if (currentSteps.length === 0) {
      // First step
      fullMoveObj = validMoves.find((m) => {
        if (m.start.row !== selectedPiece.row || m.start.col !== selectedPiece.col) return false;
        if (m.isCapture) {
          return m.steps[0].to.row === destRow && m.steps[0].to.col === destCol;
        } else {
          return m.end.row === destRow && m.end.col === destCol;
        }
      }) || null;

      if (fullMoveObj) {
        step = fullMoveObj.isCapture ? fullMoveObj.steps[0] : { from: selectedPiece, to: { row: destRow, col: destCol } };
      }
    } else {
      // In multiple capture
      // Find moves matching our chain that land on this cell as the next step
      fullMoveObj = validMoves.find((move) => {
        if (move.steps.length <= currentSteps.length) return false;
        
        // Match history
        for (let i = 0; i < currentSteps.length; i++) {
          const s1 = move.steps[i];
          const s2 = currentSteps[i];
          if (
            s1.from.row !== s2.from.row ||
            s1.from.col !== s2.from.col ||
            s1.to.row !== s2.to.row ||
            s1.to.col !== s2.to.col
          ) {
            return false;
          }
        }

        // Match next step target
        const nextStep = move.steps[currentSteps.length];
        return nextStep.to.row === destRow && nextStep.to.col === destCol;
      }) || null;

      if (fullMoveObj) {
        step = fullMoveObj.steps[currentSteps.length];
      }
    }

    if (!step || !fullMoveObj) return;

    // Perform partial step on active board
    const nextBoard = board.map((r) => r.map((c) => (c ? { ...c } : null)));
    const activePiece = nextBoard[selectedPiece.row][selectedPiece.col];
    
    if (!activePiece) return;

    // Clear starting cell of this step
    nextBoard[selectedPiece.row][selectedPiece.col] = null;
    
    // Place piece in new cell
    nextBoard[destRow][destCol] = activePiece;

    // Mark captured piece as a "ghost"
    const nextGhosts = new Set(ghosts);
    if (step.captured) {
      nextGhosts.add(`${step.captured.row},${step.captured.col}`);
      sound.playCapture();
    } else {
      sound.playMove();
    }

    const nextStepsHistory = [...currentSteps, step];

    // Determine if we have reached the end of the full move
    // We check if the matching moves still have further jumps
    const matchingMovesRemaining = validMoves.filter((move) => {
      if (move.steps.length < nextStepsHistory.length) return false;
      
      // Check prefix matching
      for (let i = 0; i < nextStepsHistory.length; i++) {
        const s1 = move.steps[i];
        const s2 = nextStepsHistory[i];
        if (
          s1.from.row !== s2.from.row ||
          s1.from.col !== s2.from.col ||
          s1.to.row !== s2.to.row ||
          s1.to.col !== s2.to.col
        ) {
          return false;
        }
      }
      return true;
    });

    const hasFurtherSteps = matchingMovesRemaining.some(
      (m) => m.steps.length > nextStepsHistory.length
    );

    if (hasFurtherSteps) {
      // Continue capturing chain! Keep piece selected, update board/ghosts
      setBoard(nextBoard);
      setGhosts(nextGhosts);
      setCurrentSteps(nextStepsHistory);
      setSelectedPiece({ row: destRow, col: destCol });
    } else {
      // Move is completed! Clear all ghosts from the board permanently
      const finalBoard = nextBoard.map((r) => r.map((c) => (c ? { ...c } : null)));
      for (const ghostKey of Array.from(nextGhosts)) {
        const [r, c] = ghostKey.split(",").map(Number);
        finalBoard[r][c] = null;
      }

      // Check for promotion to Dama (Queen)
      // Piece becomes a Queen if it ends its turn on the promotion row
      const pieceAfterMove = finalBoard[destRow][destCol];
      if (pieceAfterMove && !pieceAfterMove.isQueen) {
        const promoRow = pieceAfterMove.player === 1 ? 0 : 7;
        if (destRow === promoRow) {
          pieceAfterMove.isQueen = true;
          sound.playPromote();
        }
      }

      // Format move notation
      const finalMoveObj: Move = {
        start: fullMoveObj.start,
        end: { row: destRow, col: destCol },
        steps: nextStepsHistory,
        isCapture: fullMoveObj.isCapture,
        capturedCount: nextGhosts.size,
      };

      const notation = formatMoveNotation(finalMoveObj);
      setMoveHistory((prev) => [...prev, { notation, player: turn }]);

      // Update draw counter (reset on captures or normal pawn move)
      const isPawnMove = !board[fullMoveObj.start.row][fullMoveObj.start.col]?.isQueen;
      const shouldResetDrawCount = fullMoveObj.isCapture || isPawnMove;
      const nextDrawCount = shouldResetDrawCount ? 0 : drawTurnCount + 1;
      setDrawTurnCount(nextDrawCount);

      // Transition turn
      const nextPlayer: Player = turn === 1 ? 2 : 1;
      setLastMove(finalMoveObj);
      setBoard(finalBoard);
      setSelectedPiece(null);
      setGhosts(new Set());
      setCurrentSteps([]);

      // Repetition check
      const serialized = serializeBoardState(finalBoard, nextPlayer);
      const updatedPosHistory = [...positionHistory, serialized];
      setPositionHistory(updatedPosHistory);

      const occurrences = updatedPosHistory.filter((x) => x === serialized).length;

      // Check game over
      const status = checkGameOver(finalBoard, nextPlayer, nextDrawCount);

      if (occurrences >= 3) {
        setWinner(null);
        setGameEnded(true);
        setEndReason("Empate técnico! A mesma posição se repetiu 3 vezes no tabuleiro.");
        sound.playLoss();
      } else if (status.winner !== null || status.isDraw) {
        setWinner(status.winner);
        setGameEnded(true);
        setEndReason(status.reason);
        if (status.isDraw) {
          sound.playLoss();
        } else {
          sound.playWin();
        }
      } else {
        // Game continues
        setTurn(nextPlayer);
        setValidMoves(getValidMoves(finalBoard, nextPlayer));
      }
    }
  };

  // --- PROPOSE DRAW / ABANDON ---
  const handleOfferDraw = () => {
    if (gameEnded) return;

    if (gameMode === "robot") {
      // AI evaluates if it should accept draw. 
      // If AI is significantly winning, it declines. If fairly even, it accepts.
      const score = evaluateBoard(board, aiColor);
      const isDrawAccepted = Math.abs(score) < 180; // Accept if fairly balanced

      if (isDrawAccepted) {
        setWinner(null);
        setGameEnded(true);
        setEndReason("Empate acordado! O Robô analisou a posição e aceitou a proposta de empate.");
        sound.playLoss();
      } else {
        alert("🤖 Robô recusou o empate! O Robô acredita que tem vantagem tática no tabuleiro.");
      }
    } else {
      // Local 2P mode - prompt player 2
      const accept = window.confirm(
        `Jogador ${turn === 1 ? "2 (Pretas)" : "1 (Brancas)"}, o seu oponente está propondo um empate. Você aceita?`
      );
      if (accept) {
        setWinner(null);
        setGameEnded(true);
        setEndReason("Empate aceito por acordo mútuo entre os jogadores.");
        sound.playLoss();
      }
    }
  };

  const handleResign = () => {
    if (gameEnded) return;

    const playerResigning = turn === 1 ? "Brancas (Jogador 1)" : "Pretas (Jogador 2)";
    const confirm = window.confirm(`Deseja realmente abandonar a partida? A vitória será concedida ao adversário.`);
    
    if (confirm) {
      const victoriousPlayer: Player = turn === 1 ? 2 : 1;
      setWinner(victoriousPlayer);
      setGameEnded(true);
      setEndReason(`Abandono! O jogador das ${playerResigning} abandonou a partida.`);
      if (gameMode === "robot" && victoriousPlayer === aiColor) {
        sound.playLoss();
      } else {
        sound.playWin();
      }
    }
  };

  // --- STATS COUNTERS ---
  const getPieceCounts = () => {
    let p1Normal = 0;
    let p1Queens = 0;
    let p2Normal = 0;
    let p2Queens = 0;

    for (let r = 0; r < 8; r++) {
      for (let c = 0; c < 8; c++) {
        const piece = board[r][c];
        if (piece) {
          if (piece.player === 1) {
            if (piece.isQueen) p1Queens++;
            else p1Normal++;
          } else {
            if (piece.isQueen) p2Queens++;
            else p2Normal++;
          }
        }
      }
    }

    return {
      p1: { normal: p1Normal, queens: p1Queens, total: p1Normal + p1Queens },
      p2: { normal: p2Normal, queens: p2Queens, total: p2Normal + p2Queens },
    };
  };

  const counts = getPieceCounts();

  // Determine if there are any mandatory captures active on the board
  const mustCapture = validMoves.some((m) => m.isCapture);
  
  // Calculate max captured count available under the Law of Majority
  const maxCaptureCount = mustCapture ? validMoves[0].capturedCount : 0;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans transition-all duration-300 selection:bg-amber-500/30 selection:text-amber-200">
      
      {/* 1. GORGEOUS EXCLUSIVE MAIN MENU VIEW */}
      {screen === "menu" ? (
        <div className="flex-1 flex flex-col justify-center items-center px-4 py-12 md:py-16 relative overflow-hidden">
          
          {/* Subtle cosmic background layers */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-amber-500/5 rounded-full blur-[100px] pointer-events-none" />
          <div className="absolute top-1/4 left-1/3 w-[300px] h-[300px] bg-purple-500/5 rounded-full blur-[80px] pointer-events-none" />

          <div className="w-full max-w-2xl bg-slate-900/60 border border-slate-800/80 rounded-3xl p-6 md:p-10 shadow-2xl backdrop-blur-md space-y-8 relative z-10 animate-fade-in">
            
            {/* Header / Brand Title */}
            <div className="text-center space-y-3">
              <div className="inline-flex items-center justify-center p-3 rounded-2xl bg-gradient-to-tr from-amber-600 to-amber-400 text-slate-950 shadow-xl shadow-amber-500/10 mb-2 scale-110">
                <Trophy className="w-8 h-8 font-black animate-pulse" />
              </div>
              
              <div className="space-y-1">
                <h1 className="text-3xl md:text-4xl font-black text-white tracking-tight uppercase">
                  Damas <span className="text-amber-400">Oficial</span>
                </h1>
                <p className="text-xs text-amber-500/90 font-bold uppercase tracking-widest flex items-center justify-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-amber-400" /> Regras Oficiais da Federação Brasileira (FBD)
                </p>
              </div>

              <p className="text-slate-400 text-sm max-w-md mx-auto">
                Desafie a nossa Inteligência Artificial Mestre ou jogue localmente contra um amigo. Sistema homologado com Lei da Maioria e captura em cadeia.
              </p>
            </div>

            {/* Quick Rules highlights row */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <div className="p-3 bg-slate-950/45 border border-slate-850 rounded-xl flex gap-2.5 items-center">
                <ShieldCheck className="w-5 h-5 text-amber-500 shrink-0" />
                <div className="text-left text-xs">
                  <p className="font-bold text-slate-200">Captura Obrigatória</p>
                  <p className="text-slate-400 text-[11px] mt-0.5">Sempre ativada de forma estrita.</p>
                </div>
              </div>
              <div className="p-3 bg-slate-950/45 border border-slate-850 rounded-xl flex gap-2.5 items-center">
                <ShieldCheck className="w-5 h-5 text-amber-500 shrink-0" />
                <div className="text-left text-xs">
                  <p className="font-bold text-slate-200">Lei da Maioria</p>
                  <p className="text-slate-400 text-[11px] mt-0.5">Obrigatório capturar maior número.</p>
                </div>
              </div>
              <div className="p-3 bg-slate-950/45 border border-slate-850 rounded-xl flex gap-2.5 items-center">
                <ShieldCheck className="w-5 h-5 text-amber-500 shrink-0" />
                <div className="text-left text-xs">
                  <p className="font-bold text-slate-200">Voo da Dama</p>
                  <p className="text-slate-400 text-[11px] mt-0.5">A Dama move e captura à distância.</p>
                </div>
              </div>
            </div>

            {/* Config Panels */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2 border-t border-slate-850">
              
              {/* Game Mode Configuration */}
              <div className="space-y-4">
                <p className="text-xs font-black text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                  <Users className="w-4 h-4 text-amber-500" />
                  Selecione o Modo de Jogo
                </p>

                <div className="space-y-2.5">
                  <button
                    onClick={() => setGameMode("robot")}
                    className={`w-full p-4 text-left border rounded-2xl flex items-center justify-between transition-all active:scale-[0.98] ${
                      gameMode === "robot"
                        ? "bg-amber-500/10 border-amber-500 text-white shadow-lg shadow-amber-500/5"
                        : "bg-slate-950/50 border-slate-850 text-slate-400 hover:text-slate-200"
                    }`}
                  >
                    <div>
                      <p className="font-bold text-sm">Contra o Robô (IA)</p>
                      <p className="text-[11px] text-slate-400 mt-0.5">Pratique contra 4 níveis de inteligência.</p>
                    </div>
                    <Cpu className={`w-6 h-6 ${gameMode === "robot" ? "text-amber-400" : "text-slate-500"}`} />
                  </button>

                  <button
                    onClick={() => setGameMode("p2p")}
                    className={`w-full p-4 text-left border rounded-2xl flex items-center justify-between transition-all active:scale-[0.98] ${
                      gameMode === "p2p"
                        ? "bg-amber-500/10 border-amber-500 text-white shadow-lg shadow-amber-500/5"
                        : "bg-slate-950/50 border-slate-850 text-slate-400 hover:text-slate-200"
                    }`}
                  >
                    <div>
                      <p className="font-bold text-sm">2 Jogadores (Local)</p>
                      <p className="text-[11px] text-slate-400 mt-0.5">Jogue no mesmo dispositivo sem rotação de tela.</p>
                    </div>
                    <Users className={`w-6 h-6 ${gameMode === "p2p" ? "text-amber-400" : "text-slate-500"}`} />
                  </button>
                </div>
              </div>

              {/* Specific Mode Details */}
              <div className="space-y-4">
                {gameMode === "robot" ? (
                  <div className="space-y-3.5 animate-fade-in">
                    <p className="text-xs font-black text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                      <Cpu className="w-4 h-4 text-amber-500" />
                      Dificuldade do Robô
                    </p>

                    <div className="grid grid-cols-2 gap-2">
                      {[
                        { id: "facil", label: "Fácil", desc: "Erra defesas simples", color: "hover:border-emerald-500/30 text-emerald-400 border-emerald-500/10", active: "bg-emerald-500/10 border-emerald-500 text-emerald-400" },
                        { id: "medio", label: "Médio", desc: "Jogadas sólidas básicas", color: "hover:border-sky-500/30 text-sky-400 border-sky-500/10", active: "bg-sky-500/10 border-sky-500 text-sky-400" },
                        { id: "dificil", label: "Difícil", desc: "Cálculo tático médio", color: "hover:border-purple-500/30 text-purple-400 border-purple-500/10", active: "bg-purple-500/10 border-purple-500 text-purple-400" },
                        { id: "mestre", label: "Mestre", desc: "Aberturas e sacrifícios", color: "hover:border-amber-500/30 text-amber-400 border-amber-500/10", active: "bg-amber-500/15 border-amber-500 text-amber-400 font-bold" },
                      ].map((lvl) => {
                        const isLvlActive = aiDifficulty === lvl.id;
                        return (
                          <button
                            key={`menu-difficulty-${lvl.id}`}
                            onClick={() => setAiDifficulty(lvl.id as any)}
                            className={`p-3 text-left border rounded-xl transition-all active:scale-95 flex flex-col justify-between ${
                              isLvlActive ? lvl.active : `bg-slate-950/50 text-slate-300 ${lvl.color}`
                            }`}
                          >
                            <span className="font-bold text-xs">{lvl.label}</span>
                            <span className="text-[9px] text-slate-400 mt-1">{lvl.desc}</span>
                          </button>
                        );
                      })}
                    </div>

                    {/* Choose Starting side */}
                    <div className="space-y-2 pt-1">
                      <span className="text-[10px] font-black text-slate-400 uppercase tracking-wider block">
                        Cor das Suas Peças
                      </span>
                      <div className="flex gap-2">
                        <button
                          onClick={() => setAiColor(2)}
                          className={`flex-1 py-2 text-xs font-bold rounded-xl border transition-all active:scale-95 ${
                            aiColor === 2
                              ? "bg-slate-50 border-white text-slate-950 shadow"
                              : "bg-slate-950/50 border-slate-850 text-slate-400 hover:text-white"
                          }`}
                        >
                          Brancas (Começa jogando)
                        </button>
                        <button
                          onClick={() => setAiColor(1)}
                          className={`flex-1 py-2 text-xs font-bold rounded-xl border transition-all active:scale-95 ${
                            aiColor === 1
                              ? "bg-zinc-850 border-zinc-700 text-slate-100 shadow"
                              : "bg-slate-950/50 border-slate-850 text-slate-400 hover:text-white"
                          }`}
                        >
                          Pretas (Robô começa)
                        </button>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="p-4 bg-slate-950/60 border border-slate-850 rounded-2xl space-y-3.5 animate-fade-in text-left">
                    <p className="text-xs font-bold text-amber-500 uppercase tracking-wider flex items-center gap-1.5">
                      <Users className="w-4 h-4" /> Modo de Dois Jogadores Local
                    </p>
                    <ul className="text-xs text-slate-300 space-y-2 list-disc pl-4 leading-relaxed">
                      <li>As peças <strong className="text-white">Brancas</strong> começam a partida.</li>
                      <li><strong className="text-amber-400">Sem rotação de tela:</strong> As brancas permanecem sempre na parte de baixo, e as pretas na parte de cima, garantindo excelente foco visual e sem movimentos incômodos.</li>
                      <li>Apenas passe o dispositivo ou reveze os cliques na tela.</li>
                    </ul>
                  </div>
                )}
              </div>
            </div>

            {/* Launch Game Action Button */}
            <div className="pt-4 border-t border-slate-850 flex flex-col md:flex-row gap-3">
              <button
                onClick={() => handleStartGame(gameMode)}
                className="flex-1 py-4 px-6 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-slate-950 font-black tracking-wider rounded-2xl transition-all shadow-xl shadow-amber-500/10 hover:shadow-amber-500/25 active:scale-[0.98] text-sm md:text-base uppercase flex items-center justify-center gap-2"
              >
                <Play className="w-5 h-5 fill-slate-950" />
                <span>Começar Arena de Damas</span>
              </button>

              <button
                onClick={() => setRulesModalOpen(true)}
                className="py-4 px-6 bg-slate-950 border border-slate-850 hover:border-slate-700 hover:bg-slate-900 text-slate-200 font-bold rounded-2xl transition-all active:scale-[0.98] text-sm flex items-center justify-center gap-2"
              >
                <BookOpen className="w-4 h-4 text-amber-500" />
                <span>Ler Regulamento Oficial</span>
              </button>
            </div>
          </div>

          <div className="mt-8 text-center text-xs text-slate-600 space-y-1">
            <p>© 2026 Damas Oficial. Homologado conforme as regras do Jogo de Damas de 64 casas (Regra Brasileira).</p>
          </div>
        </div>
      ) : (
        
        // 2. FULL GAME ARENA VIEW
        <>
          {/* HEADER BAR */}
          <header className="bg-slate-900 border-b border-slate-800 shadow-md sticky top-0 z-40">
            <div className="max-w-7xl mx-auto px-4 py-3.5 flex flex-wrap justify-between items-center gap-4">
              <div className="flex items-center gap-3">
                <div className="relative flex items-center justify-center h-10 w-10 rounded-xl bg-gradient-to-tr from-amber-600 to-amber-400 text-slate-950 shadow-lg shadow-amber-500/10">
                  <Trophy className="w-5 h-5 font-black" />
                  <span className="absolute -top-1.5 -right-1.5 flex h-4 w-4 items-center justify-center rounded-full bg-rose-500 text-[9px] font-black text-white border border-slate-900 animate-pulse">
                    BR
                  </span>
                </div>
                <div>
                  <h1 className="text-lg md:text-xl font-black text-white tracking-wide uppercase flex items-center gap-2">
                    Damas <span className="text-amber-400">Oficial</span>
                  </h1>
                  <p className="text-[10px] text-amber-500/80 font-bold uppercase tracking-widest flex items-center gap-1">
                    <Sparkles className="w-3 h-3" /> Regras Oficiais Federação Brasileira (FBD)
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2.5">
                {/* Quick action utility toggles */}
                <button
                  onClick={() => setShowSuggestions(!showSuggestions)}
                  title={showSuggestions ? "Ocultar sugestões de jogadas" : "Exibir sugestões de jogadas"}
                  className={`p-2 rounded-xl border transition-all active:scale-95 ${
                    showSuggestions
                      ? "bg-slate-800 border-slate-700 text-amber-400 shadow-inner"
                      : "bg-transparent border-slate-800 text-slate-400 hover:text-slate-200"
                  }`}
                >
                  {showSuggestions ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                </button>

                <button
                  onClick={() => setSoundEnabled(!soundEnabled)}
                  title={soundEnabled ? "Mutar efeitos sonoros" : "Ativar efeitos sonoros"}
                  className={`p-2 rounded-xl border transition-all active:scale-95 ${
                    soundEnabled
                      ? "bg-slate-800 border-slate-700 text-amber-400"
                      : "bg-transparent border-slate-800 text-slate-400 hover:text-slate-200"
                  }`}
                >
                  {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
                </button>

                <button
                  onClick={() => setRulesModalOpen(true)}
                  className="px-3 py-2 text-xs font-bold bg-slate-800 hover:bg-slate-700 active:scale-95 text-slate-200 rounded-xl transition-all border border-slate-700/50 flex items-center gap-1.5"
                >
                  <BookOpen className="w-4 h-4 text-amber-500" />
                  <span className="hidden md:inline">Regras</span>
                </button>

                <button
                  onClick={handleExitGame}
                  className="px-3.5 py-2 text-xs font-bold bg-rose-900/10 hover:bg-rose-900/20 border border-rose-550/25 active:scale-95 text-rose-400 rounded-xl transition-all flex items-center gap-1.5 shadow"
                >
                  <LogOut className="w-4 h-4" />
                  <span>Sair</span>
                </button>
              </div>
            </div>
          </header>

          {/* MAIN GAMEPLAY COLUMNS */}
          <main className="flex-1 max-w-7xl w-full mx-auto p-4 lg:p-6 grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            
            {/* LEFT COLUMN: STATS AND ACTIVE STATE (3 Cols on Large) */}
            <div className="lg:col-span-3 space-y-5">
              
              {/* STATUS INDICATOR (WHICH PLAYER'S TURN) */}
              <div className="bg-slate-900 rounded-2xl border border-slate-800/80 p-5 shadow-lg relative overflow-hidden">
                <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-bl from-amber-500/10 to-transparent rounded-full pointer-events-none" />
                
                <p className="text-xs font-semibold text-slate-400 uppercase tracking-widest mb-3">Vez de Jogar</p>
                
                {gameEnded ? (
                  <div className="p-3 bg-rose-500/10 border border-rose-500/20 rounded-xl">
                    <p className="text-sm font-black text-rose-400 uppercase tracking-wider mb-1">Partida Encerrada</p>
                    <p className="text-xs text-slate-300 font-semibold">{endReason}</p>
                  </div>
                ) : paused ? (
                  <div className="p-3 bg-amber-500/10 border border-amber-500/20 rounded-xl flex items-center gap-2">
                    <Pause className="w-4 h-4 text-amber-500 animate-pulse" />
                    <span className="text-xs font-bold text-amber-400 uppercase tracking-wider">Jogo Pausado</span>
                  </div>
                ) : (
                  <div className="flex items-center gap-4">
                    <div className={`h-11 w-11 rounded-full border-3 flex items-center justify-center transition-transform duration-300 animate-pulse ${
                      turn === 1 
                        ? "bg-slate-50 border-white text-slate-900 shadow-[0_0_12px_rgba(255,255,255,0.4)]" 
                        : "bg-zinc-850 border-zinc-950 text-slate-200 shadow-[0_0_12px_rgba(0,0,0,0.8)]"
                    }`}>
                      <span className="text-xs font-black">{turn === 1 ? "B" : "P"}</span>
                    </div>
                    <div>
                      <div className="text-sm font-black tracking-wide">
                        {turn === 1 ? "Jogador 1 (Brancas)" : gameMode === "robot" ? "Robô (Pretas)" : "Jogador 2 (Pretas)"}
                      </div>
                      <p className="text-xs text-amber-500 font-bold uppercase tracking-wider flex items-center gap-1 mt-0.5 animate-pulse">
                        <span>•</span> {turn === 1 ? "Sua vez de jogar" : "Turno das Pretas"}
                      </p>
                    </div>
                  </div>
                )}
              </div>

              {/* SCOREBOARD AND STATS */}
              <div className="bg-slate-900 rounded-2xl border border-slate-800/80 p-5 shadow-lg">
                <p className="text-xs font-semibold text-slate-400 uppercase tracking-widest mb-4">Placar de Peças</p>
                
                <div className="grid grid-cols-2 gap-4">
                  {/* White Score (Always Bottom) */}
                  <div className="p-3 bg-slate-950 rounded-xl border border-slate-850 flex flex-col items-center relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-8 h-1 bg-sky-400/50" />
                    <div className="w-7 h-7 rounded-full bg-slate-50 shadow-piece-white border border-black/15 mb-2" />
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Brancas (Abaixo)</span>
                    <span className="text-2xl font-black text-white mt-1">{counts.p1.total}</span>
                    <span className="text-[10px] text-amber-400 font-semibold mt-0.5">{counts.p1.queens} {counts.p1.queens === 1 ? "Dama" : "Damas"}</span>
                  </div>

                  {/* Black Score (Always Top) */}
                  <div className="p-3 bg-slate-950 rounded-xl border border-slate-850 flex flex-col items-center relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-8 h-1 bg-purple-500/50" />
                    <div className="w-7 h-7 rounded-full bg-zinc-800 shadow-piece-black border border-black/15 mb-2" />
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Pretas (Acima)</span>
                    <span className="text-2xl font-black text-white mt-1">{counts.p2.total}</span>
                    <span className="text-[10px] text-amber-400 font-semibold mt-0.5">{counts.p2.queens} {counts.p2.queens === 1 ? "Dama" : "Damas"}</span>
                  </div>
                </div>

                {/* Captured counts details */}
                <div className="mt-4 pt-3.5 border-t border-slate-800 text-center text-xs">
                  <p className="text-slate-400 font-semibold">
                    Eliminadas: <span className="text-rose-400">{(12 - counts.p2.total)} Pretas</span>
                    <span className="text-slate-500 mx-2">|</span>
                    <span className="text-sky-300">{(12 - counts.p1.total)} Brancas</span>
                  </p>
                </div>
              </div>

              {/* GAME HISTORY LOGS */}
              <div className="bg-slate-900 rounded-2xl border border-slate-800/80 p-5 shadow-lg flex flex-col h-[210px]">
                <p className="text-xs font-semibold text-slate-400 uppercase tracking-widest mb-3">Histórico de Movimentos</p>
                
                <div className="flex-1 bg-slate-950/70 border border-slate-850 rounded-xl p-3 overflow-y-auto scrollbar-thin text-xs font-mono space-y-1">
                  {moveHistory.length === 0 ? (
                    <p className="text-slate-500 italic text-center py-6">Nenhum movimento efetuado.</p>
                  ) : (
                    <div className="space-y-1">
                      {Array(Math.ceil(moveHistory.length / 2))
                        .fill(null)
                        .map((_, idx) => {
                          const whiteMove = moveHistory[idx * 2];
                          const blackMove = moveHistory[idx * 2 + 1];
                          return (
                            <div key={`history-row-${idx}`} className="grid grid-cols-12 gap-1 py-0.5 hover:bg-slate-900/50 rounded px-1">
                              <span className="col-span-2 text-slate-500 font-bold text-right pr-2">
                                {idx + 1}.
                              </span>
                              <span className="col-span-5 text-white font-medium flex items-center gap-1">
                                <span className="inline-block w-2 h-2 rounded-full bg-slate-200 border border-black/10" />
                                {whiteMove?.notation}
                              </span>
                              <span className="col-span-5 text-amber-400 font-medium flex items-center gap-1">
                                {blackMove && (
                                  <>
                                    <span className="inline-block w-2 h-2 rounded-full bg-zinc-700 border border-black/10" />
                                    {blackMove.notation}
                                  </>
                                )}
                              </span>
                            </div>
                          );
                        })}
                      <div ref={moveLogEndRef} />
                    </div>
                  )}
                </div>
              </div>

            </div>

            {/* MIDDLE COLUMN: THE CHESSBOARD (6 Cols on Large) */}
            <div className="lg:col-span-6 flex flex-col items-center space-y-4">
              
              {/* MANDATORY CAPTURE ALERT OVERLAYS */}
              {mustCapture && !gameEnded && !paused && (
                <div className="w-full bg-amber-500/10 border border-amber-500/35 text-amber-400 p-3 rounded-xl flex items-center gap-3 shadow-lg animate-pulse-glow max-w-[560px]">
                  <span className="p-1 rounded-lg bg-amber-500/20 text-amber-500 flex items-center justify-center shrink-0">
                    <AlertCircle className="w-5 h-5 animate-bounce" />
                  </span>
                  <div className="text-xs md:text-sm">
                    <p className="font-bold text-white flex items-center gap-1">
                      Captura Obrigatória!
                    </p>
                    <p className="text-slate-300 text-[11px] md:text-xs mt-0.5">
                      Pela <strong className="text-amber-400">Lei da Maioria</strong>, você deve capturar o caminho máximo com <strong className="text-white bg-amber-500/25 px-1.5 py-0.5 rounded">{maxCaptureCount} peça{maxCaptureCount > 1 ? "s" : ""}</strong>.
                    </p>
                  </div>
                </div>
              )}

              {/* CURRENT STEPS CHAIN IN MULTI-CAPTURE */}
              {currentSteps.length > 0 && (
                <div className="w-full bg-rose-500/15 border border-rose-500/35 text-rose-300 p-3 rounded-xl flex items-center gap-3 shadow-lg max-w-[560px]">
                  <div className="p-1 rounded-lg bg-rose-500/20 text-rose-400 flex items-center justify-center shrink-0">
                    <ArrowRight className="w-5 h-5 animate-pulse" />
                  </div>
                  <div className="text-xs md:text-sm">
                    <p className="font-bold text-rose-200">Captura em Cadeia!</p>
                    <p className="text-slate-300 text-[11px] mt-0.5">
                      Sua peça está efetuando capturas múltiplas. Faça os próximos saltos obrigatórios.
                    </p>
                  </div>
                </div>
              )}

              {/* CORE GAMEBOARD - SECURED AND CENTRALLY ORIENTATED WITH NO SIDE INVERSION */}
              <GameBoard
                board={board}
                turn={turn}
                selectedPiece={selectedPiece}
                validMoves={validMoves}
                currentSteps={currentSteps}
                ghosts={ghosts}
                lastMove={lastMove}
                theme={theme}
                showSuggestions={showSuggestions}
                onCellClick={handleCellClick}
                isAiThinking={isAiThinking}
                paused={paused}
                gameEnded={gameEnded}
              />

              {/* BOTTOM BOARD EXPLANATION DETAILS */}
              <div className="w-full max-w-[560px] flex justify-between text-[11px] text-slate-400 px-2 select-none">
                <span className="flex items-center gap-1">
                  <span className="inline-block w-2.5 h-2.5 rounded-sm bg-gradient-to-tr from-emerald-950 to-emerald-900 border border-emerald-850" />
                  Peças Brancas embaixo (1-2-3), Pretas em cima (6-7-8)
                </span>
                <span>
                  Lances de Damas consecutivas: <strong className="text-amber-500">{Math.floor(drawTurnCount / 2)}</strong> / 20
                </span>
              </div>
            </div>

            {/* RIGHT COLUMN: ARENA SETTINGS AND CONTROLS (3 Cols on Large) */}
            <div className="lg:col-span-3 space-y-5">
              
              {/* GAME CONFIG INFORMATION */}
              <div className="bg-slate-900 rounded-2xl border border-slate-800/80 p-5 shadow-lg space-y-4">
                <p className="text-xs font-semibold text-slate-400 uppercase tracking-widest">Configurações da Partida</p>
                
                <div className="p-3 bg-slate-950/60 border border-slate-850 rounded-xl space-y-2 text-xs">
                  <div className="flex justify-between items-center">
                    <span className="text-slate-400">Modo:</span>
                    <span className="font-bold text-white uppercase flex items-center gap-1">
                      {gameMode === "robot" ? (
                        <><Cpu className="w-3.5 h-3.5 text-amber-500" /> Contra Robô</>
                      ) : (
                        <><Users className="w-3.5 h-3.5 text-amber-500" /> 2 Jogadores</>
                      )}
                    </span>
                  </div>

                  {gameMode === "robot" && (
                    <div className="flex justify-between items-center">
                      <span className="text-slate-400">Dificuldade:</span>
                      <span className="font-black text-amber-400 uppercase tracking-wide">
                        {aiDifficulty}
                      </span>
                    </div>
                  )}

                  <div className="flex justify-between items-center">
                    <span className="text-slate-400">Sua Cor:</span>
                    <span className="font-bold text-slate-200">
                      {gameMode === "robot" ? (aiColor === 2 ? "Brancas" : "Pretas") : "Ambas (Sua Vez)"}
                    </span>
                  </div>
                </div>

                {/* Change theme in game */}
                <div className="space-y-2">
                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-wider block">Aparência do Tabuleiro</span>
                  <div className="grid grid-cols-2 gap-1.5">
                    {[
                      { id: "wood", label: "Madeira", bg: "from-[#6b4226] to-[#f4ebd0]" },
                      { id: "green", label: "Oficial", bg: "from-[#1f563d] to-[#efebe4]" },
                      { id: "slate", label: "Obsidiana", bg: "from-slate-800 to-slate-200" },
                      { id: "cyber", label: "Cyberpunk", bg: "from-purple-950 to-zinc-800" },
                    ].map((themeBtn) => (
                      <button
                        key={`arena-theme-${themeBtn.id}`}
                        onClick={() => setTheme(themeBtn.id as any)}
                        className={`p-1.5 rounded-lg border text-[10px] font-bold flex items-center gap-1.5 bg-slate-950/40 active:scale-95 transition-all ${
                          theme === themeBtn.id ? "border-amber-500 text-white" : "border-slate-850 text-slate-400 hover:text-slate-300"
                        }`}
                      >
                        <div className={`w-3.5 h-3.5 rounded bg-gradient-to-br ${themeBtn.bg} border border-black/10 shrink-0`} />
                        <span>{themeBtn.label}</span>
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* CONTROL ACTIONS PANEL */}
              <div className="bg-slate-900 rounded-2xl border border-slate-800/80 p-5 shadow-lg space-y-3">
                <p className="text-xs font-semibold text-slate-400 uppercase tracking-widest mb-1">Ações da Arena</p>
                
                <button
                  onClick={handleRestart}
                  className="w-full py-2.5 px-4 font-bold text-xs md:text-sm bg-slate-950 hover:bg-slate-900 border border-slate-800 hover:border-slate-700 active:scale-95 text-white rounded-xl transition-all flex items-center justify-center gap-2 shadow"
                >
                  <RotateCcw className="w-4 h-4 text-amber-500" />
                  <span>Reiniciar Partida</span>
                </button>

                <button
                  onClick={() => setPaused(!paused)}
                  disabled={gameEnded}
                  className={`w-full py-2.5 px-4 font-bold text-xs md:text-sm border rounded-xl transition-all flex items-center justify-center gap-2 active:scale-95 ${
                    gameEnded 
                      ? "opacity-50 cursor-not-allowed bg-slate-950 border-slate-900 text-slate-600" 
                      : paused
                        ? "bg-amber-500 hover:bg-amber-600 text-slate-950 border-amber-600 shadow"
                        : "bg-slate-950 hover:bg-slate-900 border-slate-800 hover:border-slate-700 text-white"
                  }`}
                >
                  {paused ? <Play className="w-4 h-4" /> : <Pause className="w-4 h-4 text-amber-500" />}
                  <span>{paused ? "Retomar Partida" : "Pausar Jogo"}</span>
                </button>

                <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-850">
                  <button
                    onClick={handleOfferDraw}
                    disabled={gameEnded || paused}
                    className="py-2 text-xs font-semibold text-slate-300 hover:text-white bg-slate-950 hover:bg-slate-900 border border-slate-850 hover:border-slate-800 rounded-lg transition-all active:scale-95 disabled:opacity-50"
                  >
                    Propor Empate
                  </button>
                  <button
                    onClick={handleResign}
                    disabled={gameEnded || paused}
                    className="py-2 text-xs font-semibold text-rose-400 hover:text-rose-300 bg-slate-950 hover:bg-rose-950/10 border border-slate-850 hover:border-rose-900/30 rounded-lg transition-all active:scale-95 disabled:opacity-50"
                  >
                    Abandonar
                  </button>
                </div>
              </div>

            </div>
          </main>
        </>
      )}

      {/* GAME OVER MODAL OVERLAY */}
      {gameEnded && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md animate-fade-in">
          <div className="relative w-full max-w-md bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl overflow-hidden p-6 text-center space-y-4">
            <div className="mx-auto h-16 w-16 rounded-full bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-500 shadow-inner">
              <Trophy className="w-8 h-8 filter drop-shadow animate-bounce" />
            </div>

            <div className="space-y-1">
              <h2 className="text-xl md:text-2xl font-black text-white tracking-wide uppercase">
                {winner === null ? "Partida Empatada" : `Vitória!`}
              </h2>
              <p className="text-xs font-bold text-amber-500 uppercase tracking-widest">
                {winner === 1 
                  ? "Jogador 1 (Brancas)" 
                  : winner === 2 
                    ? gameMode === "robot" 
                      ? "Robô (Pretas)" 
                      : "Jogador 2 (Pretas)"
                    : "Fim do Jogo"}
              </p>
            </div>

            <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800/80 text-xs text-slate-300">
              {endReason}
            </div>

            <div className="flex gap-2 pt-2">
              <button
                onClick={() => handleRestart()}
                className="flex-1 py-3 bg-amber-500 hover:bg-amber-600 text-slate-950 font-black tracking-wider rounded-xl transition-all shadow-lg shadow-amber-500/15 hover:shadow-amber-500/25 active:scale-[0.98] text-xs uppercase flex items-center justify-center gap-1.5"
              >
                <RotateCcw className="w-4 h-4 font-black" />
                <span>Jogar Novamente</span>
              </button>
              <button
                onClick={() => setScreen("menu")}
                className="flex-1 py-3 bg-slate-950 hover:bg-slate-900 text-slate-200 border border-slate-800 font-bold rounded-xl transition-all active:scale-[0.98] text-xs uppercase flex items-center justify-center gap-1.5"
              >
                <LogOut className="w-4 h-4" />
                <span>Menu Inicial</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* RULES MODAL DIALOG */}
      <RulesModal isOpen={rulesModalOpen} onClose={() => setRulesModalOpen(false)} />

      {/* FOOTER BAR */}
      <footer className="bg-slate-900 border-t border-slate-850 py-4 mt-auto">
        <div className="max-w-7xl mx-auto px-4 text-center text-xs text-slate-500 select-none">
          <p>© 2026 Damas Oficial. Desenvolvido rigorosamente sob as diretrizes e leis de torneio da Federação Brasileira de Jogo de Damas (FBD).</p>
          <p className="mt-1">Interface responsiva otimizada para computadores de mesa, laptops, celulares de todas as resoluções e tablets.</p>
        </div>
      </footer>
    </div>
  );
}
