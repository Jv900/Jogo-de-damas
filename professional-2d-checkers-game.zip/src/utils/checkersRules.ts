export type Player = 1 | 2; // 1 = White/Light (Brancas), 2 = Black/Dark (Pretas)

export interface Piece {
  id: string;
  player: Player;
  isQueen: boolean;
}

export type Board = (Piece | null)[][];

export interface Position {
  row: number;
  col: number;
}

export interface MoveStep {
  from: Position;
  to: Position;
  captured?: Position; // Position of the piece captured in this single step
}

export interface CapturePath {
  start: Position;
  steps: MoveStep[];
  capturedPositions: string[]; // String keys "row,col" of captured pieces
  endPos: Position;
}

export interface Move {
  start: Position;
  end: Position;
  steps: MoveStep[]; // Multi-jump steps
  isCapture: boolean;
  capturedCount: number;
}

export interface GameHistoryEntry {
  turn: Player;
  notation: string; // e.g. C3-D4 or C3xF5
  timestamp: string;
}

// 8x8 Board setup
// Light squares: (row + col) % 2 === 0
// Dark squares: (row + col) % 2 === 1. Play is only on dark squares.
// Bottom-left corner (7,0) is a dark square ((7+0)%2 === 1).
// Bottom-right corner (7,7) is a light square ((7+7)%2 === 0).
export function createInitialBoard(): Board {
  const board: Board = Array(8)
    .fill(null)
    .map(() => Array(8).fill(null));

  let pieceIdCounter = 1;

  for (let row = 0; row < 8; row++) {
    for (let col = 0; col < 8; col++) {
      if ((row + col) % 2 === 1) {
        if (row < 3) {
          // Player 2 (Dark/Pretas) at top rows
          board[row][col] = {
            id: `p2-${pieceIdCounter++}`,
            player: 2,
            isQueen: false,
          };
        } else if (row > 4) {
          // Player 1 (Light/Brancas) at bottom rows
          board[row][col] = {
            id: `p1-${pieceIdCounter++}`,
            player: 1,
            isQueen: false,
          };
        }
      }
    }
  }

  return board;
}

// Helper to check if coordinates are within the board
export function isValidCell(row: number, col: number): boolean {
  return row >= 0 && row < 8 && col >= 0 && col < 8;
}

// Convert position to checkers notation (e.g., C3, F5, etc.)
// Columns: A-H (0 is A, 7 is H)
// Rows: 8 to 1 (Row 0 is 8, Row 7 is 1)
export function getPositionNotation(row: number, col: number): string {
  const letters = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'];
  const num = 8 - row;
  return `${letters[col]}${num}`;
}

// Deep copy the board
export function cloneBoard(board: Board): Board {
  return board.map((row) =>
    row.map((cell) => (cell ? { ...cell } : null))
  );
}

/**
 * RECURSIVE CAPTURE PATHFINDING
 * Finds all complete capture paths for a given piece on a board.
 * In Brazilian checkers, during a multi-capture, captured pieces remain on the board
 * and act as obstacles (you cannot jump them again or walk through them) until the end of the turn.
 */
export function getCapturePathsForPiece(
  board: Board,
  startRow: number,
  startCol: number,
  player: Player,
  isQueen: boolean,
  currentPos: Position = { row: startRow, col: startCol },
  capturedKeys: Set<string> = new Set<string>(),
  currentSteps: MoveStep[] = []
): CapturePath[] {
  const paths: CapturePath[] = [];
  const directions = [
    { dr: -1, dc: -1 },
    { dr: -1, dc: 1 },
    { dr: 1, dc: -1 },
    { dr: 1, dc: 1 },
  ];

  let hasMoreJumps = false;

  if (!isQueen) {
    // Normal piece captures (can jump both forward and backward)
    for (const { dr, dc } of directions) {
      const midRow = currentPos.row + dr;
      const midCol = currentPos.col + dc;
      const destRow = currentPos.row + dr * 2;
      const destCol = currentPos.col + dc * 2;

      if (isValidCell(destRow, destCol)) {
        const midPiece = board[midRow][midCol];
        const destPiece = board[destRow][destCol];

        const midKey = `${midRow},${midCol}`;

        // Can jump if:
        // - There is an enemy piece in the middle
        // - The enemy piece has NOT been captured yet in this chain
        // - The destination is empty OR is the STARTING position of this full move (since the piece leaves it, it's virtually empty,
        //   but wait: if the piece left it, it IS empty. What if we loop back to an intermediate position of this turn?
        //   We cannot land on a square currently occupied. But the starting square is empty because we already moved from it).
        const isDestEmpty =
          destPiece === null ||
          (destRow === startRow && destCol === startCol && currentSteps.length > 0);

        if (
          midPiece &&
          midPiece.player !== player &&
          !capturedKeys.has(midKey) &&
          isDestEmpty
        ) {
          hasMoreJumps = true;

          // Perform virtual step
          const step: MoveStep = {
            from: { ...currentPos },
            to: { row: destRow, col: destCol },
            captured: { row: midRow, col: midCol },
          };

          const nextCapturedKeys = new Set(capturedKeys);
          nextCapturedKeys.add(midKey);

          // Recurse from the destination
          // Note: In Brazilian checkers, if a normal piece reaches the last row in the middle of a capture,
          // it does NOT promote. It continues capturing as a normal piece.
          const subPaths = getCapturePathsForPiece(
            board,
            startRow,
            startCol,
            player,
            false, // remains normal piece during capture chain
            { row: destRow, col: destCol },
            nextCapturedKeys,
            [...currentSteps, step]
          );

          if (subPaths.length > 0) {
            paths.push(...subPaths);
          } else {
            paths.push({
              start: { row: startRow, col: startCol },
              steps: [...currentSteps, step],
              capturedPositions: Array.from(nextCapturedKeys),
              endPos: { row: destRow, col: destCol },
            });
          }
        }
      }
    }
  } else {
    // Queen (Dama) captures
    // Can move any number of empty spaces, jump over 1 opponent, land on any empty space behind it,
    // and potentially change direction and jump again.
    for (const { dr, dc } of directions) {
      // Find the enemy piece along this diagonal
      let midRow = currentPos.row + dr;
      let midCol = currentPos.col + dc;
      let foundEnemy: Position | null = null;
      let blocked = false;

      while (isValidCell(midRow, midCol)) {
        const piece = board[midRow][midCol];
        const pieceKey = `${midRow},${midCol}`;

        if (piece !== null) {
          // If the piece is already captured in this chain, we treat it as an obstacle (cannot jump again, cannot pass through)
          if (capturedKeys.has(pieceKey)) {
            blocked = true;
            break;
          }

          if (piece.player === player) {
            // Blocked by friendly piece
            blocked = true;
            break;
          } else {
            // Enemy piece found
            foundEnemy = { row: midRow, col: midCol };
            break; // Stop looking further along this diagonal for a first enemy
          }
        }
        midRow += dr;
        midCol += dc;
      }

      if (blocked || !foundEnemy) {
        continue; // No jump in this direction
      }

      // Now check landing squares behind the enemy piece
      let landRow = foundEnemy.row + dr;
      let landCol = foundEnemy.col + dc;

      while (isValidCell(landRow, landCol)) {
        const landPiece = board[landRow][landCol];
        
        // Can land here if it's empty, or if it is the absolute start position of the entire movement
        const isLandEmpty =
          landPiece === null ||
          (landRow === startRow && landCol === startCol && currentSteps.length > 0);

        if (!isLandEmpty) {
          // If we hit any other piece (even a ghost), we cannot jump over it or land further
          break;
        }

        // Valid jump!
        hasMoreJumps = true;
        const step: MoveStep = {
          from: { ...currentPos },
          to: { row: landRow, col: landCol },
          captured: { ...foundEnemy },
        };

        const nextCapturedKeys = new Set(capturedKeys);
        nextCapturedKeys.add(`${foundEnemy.row},${foundEnemy.col}`);

        // Recurse from the landing square
        const subPaths = getCapturePathsForPiece(
          board,
          startRow,
          startCol,
          player,
          true, // Queen stays Queen
          { row: landRow, col: landCol },
          nextCapturedKeys,
          [...currentSteps, step]
        );

        if (subPaths.length > 0) {
          paths.push(...subPaths);
        } else {
          paths.push({
            start: { row: startRow, col: startCol },
            steps: [...currentSteps, step],
            capturedPositions: Array.from(nextCapturedKeys),
            endPos: { row: landRow, col: landCol },
          });
        }

        landRow += dr;
        landCol += dc;
      }
    }
  }

  // If no further jumps were possible but we already made some jumps, return this path
  if (!hasMoreJumps && currentSteps.length > 0) {
    return [
      {
        start: { row: startRow, col: startCol },
        steps: currentSteps,
        capturedPositions: Array.from(capturedKeys),
        endPos: currentPos,
      },
    ];
  }

  return paths;
}

/**
 * Normal (Non-Capturing) moves for a piece
 */
export function getNormalMovesForPiece(
  board: Board,
  row: number,
  col: number,
  player: Player,
  isQueen: boolean
): Move[] {
  const moves: Move[] = [];
  const directions = [
    { dr: -1, dc: -1 },
    { dr: -1, dc: 1 },
    { dr: 1, dc: -1 },
    { dr: 1, dc: 1 },
  ];

  if (!isQueen) {
    // Ordinary piece: only moves forward
    // Player 1 (Light) moves UP (dr < 0, i.e. -1)
    // Player 2 (Dark) moves DOWN (dr > 0, i.e. 1)
    const forwardDr = player === 1 ? -1 : 1;
    const sideDcs = [-1, 1];

    for (const dc of sideDcs) {
      const destRow = row + forwardDr;
      const destCol = col + dc;

      if (isValidCell(destRow, destCol) && board[destRow][destCol] === null) {
        moves.push({
          start: { row, col },
          end: { row: destRow, col: destCol },
          steps: [
            {
              from: { row, col },
              to: { row: destRow, col: destCol },
            },
          ],
          isCapture: false,
          capturedCount: 0,
        });
      }
    }
  } else {
    // Queen (Dama): moves any number of empty squares in all 4 diagonals
    for (const { dr, dc } of directions) {
      let destRow = row + dr;
      let destCol = col + dc;

      while (isValidCell(destRow, destCol) && board[destRow][destCol] === null) {
        moves.push({
          start: { row, col },
          end: { row: destRow, col: destCol },
          steps: [
            {
              from: { row, col },
              to: { row: destRow, col: destCol },
            },
          ],
          isCapture: false,
          capturedCount: 0,
        });
        destRow += dr;
        destCol += dc;
      }
    }
  }

  return moves;
}

/**
 * GET ALL VALID MOVES FOR THE CURRENT PLAYER
 * This function enforces:
 * 1. CAPTURA OBRIGATÓRIA (Capture is mandatory if any capture exists)
 * 2. LEI DA MAIORIA (Must choose the capture path that takes the maximum number of pieces)
 */
export function getValidMoves(board: Board, player: Player): Move[] {
  let allCaptures: CapturePath[] = [];

  // 1. Gather all possible capture paths for all pieces of the current player
  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      const piece = board[r][c];
      if (piece && piece.player === player) {
        const pieceCaptures = getCapturePathsForPiece(
          board,
          r,
          c,
          player,
          piece.isQueen
        );
        allCaptures.push(...pieceCaptures);
      }
    }
  }

  // 2. If captures exist, filter by LEI DA MAIORIA
  if (allCaptures.length > 0) {
    // Find maximum captured count
    let maxCaptured = 0;
    for (const cap of allCaptures) {
      if (cap.capturedPositions.length > maxCaptured) {
        maxCaptured = cap.capturedPositions.length;
      }
    }

    // Only allow paths that capture exactly maxCaptured pieces
    const optimalCaptures = allCaptures.filter(
      (cap) => cap.capturedPositions.length === maxCaptured
    );

    // Map CapturePaths to Move objects
    return optimalCaptures.map((cap) => ({
      start: cap.start,
      end: cap.endPos,
      steps: cap.steps,
      isCapture: true,
      capturedCount: cap.capturedPositions.length,
    }));
  }

  // 3. If no captures are available, get all normal moves
  const normalMoves: Move[] = [];
  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      const piece = board[r][c];
      if (piece && piece.player === player) {
        const pMoves = getNormalMovesForPiece(board, r, c, player, piece.isQueen);
        normalMoves.push(...pMoves);
      }
    }
  }

  return normalMoves;
}

/**
 * Checks if a player has any moves left.
 * If not, the other player wins.
 */
export function hasPossibleMoves(board: Board, player: Player): boolean {
  const moves = getValidMoves(board, player);
  return moves.length > 0;
}

/**
 * Check if the game is over.
 * Returns the winning player or null, and reason.
 */
export function checkGameOver(
  board: Board,
  currentTurn: Player,
  drawTurnCount: number // count of consecutive queen moves without capture/pawn moves
): { winner: Player | null; isDraw: boolean; reason: string } {
  // Check piece counts
  let p1Count = 0;
  let p2Count = 0;

  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      const p = board[r][c];
      if (p) {
        if (p.player === 1) p1Count++;
        else p2Count++;
      }
    }
  }

  if (p1Count === 0) {
    return { winner: 2, isDraw: false, reason: "Jogador 2 capturou todas as peças!" };
  }
  if (p2Count === 0) {
    return { winner: 1, isDraw: false, reason: "Jogador 1 capturou todas as peças!" };
  }

  // Check if current player can move
  const hasMoves = hasPossibleMoves(board, currentTurn);
  if (!hasMoves) {
    const winner = currentTurn === 1 ? 2 : 1;
    return {
      winner,
      isDraw: false,
      reason: `Jogador ${currentTurn} está bloqueado! Jogador ${winner} venceu.`,
    };
  }

  // Draw rule: 20 successive moves with Queens only, no captures, no normal piece moves
  if (drawTurnCount >= 40) { // 20 full moves = 40 half-turns (turns)
    return {
      winner: null,
      isDraw: true,
      reason: "Empate por limite de jogadas sucessivas de Damas (20 jogadas sem capturas)!",
    };
  }

  // Insufficient material draw:
  // e.g. 1 Queen vs 1 Queen
  let p1Queens = 0;
  let p2Queens = 0;
  let p1Normal = 0;
  let p2Normal = 0;

  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      const p = board[r][c];
      if (p) {
        if (p.player === 1) {
          if (p.isQueen) p1Queens++;
          else p1Normal++;
        } else {
          if (p.isQueen) p2Queens++;
          else p2Normal++;
        }
      }
    }
  }

  const totalP1 = p1Queens + p1Normal;
  const totalP2 = p2Queens + p2Normal;

  if (totalP1 === 1 && p1Queens === 1 && totalP2 === 1 && p2Queens === 1) {
    return {
      winner: null,
      isDraw: true,
      reason: "Empate automático! Restou apenas 1 Dama contra 1 Dama.",
    };
  }

  return { winner: null, isDraw: false, reason: "" };
}

/**
 * Execute a move step and return the new board.
 * Also returns whether the piece was promoted to a Queen.
 */
export function executeMoveOnBoard(
  board: Board,
  move: Move
): { newBoard: Board; promoted: boolean } {
  const newBoard = cloneBoard(board);
  const { start, end, steps, isCapture } = move;

  const piece = newBoard[start.row][start.col];
  if (!piece) return { newBoard, promoted: false };

  // Clear starting square
  newBoard[start.row][start.col] = null;

  // Clear captured pieces
  if (isCapture) {
    for (const step of steps) {
      if (step.captured) {
        newBoard[step.captured.row][step.captured.col] = null;
      }
    }
  }

  // Determine if promoted to Queen
  // Regular piece becomes a Queen ONLY if it ENDS its turn on the promotion row.
  let isNowQueen = piece.isQueen;
  let promoted = false;

  if (!piece.isQueen) {
    const promotionRow = piece.player === 1 ? 0 : 7;
    if (end.row === promotionRow) {
      isNowQueen = true;
      promoted = true;
    }
  }

  // Place piece in final spot
  newBoard[end.row][end.col] = {
    ...piece,
    isQueen: isNowQueen,
  };

  return { newBoard, promoted };
}
