// Sound synthesizer utility using Web Audio API

class SoundManager {
  private ctx: AudioContext | null = null;
  private muted: boolean = false;

  private initCtx() {
    if (!this.ctx) {
      this.ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    if (this.ctx && this.ctx.state === "suspended") {
      this.ctx.resume();
    }
  }

  public setMuted(muted: boolean) {
    this.muted = muted;
  }

  public isMuted(): boolean {
    return this.muted;
  }

  public playMove() {
    if (this.muted) return;
    try {
      this.initCtx();
      const ctx = this.ctx;
      if (!ctx) return;

      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = "triangle";
      // A quick, wooden "clack"
      osc.frequency.setValueAtTime(120, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(40, ctx.currentTime + 0.08);

      gain.gain.setValueAtTime(0.3, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.08);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start();
      osc.stop(ctx.currentTime + 0.08);
    } catch (e) {
      console.warn("Web Audio API not supported or blocked", e);
    }
  }

  public playCapture() {
    if (this.muted) return;
    try {
      this.initCtx();
      const ctx = this.ctx;
      if (!ctx) return;

      const now = ctx.currentTime;
      // Capture is a double-clack with higher frequency
      for (let i = 0; i < 2; i++) {
        const timeOffset = i * 0.06;
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        osc.type = "sine";
        osc.frequency.setValueAtTime(180 - i * 30, now + timeOffset);
        osc.frequency.exponentialRampToValueAtTime(60, now + timeOffset + 0.05);

        gain.gain.setValueAtTime(0.4, now + timeOffset);
        gain.gain.exponentialRampToValueAtTime(0.01, now + timeOffset + 0.05);

        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.start(now + timeOffset);
        osc.stop(now + timeOffset + 0.05);
      }
    } catch (e) {
      console.warn("Web Audio API warning", e);
    }
  }

  public playPromote() {
    if (this.muted) return;
    try {
      this.initCtx();
      const ctx = this.ctx;
      if (!ctx) return;

      const now = ctx.currentTime;
      // Ascending chime
      const notes = [261.63, 329.63, 392.00, 523.25]; // C4, E4, G4, C5
      notes.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        osc.type = "sine";
        osc.frequency.setValueAtTime(freq, now + idx * 0.08);

        gain.gain.setValueAtTime(0.15, now + idx * 0.08);
        gain.gain.exponentialRampToValueAtTime(0.01, now + idx * 0.08 + 0.2);

        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.start(now + idx * 0.08);
        osc.stop(now + idx * 0.08 + 0.2);
      });
    } catch (e) {
      console.warn("Web Audio API warning", e);
    }
  }

  public playWin() {
    if (this.muted) return;
    try {
      this.initCtx();
      const ctx = this.ctx;
      if (!ctx) return;

      const now = ctx.currentTime;
      // Happy major chord fanfare
      const chord = [261.63, 329.63, 392.00, 523.25, 659.25]; // C major notes
      chord.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        osc.type = "triangle";
        osc.frequency.setValueAtTime(freq, now + idx * 0.1);
        
        gain.gain.setValueAtTime(0.1, now + idx * 0.1);
        gain.gain.linearRampToValueAtTime(0.1, now + idx * 0.1 + 0.3);
        gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.1 + 0.7);

        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.start(now + idx * 0.1);
        osc.stop(now + idx * 0.1 + 0.8);
      });
    } catch (e) {
      console.warn("Web Audio API warning", e);
    }
  }

  public playLoss() {
    if (this.muted) return;
    try {
      this.initCtx();
      const ctx = this.ctx;
      if (!ctx) return;

      const now = ctx.currentTime;
      // Melancholic descending notes
      const notes = [311.13, 293.66, 261.63, 233.08]; // Eb4, D4, C4, Bb3 (sad feel)
      notes.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        osc.type = "sine";
        osc.frequency.setValueAtTime(freq, now + idx * 0.15);

        gain.gain.setValueAtTime(0.15, now + idx * 0.15);
        gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.15 + 0.4);

        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.start(now + idx * 0.15);
        osc.stop(now + idx * 0.15 + 0.4);
      });
    } catch (e) {
      console.warn("Web Audio API warning", e);
    }
  }
}

export const sound = new SoundManager();
