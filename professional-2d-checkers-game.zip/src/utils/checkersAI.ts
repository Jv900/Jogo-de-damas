import {
  Board,
  Player,
  Move,
  getValidMoves,
  executeMoveOnBoard,
} from "./checkersRules";

/**
 * Heurística de avaliação do tabuleiro.
 * Retorna uma pontuação sob a perspectiva de um determinado jogador.
 * Valores positivos são bons para o jogador, negativos para o adversário.
 */
export function evaluateBoard(board: Board, player: Player): number {
  let score = 0;

  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      const piece = board[r][c];
      if (!piece) continue;

      const isFriendly = piece.player === player;
      const sign = isFriendly ? 1 : -1;

      // 1. Valor base da peça
      let val = piece.isQueen ? 350 : 100;

      // 2. Controle do Centro (casas centrais são taticamente superiores)
      // Linhas 3 e 4, Colunas 2 a 5
      if (r >= 2 && r <= 5 && c >= 2 && c <= 5) {
        val += piece.isQueen ? 25 : 15;
      }

      // 3. Defesa da última fileira (evita coroação do oponente)
      if (piece.player === 1 && r === 7) {
        val += 25; // Brancas protegendo sua linha de fundo
      }
      if (piece.player === 2 && r === 0) {
        val += 25; // Pretas protegendo sua linha de fundo
      }

      // 4. Progresso de promoção (pedras normais mais próximas de virar Dama valem mais)
      if (!piece.isQueen) {
        if (piece.player === 1) {
          // Brancas avançando para a linha 0
          val += (7 - r) * 8;
        } else {
          // Pretas avançando para a linha 7
          val += r * 8;
        }
      }

      // 5. Segurança nas bordas (peças nas laterais não podem ser capturadas)
      if (c === 0 || c === 7) {
        val += 12;
      }

      // 6. Peças de ouro (as pontas da linha de trás oferecem posições defensivas fortes)
      if (!piece.isQueen) {
        if (piece.player === 1 && r === 7 && (c === 0 || c === 6)) {
          val += 20;
        }
        if (piece.player === 2 && r === 0 && (c === 1 || c === 7)) {
          val += 20;
        }
      }

      score += sign * val;
    }
  }

  return score;
}

/**
 * Algoritmo Minimax com Poda Alfa-Beta para selecionar a melhor jogada.
 */
function minimax(
  board: Board,
  depth: number,
  alpha: number,
  beta: number,
  isMaximizing: boolean,
  aiPlayer: Player,
  currentPlayer: Player
): { score: number; move: Move | null } {
  // Condição de parada: profundidade alcançada ou fim de jogo
  const validMoves = getValidMoves(board, currentPlayer);

  if (depth === 0 || validMoves.length === 0) {
    return {
      score: evaluateBoard(board, aiPlayer),
      move: null,
    };
  }

  let bestMove: Move | null = null;

  if (isMaximizing) {
    let maxScore = -Infinity;
    for (const move of validMoves) {
      // Executa jogada virtualmente
      const { newBoard } = executeMoveOnBoard(board, move);
      const nextPlayer: Player = currentPlayer === 1 ? 2 : 1;

      // Recurse
      const { score } = minimax(
        newBoard,
        depth - 1,
        alpha,
        beta,
        false,
        aiPlayer,
        nextPlayer
      );

      if (score > maxScore) {
        maxScore = score;
        bestMove = move;
      }

      alpha = Math.max(alpha, score);
      if (beta <= alpha) {
        break; // Poda Beta
      }
    }
    return { score: maxScore, move: bestMove };
  } else {
    let minScore = Infinity;
    for (const move of validMoves) {
      // Executa jogada virtualmente
      const { newBoard } = executeMoveOnBoard(board, move);
      const nextPlayer: Player = currentPlayer === 1 ? 2 : 1;

      // Recurse
      const { score } = minimax(
        newBoard,
        depth - 1,
        alpha,
        beta,
        true,
        aiPlayer,
        nextPlayer
      );

      if (score < minScore) {
        minScore = score;
        bestMove = move;
      }

      beta = Math.min(beta, score);
      if (beta <= alpha) {
        break; // Poda Alfa
      }
    }
    return { score: minScore, move: bestMove };
  }
}

/**
 * Função principal para obter a jogada da Inteligência Artificial.
 * Suporta 4 níveis de dificuldade: Fácil, Médio, Difícil, Mestre.
 */
export function getAIMove(
  board: Board,
  aiPlayer: Player,
  difficulty: "facil" | "medio" | "dificil" | "mestre"
): Move | null {
  const validMoves = getValidMoves(board, aiPlayer);

  if (validMoves.length === 0) return null;
  if (validMoves.length === 1) return validMoves[0]; // Só há uma jogada possível (ex: captura obrigatória única)

  // 1. NÍVEL FÁCIL:
  // Tem 35% de chance de fazer uma escolha aleatória simples.
  // Caso contrário, calcula em Profundidade 1 (vê apenas 1 lance à frente).
  if (difficulty === "facil") {
    if (Math.random() < 0.35) {
      const randomIndex = Math.floor(Math.random() * validMoves.length);
      return validMoves[randomIndex];
    }
    const { move } = minimax(board, 1, -Infinity, Infinity, true, aiPlayer, aiPlayer);
    return move || validMoves[0];
  }

  // 2. NÍVEL MÉDIO:
  // Profundidade 2 ou 3.
  // Joga de forma sólida, não comete erros óbvios, mas não planeja muito a longo prazo.
  if (difficulty === "medio") {
    const { move } = minimax(board, 2, -Infinity, Infinity, true, aiPlayer, aiPlayer);
    return move || validMoves[0];
  }

  // 3. NÍVEL DIFÍCIL:
  // Profundidade 4.
  // Planeja lances à frente, protege o fundo e tenta armar armadilhas de captura.
  if (difficulty === "dificil") {
    const { move } = minimax(board, 4, -Infinity, Infinity, true, aiPlayer, aiPlayer);
    return move || validMoves[0];
  }

  // 4. NÍVEL MESTRE:
  // Profundidade 5 ou 6.
  // Alta inteligência tática, calcula múltiplos lances de captura e domina as pontas e o centro.
  // Se o jogo estiver nas fases finais (poucas peças), aumentamos a profundidade para cálculo perfeito.
  let pieceCount = 0;
  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      if (board[r][c]) pieceCount++;
    }
  }

  const depth = pieceCount <= 6 ? 7 : 5; // Jogo final permite pesquisar mais fundo de forma rápida!
  const { move } = minimax(board, depth, -Infinity, Infinity, true, aiPlayer, aiPlayer);
  return move || validMoves[0];
}
