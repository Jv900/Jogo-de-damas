import { BoardPiece, MoveOption, PlayerColor, Position } from '../types/game';

export const BOARD_SIZE = 8;

/**
 * Checks if (row, col) is on the board
 */
export function isValidSquare(row: number, col: number): boolean {
  return row >= 0 && row < BOARD_SIZE && col >= 0 && col < BOARD_SIZE;
}

/**
 * Checks if (row, col) is a dark square valid for Checkers
 */
export function isDarkSquare(row: number, col: number): boolean {
  return isValidSquare(row, col) && (row + col) % 2 === 1;
}

/**
 * Creates the initial official Brazilian Checkers board setup (12 white vs 12 black on dark squares)
 */
export function createInitialBoard(): (BoardPiece | null)[][] {
  const board: (BoardPiece | null)[][] = Array.from({ length: BOARD_SIZE }, () =>
    Array(BOARD_SIZE).fill(null)
  );

  // Black pieces on rows 0, 1, 2
  for (let r = 0; r <= 2; r++) {
    for (let c = 0; c < BOARD_SIZE; c++) {
      if (isDarkSquare(r, c)) {
        board[r][c] = {
          id: `black-${r}-${c}`,
          color: 'black',
          type: 'pedra',
          row: r,
          col: c,
        };
      }
    }
  }

  // White pieces on rows 5, 6, 7
  for (let r = 5; r <= 7; r++) {
    for (let c = 0; c < BOARD_SIZE; c++) {
      if (isDarkSquare(r, c)) {
        board[r][c] = {
          id: `white-${r}-${c}`,
          color: 'white',
          type: 'pedra',
          row: r,
          col: c,
        };
      }
    }
  }

  return board;
}

/**
 * Helper to clone board for simulations
 */
export function cloneBoard(board: (BoardPiece | null)[][]): (BoardPiece | null)[][] {
  return board.map(row => row.map(piece => (piece ? { ...piece } : null)));
}

/**
 * Generates string representation of board + turn for 3-fold repetition
 */
export function getBoardPositionHash(board: (BoardPiece | null)[][], turn: PlayerColor): string {
  let hash = `${turn}:`;
  for (let r = 0; r < BOARD_SIZE; r++) {
    for (let c = 0; c < BOARD_SIZE; c++) {
      const p = board[r][c];
      if (p) {
        hash += `${r}${c}${p.color[0]}${p.type[0]};`;
      }
    }
  }
  return hash;
}

/**
 * Checks if a piece would promote at `pos` (ONLY if it stops there at the end of its turn)
 */
export function willPromote(piece: BoardPiece, targetRow: number): boolean {
  if (piece.type === 'dama') return false;
  return (piece.color === 'white' && targetRow === 0) || (piece.color === 'black' && targetRow === BOARD_SIZE - 1);
}

/**
 * Recursive finder for multi-jumps of a single piece.
 * Adheres to Brazilian Checkers ("As peças capturadas não são retiradas durante a sequência de captura" + "Não pode saltar a mesma peça duas vezes").
 */
function findJumpSequences(
  board: (BoardPiece | null)[][],
  piece: BoardPiece,
  currentPos: Position,
  alreadyCaptured: Position[],
  pathSoFar: Position[]
): MoveOption[] {
  const results: MoveOption[] = [];
  const directions = [
    { dr: -1, dc: -1 },
    { dr: -1, dc: 1 },
    { dr: 1, dc: -1 },
    { dr: 1, dc: 1 },
  ];

  let foundFurtherJump = false;

  if (piece.type === 'pedra') {
    // Pedra captures 1 square away, landing 2 squares away in any of 4 diagonals
    for (const { dr, dc } of directions) {
      const adjRow = currentPos.row + dr;
      const adjCol = currentPos.col + dc;
      const landRow = currentPos.row + dr * 2;
      const landCol = currentPos.col + dc * 2;

      if (!isValidSquare(landRow, landCol)) continue;

      const adjPiece = board[adjRow][adjCol];
      // Must be an opponent piece that hasn't been captured yet in this sequence
      if (!adjPiece || adjPiece.color === piece.color) continue;
      const alreadyJumpedThisPiece = alreadyCaptured.some(p => p.row === adjRow && p.col === adjCol);
      if (alreadyJumpedThisPiece) continue;

      const landPiece = board[landRow][landCol];
      // Landing square must be empty OR the starting square of this exact piece (since the piece moved away)
      const isStartSquare = landRow === piece.row && landCol === piece.col;
      if (landPiece && !isStartSquare) continue;

      foundFurtherJump = true;
      const nextPath = [...pathSoFar, { row: landRow, col: landCol }];
      const nextCaptured = [...alreadyCaptured, { row: adjRow, col: adjCol }];

      // Recurse from land pos
      const subSequences = findJumpSequences(
        board,
        piece,
        { row: landRow, col: landCol },
        nextCaptured,
        nextPath
      );

      results.push(...subSequences);
    }
  } else {
    // Dama captures along any diagonal distance
    for (const { dr, dc } of directions) {
      let r = currentPos.row + dr;
      let c = currentPos.col + dc;
      let firstOpponentPos: Position | null = null;

      // Scan along the diagonal until edge or obstacle
      while (isValidSquare(r, c)) {
        const squarePiece = board[r][c];
        const isStartSquare = r === piece.row && c === piece.col;

        if (squarePiece && !isStartSquare) {
          if (squarePiece.color === piece.color) {
            // Blocked by friendly piece
            break;
          } else {
            // Found opponent piece
            const alreadyJumpedThisPiece = alreadyCaptured.some(p => p.row === r && p.col === c);
            if (alreadyJumpedThisPiece) {
              // Cannot jump over the same captured piece twice
              break;
            }
            if (firstOpponentPos !== null) {
              // Two opponent pieces without empty space in between along diagonal
              break;
            }
            firstOpponentPos = { row: r, col: c };
          }
        } else if (firstOpponentPos !== null) {
          // This square is empty beyond the captured opponent piece!
          // We can land here AND check if from here we can jump further along branching diagonals!
          foundFurtherJump = true;
          const nextPath = [...pathSoFar, { row: r, col: c }];
          const nextCaptured = [...alreadyCaptured, firstOpponentPos];

          const subSequences = findJumpSequences(
            board,
            piece,
            { row: r, col: c },
            nextCaptured,
            nextPath
          );

          results.push(...subSequences);
        }

        r += dr;
        c += dc;
      }
    }
  }

  if (!foundFurtherJump && alreadyCaptured.length > 0) {
    // This is the end of a capture sequence
    const finalPos = currentPos;
    results.push({
      from: { row: piece.row, col: piece.col },
      to: finalPos,
      path: pathSoFar,
      capturedPositions: alreadyCaptured,
      isCapture: true,
      captureCount: alreadyCaptured.length,
      promoted: willPromote(piece, finalPos.row),
    });
  }

  return results;
}

/**
 * Finds normal non-capture moves for a piece
 */
function findSimpleMoves(board: (BoardPiece | null)[][], piece: BoardPiece): MoveOption[] {
  const results: MoveOption[] = [];

  if (piece.type === 'pedra') {
    // Pedra only moves forward (1 step diagonally)
    const dr = piece.color === 'white' ? -1 : 1;
    const dCols = [-1, 1];

    for (const dc of dCols) {
      const targetRow = piece.row + dr;
      const targetCol = piece.col + dc;

      if (isValidSquare(targetRow, targetCol) && !board[targetRow][targetCol]) {
        results.push({
          from: { row: piece.row, col: piece.col },
          to: { row: targetRow, col: targetCol },
          path: [{ row: piece.row, col: piece.col }, { row: targetRow, col: targetCol }],
          capturedPositions: [],
          isCapture: false,
          captureCount: 0,
          promoted: willPromote(piece, targetRow),
        });
      }
    }
  } else {
    // Dama moves any number of empty squares in 4 directions
    const directions = [
      { dr: -1, dc: -1 },
      { dr: -1, dc: 1 },
      { dr: 1, dc: -1 },
      { dr: 1, dc: 1 },
    ];

    for (const { dr, dc } of directions) {
      let r = piece.row + dr;
      let c = piece.col + dc;

      while (isValidSquare(r, c) && !board[r][c]) {
        results.push({
          from: { row: piece.row, col: piece.col },
          to: { row: r, col: c },
          path: [{ row: piece.row, col: piece.col }, { row: r, col: c }],
          capturedPositions: [],
          isCapture: false,
          captureCount: 0,
          promoted: false, // Dama is already Dama
        });
        r += dr;
        c += dc;
      }
    }
  }

  return results;
}

/**
 * Computes ALL valid moves for ALL pieces of `color` under Official Brazilian Checkers Rules.
 * Enforces Captura Obrigatória + Lei da Maioria (if `enforceMajorityRule` is true or always).
 */
export function getAllValidMovesForPlayer(
  board: (BoardPiece | null)[][],
  color: PlayerColor,
  enforceMajorityRule: boolean = true
): MoveOption[] {
  const allCaptures: MoveOption[] = [];
  const allSimpleMoves: MoveOption[] = [];

  for (let r = 0; r < BOARD_SIZE; r++) {
    for (let c = 0; c < BOARD_SIZE; c++) {
      const piece = board[r][c];
      if (piece && piece.color === color) {
        const captures = findJumpSequences(
          board,
          piece,
          { row: r, col: c },
          [],
          [{ row: r, col: c }]
        );
        allCaptures.push(...captures);

        // Only compute simple moves if no captures found yet (optimization/logical separation)
        const simple = findSimpleMoves(board, piece);
        allSimpleMoves.push(...simple);
      }
    }
  }

  // 1. If ANY capture exists -> Captura Obrigatória! Simple moves are forbidden!
  if (allCaptures.length > 0) {
    if (!enforceMajorityRule) {
      return allCaptures;
    }

    // 2. Lei da Maioria: must pick the sequence(s) capturing the MAXIMUM number of pieces
    let maxCaptureCount = 0;
    for (const move of allCaptures) {
      if (move.captureCount > maxCaptureCount) {
        maxCaptureCount = move.captureCount;
      }
    }

    return allCaptures.filter(m => m.captureCount === maxCaptureCount);
  }

  // No captures possible, return all simple moves
  return allSimpleMoves;
}

/**
 * Returns valid moves for a specific piece at (row, col) given the player's full allowed moves
 */
export function getValidMovesForSquare(
  allAllowedMoves: MoveOption[],
  row: number,
  col: number
): MoveOption[] {
  return allAllowedMoves.filter(m => m.from.row === row && m.from.col === col);
}

/**
 * Applies a move to the board and returns updated board, piece, and whether it promoted
 */
export function applyMoveToBoard(
  board: (BoardPiece | null)[][],
  move: MoveOption
): {
  newBoard: (BoardPiece | null)[][];
  movedPiece: BoardPiece;
  wasPromoted: boolean;
  capturedPieces: BoardPiece[];
} {
  const newBoard = cloneBoard(board);
  const piece = newBoard[move.from.row][move.from.col];

  if (!piece) {
    throw new Error(`No piece at ${move.from.row},${move.from.col}`);
  }

  // Remove from start square
  newBoard[move.from.row][move.from.col] = null;

  // Collect and remove captured pieces
  const capturedPieces: BoardPiece[] = [];
  for (const capPos of move.capturedPositions) {
    const capPiece = newBoard[capPos.row][capPos.col];
    if (capPiece) {
      capturedPieces.push(capPiece);
      newBoard[capPos.row][capPos.col] = null;
    }
  }

  // Place piece at destination
  let wasPromoted = false;
  let newType = piece.type;
  if (move.promoted && piece.type === 'pedra') {
    newType = 'dama';
    wasPromoted = true;
  }

  const movedPiece: BoardPiece = {
    ...piece,
    row: move.to.row,
    col: move.to.col,
    type: newType,
  };

  newBoard[move.to.row][move.to.col] = movedPiece;

  return {
    newBoard,
    movedPiece,
    wasPromoted,
    capturedPieces,
  };
}

/**
 * Converts algebraic or board coordinates to clean notation (e.g., c3-d4 or c3xe5xg7)
 */
export function formatMoveNotation(move: MoveOption): string {
  const colLetter = (c: number) => String.fromCharCode(97 + c);
  const rowNumber = (r: number) => (BOARD_SIZE - r).toString();

  const fromStr = `${colLetter(move.from.col)}${rowNumber(move.from.row)}`;
  
  if (move.isCapture) {
    // If capture, show the jumps or landing positions
    const steps = move.path.slice(1).map(p => `${colLetter(p.col)}${rowNumber(p.row)}`);
    return `${fromStr}x${steps.join('x')}`;
  } else {
    const toStr = `${colLetter(move.to.col)}${rowNumber(move.to.row)}`;
    return `${fromStr}-${toStr}`;
  }
}

/**
 * Counts pieces of each color
 */
export function countPieces(board: (BoardPiece | null)[][]): {
  whitePedras: number;
  whiteDamas: number;
  blackPedras: number;
  blackDamas: number;
  whiteTotal: number;
  blackTotal: number;
} {
  let whitePedras = 0;
  let whiteDamas = 0;
  let blackPedras = 0;
  let blackDamas = 0;

  for (let r = 0; r < BOARD_SIZE; r++) {
    for (let c = 0; c < BOARD_SIZE; c++) {
      const p = board[r][c];
      if (p) {
        if (p.color === 'white') {
          if (p.type === 'pedra') whitePedras++;
          else whiteDamas++;
        } else {
          if (p.type === 'pedra') blackPedras++;
          else blackDamas++;
        }
      }
    }
  }

  return {
    whitePedras,
    whiteDamas,
    blackPedras,
    blackDamas,
    whiteTotal: whitePedras + whiteDamas,
    blackTotal: blackPedras + blackDamas,
  };
}

/**
 * Checks if current player is out of moves or if all pieces of a player are captured
 */
export function checkGameEnd(
  board: (BoardPiece | null)[][],
  currentTurn: PlayerColor,
  allAllowedMovesForCurrent: MoveOption[],
  positionHistory: string[],
  halfMoveClock: number
): {
  isEnd: boolean;
  winner: PlayerColor | null;
  winReason: string | null;
} {
  const counts = countPieces(board);

  // 1. Check if all pieces captured
  if (counts.whiteTotal === 0) {
    return {
      isEnd: true,
      winner: 'black',
      winReason: 'Vitória por Captura Total (Todas as peças brancas foram capturadas)',
    };
  }
  if (counts.blackTotal === 0) {
    return {
      isEnd: true,
      winner: 'white',
      winReason: 'Vitória por Captura Total (Todas as peças pretas foram capturadas)',
    };
  }

  // 2. Check if current player is blocked (no legal moves left)
  if (allAllowedMovesForCurrent.length === 0) {
    const winner = currentTurn === 'white' ? 'black' : 'white';
    const blockedColorName = currentTurn === 'white' ? 'Brancas' : 'Pretas';
    return {
      isEnd: true,
      winner,
      winReason: `Vitória por Bloqueio Total (As peças ${blockedColorName} não possuem movimentos legais)`,
    };
  }

  // 3. Draw by 3-fold repetition
  if (positionHistory.length >= 3) {
    const currentHash = positionHistory[positionHistory.length - 1];
    let repeatCount = 0;
    for (const h of positionHistory) {
      if (h === currentHash) {
        repeatCount++;
      }
    }
    if (repeatCount >= 3) {
      return {
        isEnd: true,
        winner: null,
        winReason: 'Empate pela Regra das 3 Repetições (A mesma posição repetiu 3 vezes no tabuleiro)',
      };
    }
  }

  // 4. Draw by 20 moves rule without captures or pawn move
  if (halfMoveClock >= 40) { // 40 half-moves = 20 full turns of both players
    return {
      isEnd: true,
      winner: null,
      winReason: 'Empate pela Regra dos 20 Lances (20 lances consecutivos sem captura nem movimento de pedra)',
    };
  }

  return {
    isEnd: false,
    winner: null,
    winReason: null,
  };
}
