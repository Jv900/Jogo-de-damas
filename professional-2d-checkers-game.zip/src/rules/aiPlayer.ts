import { AIDifficulty, BoardPiece, MoveOption, PlayerColor } from '../types/game';
import { applyMoveToBoard, BOARD_SIZE, getAllValidMovesForPlayer } from './damasEngine';

/**
 * Heuristic evaluation function for a board state from AI's perspective
 */
function evaluateBoard(
  board: (BoardPiece | null)[][],
  aiColor: PlayerColor,
  enforceMajorityRule: boolean
): number {
  let score = 0;
  const oppColor: PlayerColor = aiColor === 'white' ? 'black' : 'white';

  let aiCount = 0;
  let oppCount = 0;

  for (let r = 0; r < BOARD_SIZE; r++) {
    for (let c = 0; c < BOARD_SIZE; c++) {
      const piece = board[r][c];
      if (!piece) continue;

      const isAi = piece.color === aiColor;
      const multiplier = isAi ? 1 : -1;

      if (isAi) aiCount++;
      else oppCount++;

      // Base value: Pedra = 100, Dama = 350
      if (piece.type === 'pedra') {
        score += multiplier * 100;

        // Positional bonus: advancement toward promotion
        const advancement = piece.color === 'black' ? r : (BOARD_SIZE - 1 - r);
        score += multiplier * (advancement * 5);

        // Center control bonus (squares d4, e4, d5, e5, c4, f5)
        if ((r === 3 || r === 4) && (c >= 2 && c <= 5)) {
          score += multiplier * 8;
        }

        // Back-row protection bonus (row 0 for black, row 7 for white)
        const isBackRow = (piece.color === 'black' && r === 0) || (piece.color === 'white' && r === BOARD_SIZE - 1);
        if (isBackRow) {
          score += multiplier * 12;
        }
      } else {
        // Dama bonus
        score += multiplier * 350;

        // Central Dama has high mobility
        if (r >= 2 && r <= 5 && c >= 2 && c <= 5) {
          score += multiplier * 15;
        }
      }
    }
  }

  // Terminal checks
  if (aiCount === 0) return -100000;
  if (oppCount === 0) return 100000;

  // Mobility bonus (how many moves are available)
  const aiMoves = getAllValidMovesForPlayer(board, aiColor, enforceMajorityRule);
  const oppMoves = getAllValidMovesForPlayer(board, oppColor, enforceMajorityRule);

  if (aiMoves.length === 0) return -90000; // AI has no moves, defeat
  if (oppMoves.length === 0) return 90000; // Opponent has no moves, AI win!

  score += (aiMoves.length - oppMoves.length) * 3;

  return score;
}

/**
 * Minimax with Alpha-Beta Pruning
 */
function minimax(
  board: (BoardPiece | null)[][],
  depth: number,
  alpha: number,
  beta: number,
  maximizingPlayer: boolean,
  aiColor: PlayerColor,
  enforceMajorityRule: boolean
): { score: number; move?: MoveOption } {
  const currentColor = maximizingPlayer ? aiColor : (aiColor === 'white' ? 'black' : 'white');
  const validMoves = getAllValidMovesForPlayer(board, currentColor, enforceMajorityRule);

  if (depth === 0 || validMoves.length === 0) {
    return { score: evaluateBoard(board, aiColor, enforceMajorityRule) };
  }

  // Sort moves: try captures first for much faster alpha-beta cutoff
  validMoves.sort((a, b) => b.captureCount - a.captureCount || (b.promoted ? 1 : 0) - (a.promoted ? 1 : 0));

  if (maximizingPlayer) {
    let maxEval = -Infinity;
    let bestMove = validMoves[0];

    for (const move of validMoves) {
      const { newBoard } = applyMoveToBoard(board, move);
      const evalResult = minimax(
        newBoard,
        depth - 1,
        alpha,
        beta,
        false,
        aiColor,
        enforceMajorityRule
      );

      if (evalResult.score > maxEval) {
        maxEval = evalResult.score;
        bestMove = move;
      }
      alpha = Math.max(alpha, evalResult.score);
      if (beta <= alpha) {
        break; // Beta cut-off
      }
    }
    return { score: maxEval, move: bestMove };
  } else {
    let minEval = Infinity;
    let bestMove = validMoves[0];

    for (const move of validMoves) {
      const { newBoard } = applyMoveToBoard(board, move);
      const evalResult = minimax(
        newBoard,
        depth - 1,
        alpha,
        beta,
        true,
        aiColor,
        enforceMajorityRule
      );

      if (evalResult.score < minEval) {
        minEval = evalResult.score;
        bestMove = move;
      }
      beta = Math.min(beta, evalResult.score);
      if (beta <= alpha) {
        break; // Alpha cut-off
      }
    }
    return { score: minEval, move: bestMove };
  }
}

/**
 * Selects the best move according to the AI difficulty level
 */
export function getBestMoveForAI(
  board: (BoardPiece | null)[][],
  aiColor: PlayerColor,
  difficulty: AIDifficulty,
  enforceMajorityRule: boolean
): MoveOption | null {
  const validMoves = getAllValidMovesForPlayer(board, aiColor, enforceMajorityRule);
  if (validMoves.length === 0) return null;
  if (validMoves.length === 1) return validMoves[0];

  // 1. Easy level: 40% random move, or simple evaluation
  if (difficulty === 'easy') {
    if (Math.random() < 0.45) {
      const randomIndex = Math.floor(Math.random() * validMoves.length);
      return validMoves[randomIndex];
    }
    // Otherwise 1-ply search
    const result = minimax(board, 1, -Infinity, Infinity, true, aiColor, enforceMajorityRule);
    return result.move || validMoves[0];
  }

  // 2. Medium level: basic strategy (depth 3), no silly mistakes, respects positional safety
  if (difficulty === 'medium') {
    // Occasional slight sub-optimal choice to keep game dynamic for intermediate players
    const result = minimax(board, 3, -Infinity, Infinity, true, aiColor, enforceMajorityRule);
    return result.move || validMoves[0];
  }

  // 3. Hard level: advanced planning (depth 5)
  if (difficulty === 'hard') {
    const result = minimax(board, 5, -Infinity, Infinity, true, aiColor, enforceMajorityRule);
    return result.move || validMoves[0];
  }

  // 4. Master level: official tournament depth (depth 6 or 8 if fewer pieces left)
  let searchDepth = 6;
  let totalPieces = 0;
  for (let r = 0; r < BOARD_SIZE; r++) {
    for (let c = 0; c < BOARD_SIZE; c++) {
      if (board[r][c]) totalPieces++;
    }
  }
  if (totalPieces <= 10) searchDepth = 7;
  if (totalPieces <= 5) searchDepth = 8;

  const result = minimax(board, searchDepth, -Infinity, Infinity, true, aiColor, enforceMajorityRule);
  return result.move || validMoves[0];
}
