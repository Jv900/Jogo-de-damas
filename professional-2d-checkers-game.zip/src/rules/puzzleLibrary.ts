import { BoardPiece, PuzzleChallenge } from '../types/game';
import { BOARD_SIZE, isDarkSquare } from './damasEngine';

/**
 * Helper to build empty board
 */
function createEmptyBoard(): (BoardPiece | null)[][] {
  return Array.from({ length: BOARD_SIZE }, () => Array(BOARD_SIZE).fill(null));
}

/**
 * Helper to place piece
 */
function placePiece(
  board: (BoardPiece | null)[][],
  row: number,
  col: number,
  color: 'white' | 'black',
  type: 'pedra' | 'dama' = 'pedra'
) {
  if (isDarkSquare(row, col)) {
    board[row][col] = {
      id: `${color}-${row}-${col}-${Math.random()}`,
      color,
      type,
      row,
      col,
    };
  }
}

export const PUZZLE_CHALLENGES: PuzzleChallenge[] = [
  {
    id: 'lei-da-maioria-1',
    title: 'Desafio 1: A Lei da Maioria',
    difficulty: 'Iniciante',
    description: 'Pelas Regras Oficiais da FBD, quando houver duas ou mais opções de captura, é OBRIGATÓRIO escolher o caminho que capture o MAIOR número de peças adversárias ("Lei da Maioria").',
    ruleHighlight: 'Observe que a pedra branca em e3 (4,4) pode capturar 1 peça para a esquerda ou 3 peças na sequência para a direita. O sistema obrigará você a escolher a captura de 3 peças!',
    objective: 'Efetue a captura múltipla obrigatória de 3 peças para vencer a partida.',
    initialTurn: 'white',
    boardSetup: (() => {
      const b = createEmptyBoard();
      placePiece(b, 4, 4, 'white', 'pedra'); // e3/row 4 col 4
      
      // Option 1: 1 capture to the top-left (row 3 col 3 -> land row 2 col 2)
      placePiece(b, 3, 3, 'black', 'pedra');

      // Option 2 (Majority sequence!): 3 captures
      placePiece(b, 3, 5, 'black', 'pedra'); // first jump to row 2 col 6
      placePiece(b, 3, 7, 'black', 'pedra'); // after landing at (2,6), jumps to (4,6) ? let's make a clear exact chain
      
      // Let's create exact chain: start at (5,2)
      return (() => {
        const board = createEmptyBoard();
        // White at (5,2) -> c3
        placePiece(board, 5, 2, 'white', 'pedra');
        
        // Single jump option: (4,1) to land on (3,0)
        placePiece(board, 4, 1, 'black', 'pedra');
        
        // Triple jump option: (4,3) -> land on (3,4), then (2,5) -> land on (1,6), then (2,7)? let's check exact squares
        // From (5,2) jump over (4,3) to (3,4).
        placePiece(board, 4, 3, 'black', 'pedra');
        // From (3,4) jump over (2,5) to (1,6).
        placePiece(board, 2, 5, 'black', 'pedra');
        // From (1,6) jump over (2,7) backward? Or (0,5)? Let's put black at (2,7) so from (1,6) we jump over (2,7) to (3,6) or let's check dark squares!
        // Is (1,6) a dark square? 1+6 = 7 (odd, dark square!).
        // Is (2,5) dark? 2+5 = 7 (dark square).
        // From (1,6) if black is at (2,7) (dark square), landing is (3,6)? Let's check 3+6=9 (odd!). But 3,6 + dr/dc -> (1,6)+(1,1) = (2,7). Then + (1,1) = (3,8) which is off board!
        // Instead from (1,6) let's jump over (1,5)? No diagonal is dr=-1/1, dc=-1/1.
        // From (1,6), diagonals are: (-1,-1)->(0,5), (1,-1)->(2,5 which is where we came from), (1,1)->(2,7 off board after), (-1,1)->(0,7).
        // Let's put black at (0,5) so we jump from (1,6) over (0,5)? No (0,5) is row 0. We can't land on (-1,4).
        // Let's make the triple chain from (6,3):
        return (() => {
          const b2 = createEmptyBoard();
          placePiece(b2, 6, 3, 'white', 'pedra');
          // Option 1: single capture over (5,2) -> land (4,1)
          placePiece(b2, 5, 2, 'black', 'pedra');
          // Option 2 (Majority rule): 3 captures!
          // (6,3) jumps over (5,4) -> lands on (4,5)
          placePiece(b2, 5, 4, 'black', 'pedra');
          // (4,5) jumps over (3,4) -> lands on (2,3)
          placePiece(b2, 3, 4, 'black', 'pedra');
          // (2,3) jumps over (1,4) -> lands on (0,5) [and promotes to Dama!]
          placePiece(b2, 1, 4, 'black', 'pedra');
          return b2;
        })();
      })();
    })(),
  },
  {
    id: 'captura-tras-2',
    title: 'Desafio 2: Captura Para Trás',
    difficulty: 'Iniciante',
    description: 'Em Damas Brasileiras (diferente das regras americanas/inglesas), a pedra comum PODE E DEVE capturar para trás sempre que houver oportunidade!',
    ruleHighlight: 'A pedra branca em (3,2) foi ultrapassada pelas pretas, mas como há uma peça preta na diagonal traseira (4,3) com a casa (5,4) vazia, você deve capturar para trás!',
    objective: 'Execute a captura para trás e depois continue a sequência para limpar a área.',
    initialTurn: 'white',
    boardSetup: (() => {
      const b = createEmptyBoard();
      placePiece(b, 3, 2, 'white', 'pedra');
      placePiece(b, 4, 3, 'black', 'pedra'); // backward jump to (5,4)
      placePiece(b, 6, 3, 'black', 'pedra'); // from (5,4) forward jump over (6,3) to (7,2)!
      return b;
    })(),
  },
  {
    id: 'coroacao-passagem-3',
    title: 'Desafio 3: Passagem Pela Coroação',
    difficulty: 'Intermediário',
    description: 'Regra Oficial da FBD: "Se a pedra, durante uma captura múltipla, passa pela casa de coroação (última fileira) sem parar, ela NÃO é coroada Dama, continuando sua trajetória como pedra comum."',
    ruleHighlight: 'Sua pedra começará em (2,3), saltará para a linha 0 (casa de coroação) em (0,5), mas como ainda há outra captura obrigatória para trás a partir de (0,5), ela NÃO vira Dama no meio do caminho!',
    objective: 'Complete a captura em cadeia para presenciar a regra da passagem pela coroação.',
    initialTurn: 'white',
    boardSetup: (() => {
      const b = createEmptyBoard();
      placePiece(b, 2, 3, 'white', 'pedra');
      // Jump 1: over (1,4) -> land on (0,5) (promotion row!)
      placePiece(b, 1, 4, 'black', 'pedra');
      // Jump 2 (backward from 0,5): over (1,6) -> land on (2,7)
      placePiece(b, 1, 6, 'black', 'pedra');
      return b;
    })(),
  },
  {
    id: 'dama-voadora-4',
    title: 'Desafio 4: O Poder da Dama Voadora',
    difficulty: 'Avançado',
    description: 'A Dama se movimenta e captura a qualquer distância na diagonal livre. Além disso, ao capturar uma peça, ela pode pousar em QUALQUER casa vazia além da peça capturada que permita continuar capturando em outra diagonal!',
    ruleHighlight: 'Sua Dama Branca está em (7,0). Ela vai capturar a peça preta em (4,3), pousar estrategicamente e continuar capturando na outra diagonal.',
    objective: 'Use a Dama de longo alcance para eliminar as 3 peças pretas em um único turno.',
    initialTurn: 'white',
    boardSetup: (() => {
      const b = createEmptyBoard();
      placePiece(b, 7, 0, 'white', 'dama');
      placePiece(b, 4, 3, 'black', 'pedra'); // jump over (4,3) to (3,4) or (2,5)
      // From (2,5), jump over (1,4) to (0,3)
      placePiece(b, 1, 4, 'black', 'pedra');
      // From (0,3), jump over (1,2) to (2,1)
      placePiece(b, 1, 2, 'black', 'pedra');
      return b;
    })(),
  },
  {
    id: 'golpe-tatico-5',
    title: 'Desafio 5: Golpe de Mestre (Sacrifício e Vitória)',
    difficulty: 'Oficial',
    description: 'Em torneios oficiais da Federação Brasileira de Damas, o sacrifício estratégico de uma ou mais pedras para forçar a Lei da Maioria no adversário e abrir caminho para a coroação é a tática mais refinada.',
    ruleHighlight: 'Você tem uma pedra branca pronta para abrir um buraco na defesa adversária. Observe como a captura obrigatória força as pretas a aceitarem o sacrifício, deixando o caminho livre!',
    objective: 'Ganhe a partida utilizando a tática de bloqueio e captura.',
    initialTurn: 'white',
    boardSetup: (() => {
      const b = createEmptyBoard();
      placePiece(b, 5, 2, 'white', 'pedra');
      placePiece(b, 5, 4, 'white', 'pedra');
      placePiece(b, 4, 3, 'black', 'pedra');
      placePiece(b, 2, 3, 'black', 'pedra');
      placePiece(b, 2, 5, 'black', 'pedra');
      return b;
    })(),
  },
];
