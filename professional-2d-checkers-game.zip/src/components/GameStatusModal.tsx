import React, { useEffect } from 'react';
import { Trophy, Handshake, RotateCcw, Search, ArrowRight } from 'lucide-react';
import confetti from 'canvas-confetti';
import { GameMode, PlayerColor } from '../types/game';

interface GameStatusModalProps {
  status: 'won' | 'draw';
  winner: PlayerColor | null;
  winReason: string | null;
  gameMode: GameMode;
  totalMoves: number;
  onPlayAgain: () => void;
  onReviewBoard: () => void;
  onChangeMode: () => void;
}

export const GameStatusModal: React.FC<GameStatusModalProps> = ({
  status,
  winner,
  winReason,
  gameMode,
  totalMoves,
  onPlayAgain,
  onReviewBoard,
  onChangeMode,
}) => {
  useEffect(() => {
    if (status === 'won') {
      try {
        confetti({
          particleCount: 100,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#f59e0b', '#3b82f6', '#10b981', '#ef4444'],
        });
      } catch {
        // Confetti failed
      }
    }
  }, [status]);

  const getTitle = () => {
    if (status === 'draw') return 'Empate Declarado!';
    if (gameMode === 'ai') {
      return winner === 'white' ? 'Vitória Triunfal!' : 'Vitória do Robô!';
    }
    return winner === 'white' ? 'Vitória das Brancas!' : 'Vitória das Pretas!';
  };

  const getSubtitle = () => {
    if (status === 'draw') return 'Uma partida equilibrada e tática de alto nível!';
    if (gameMode === 'ai') {
      return winner === 'white'
        ? 'Você derrotou o Robô seguindo as Regras Oficiais da FBD!'
        : 'O Robô IA dominou o tabuleiro nesta partida!';
    }
    return `O Jogador com as peças ${winner === 'white' ? 'Brancas' : 'Pretas'} conquistou a vitória!`;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div className="bg-gradient-to-b from-slate-900 via-slate-900 to-slate-950 border border-slate-800 rounded-3xl shadow-2xl max-w-md w-full p-6 sm:p-8 text-center space-y-6 relative overflow-hidden">
        
        {/* Glow backdrop behind icon */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-48 bg-amber-500/20 rounded-full blur-3xl pointer-events-none" />

        {/* Icon Header */}
        <div className="inline-flex items-center justify-center w-20 h-20 rounded-3xl bg-gradient-to-br from-amber-500 via-amber-600 to-amber-700 shadow-xl shadow-amber-500/25 border-2 border-amber-400/40 transform scale-105">
          {status === 'won' ? (
            <Trophy className="w-10 h-10 text-slate-950 stroke-[2.5]" />
          ) : (
            <Handshake className="w-10 h-10 text-slate-950 stroke-[2.5]" />
          )}
        </div>

        {/* Titles & Reason */}
        <div className="space-y-2">
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight font-serif-title">
            {getTitle()}
          </h2>
          <p className="text-xs sm:text-sm font-semibold text-amber-400">
            {getSubtitle()}
          </p>
          {winReason && (
            <div className="mt-3 p-3 rounded-2xl bg-slate-950/80 border border-slate-800/80 text-xs text-slate-300 leading-relaxed font-mono">
              {winReason}
            </div>
          )}
        </div>

        {/* Stats Summary */}
        <div className="grid grid-cols-2 gap-2.5 py-2">
          <div className="p-3 rounded-2xl bg-slate-950/60 border border-slate-800 text-center">
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block">
              Total de Lances
            </span>
            <span className="text-lg font-mono font-extrabold text-white">
              {totalMoves}
            </span>
          </div>
          <div className="p-3 rounded-2xl bg-slate-950/60 border border-slate-800 text-center">
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block">
              Regulamento
            </span>
            <span className="text-sm font-extrabold text-amber-400 mt-0.5 block">
              Damas 64 FBD
            </span>
          </div>
        </div>

        {/* Buttons Action Group */}
        <div className="space-y-2.5 pt-2">
          <button
            onClick={onPlayAgain}
            className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-amber-500 via-amber-600 to-amber-700 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-extrabold text-sm transition-all shadow-lg shadow-amber-500/25 flex items-center justify-center gap-2"
          >
            <RotateCcw className="w-4 h-4 stroke-[2.5]" />
            <span>Jogar Novamente</span>
          </button>

          <button
            onClick={onReviewBoard}
            className="w-full py-3 px-6 rounded-2xl bg-slate-800 hover:bg-slate-750 text-slate-200 font-bold text-xs transition-all border border-slate-700/80 flex items-center justify-center gap-2"
          >
            <Search className="w-4 h-4 text-slate-400" />
            <span>Ver / Analisar Tabuleiro Final</span>
          </button>

          <button
            onClick={onChangeMode}
            className="w-full py-2.5 px-6 rounded-2xl bg-transparent hover:bg-slate-900 text-slate-400 hover:text-white font-medium text-xs transition-all flex items-center justify-center gap-1.5"
          >
            <span>Trocar Modo de Jogo ou Desafio</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
