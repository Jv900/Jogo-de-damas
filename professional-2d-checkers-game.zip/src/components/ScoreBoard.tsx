import React from 'react';
import { Crown, Circle, ShieldAlert, Zap, Bot, User } from 'lucide-react';
import { AIDifficulty, BoardPiece, GameMode, GameSettings, MoveOption, PlayerColor } from '../types/game';
import { countPieces } from '../rules/damasEngine';

interface ScoreBoardProps {
  board: (BoardPiece | null)[][];
  currentTurn: PlayerColor;
  gameMode: GameMode;
  settings: GameSettings;
  onUpdateSettings: (newSettings: Partial<GameSettings>) => void;
  mandatoryMoves: MoveOption[];
  multiCaptureInProgress: boolean;
  timers?: { white: number; black: number };
}

export const ScoreBoard: React.FC<ScoreBoardProps> = ({
  board,
  currentTurn,
  gameMode,
  settings,
  onUpdateSettings,
  mandatoryMoves,
  multiCaptureInProgress,
  timers,
}) => {
  const counts = countPieces(board);

  const formatTime = (seconds?: number) => {
    if (seconds === undefined || settings.timerMode === 'none') return null;
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  const getPlayerLabel = (color: PlayerColor) => {
    if (gameMode === 'ai') {
      if (color === settings.aiPlayerColor) {
        const diffNames: Record<string, string> = {
          easy: 'Robô (Fácil)',
          medium: 'Robô (Médio)',
          hard: 'Robô (Difícil)',
          master: 'Robô (Mestre FBD)',
        };
        return diffNames[settings.aiDifficulty] || 'Robô IA';
      }
      return 'Você (Brancas)';
    }
    if (gameMode === 'puzzle') {
      return color === 'white' ? 'Sua Vez (Desafio)' : 'Defesa do Desafio';
    }
    return color === 'white' ? 'Jogador 1 (Brancas)' : 'Jogador 2 (Pretas)';
  };

  const hasMandatoryCapture = mandatoryMoves.length > 0 && mandatoryMoves[0].isCapture;
  const majorityCaptureCount = hasMandatoryCapture ? mandatoryMoves[0].captureCount : 0;

  const aiLevels: { id: AIDifficulty; label: string; badge: string }[] = [
    { id: 'easy', label: 'Fácil', badge: 'Iniciante' },
    { id: 'medium', label: 'Médio', badge: 'Intermediário' },
    { id: 'hard', label: 'Difícil', badge: 'Avançado' },
    { id: 'master', label: 'Mestre', badge: 'Oficial FBD' },
  ];

  return (
    <div className="w-full space-y-3">
      {/* Turn Indicator Banner - High Contrast & Large */}
      <div
        className={`w-full py-3 px-4 sm:px-5 rounded-2xl flex items-center justify-between border-2 shadow-xl transition-all duration-300 ${
          multiCaptureInProgress
            ? 'bg-amber-950/90 border-amber-500 text-amber-200 animate-pulse'
            : currentTurn === 'white'
            ? 'bg-gradient-to-r from-slate-900 via-slate-850 to-slate-900 border-amber-400 text-white shadow-amber-500/20'
            : 'bg-gradient-to-r from-slate-900 via-zinc-900 to-slate-900 border-indigo-400 text-white shadow-indigo-500/20'
        }`}
      >
        <div className="flex items-center gap-3.5">
          <div
            className={`w-5 h-5 rounded-full flex items-center justify-center border-[3px] shrink-0 ${
              currentTurn === 'white'
                ? 'bg-white border-slate-300 shadow-[0_0_15px_rgba(255,255,255,0.9)] scale-110'
                : 'bg-zinc-800 border-zinc-500 shadow-[0_0_15px_rgba(100,116,139,0.9)] scale-110'
            }`}
          />
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[11px] sm:text-xs font-bold uppercase tracking-widest text-amber-300">
                TURNO ATUAL:
              </span>
              <span className="text-base sm:text-lg font-black tracking-tight text-white">
                {getPlayerLabel(currentTurn)}
              </span>
            </div>
            {multiCaptureInProgress && (
              <span className="text-xs font-bold text-amber-400 flex items-center gap-1.5 mt-0.5">
                <Zap className="w-3.5 h-3.5 text-amber-400 animate-bounce shrink-0" />
                <span>Captura múltipla em andamento! Toque na próxima casa da sequência.</span>
              </span>
            )}
          </div>
        </div>

        {/* Mandatory Capture / Majority Rule Warning Badge (Desktop) */}
        {hasMandatoryCapture && !multiCaptureInProgress && (
          <div className="hidden sm:flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-rose-600/30 border-2 border-rose-500/80 text-rose-200 text-xs font-black shadow-lg animate-pulse shrink-0">
            <ShieldAlert className="w-4 h-4 text-rose-400" />
            <span>
              Captura Obrigatória ({majorityCaptureCount} {majorityCaptureCount === 1 ? 'peça' : 'peças'})
            </span>
          </div>
        )}
      </div>

      {/* Mobile Mandatory Capture Banner */}
      {hasMandatoryCapture && !multiCaptureInProgress && (
        <div className="sm:hidden w-full flex items-center justify-center gap-2 py-2 px-3 rounded-xl bg-rose-600/30 border-2 border-rose-500/80 text-rose-200 text-xs font-black shadow-md animate-pulse">
          <ShieldAlert className="w-4 h-4 text-rose-400 shrink-0" />
          <span>
            Lei da Maioria — Obrigatório capturar {majorityCaptureCount} {majorityCaptureCount === 1 ? 'peça' : 'peças'}!
          </span>
        </div>
      )}

      {/* AI Difficulty Selector - Directly Visible on Main Interface */}
      {gameMode === 'ai' && (
        <div className="bg-slate-900/95 border border-slate-800 rounded-2xl p-3 shadow-lg">
          <div className="flex items-center justify-between mb-2 px-1">
            <div className="flex items-center gap-1.5 text-xs font-bold text-amber-400">
              <Bot className="w-4 h-4 text-amber-400" />
              <span>Nível do Robô IA:</span>
            </div>
            <span className="text-[11px] text-slate-400 font-medium">Toque para trocar de nível</span>
          </div>
          <div className="grid grid-cols-4 gap-1.5 sm:gap-2">
            {aiLevels.map(lvl => {
              const isSelected = settings.aiDifficulty === lvl.id;
              return (
                <button
                  key={lvl.id}
                  onClick={() => onUpdateSettings({ aiDifficulty: lvl.id })}
                  className={`py-2 px-1.5 sm:px-3 rounded-xl text-center transition-all flex flex-col items-center justify-center border min-h-[46px] ${
                    isSelected
                      ? 'bg-gradient-to-b from-amber-500 to-amber-600 border-amber-300 text-slate-950 font-black shadow-md shadow-amber-500/25 scale-[1.02]'
                      : 'bg-slate-950/80 hover:bg-slate-800 border-slate-800 text-slate-300 font-semibold'
                  }`}
                  title={`Trocar dificuldade para ${lvl.label} (${lvl.badge})`}
                >
                  <span className="text-xs sm:text-sm tracking-tight leading-none mb-0.5">
                    {lvl.label}
                  </span>
                  <span className={`text-[9px] sm:text-[10px] leading-none uppercase tracking-wide font-mono ${isSelected ? 'text-slate-900 font-extrabold' : 'text-slate-500'}`}>
                    {lvl.badge}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Player Score Cards Panel - Large Crisp Counters */}
      <div className="grid grid-cols-2 gap-3">
        {/* White Player Panel */}
        <div
          className={`p-3.5 sm:p-4 rounded-2xl border-2 transition-all ${
            currentTurn === 'white'
              ? 'bg-slate-900/95 border-amber-400 shadow-lg shadow-amber-500/15 ring-2 ring-amber-400/20'
              : 'bg-slate-900/50 border-slate-800 opacity-85'
          }`}
        >
          <div className="flex items-center justify-between mb-2.5">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-white/10 border border-white/20 flex items-center justify-center shrink-0">
                <User className="w-4.5 h-4.5 text-white" />
              </div>
              <span className="text-sm sm:text-base font-extrabold text-white truncate">
                {getPlayerLabel('white')}
              </span>
            </div>
            {settings.timerMode !== 'none' && timers && (
              <span className={`text-xs font-mono font-bold px-2.5 py-1 rounded-lg ${timers.white < 30 ? 'bg-rose-500/25 text-rose-300 animate-pulse' : 'bg-slate-800 text-slate-200'}`}>
                {formatTime(timers.white)}
              </span>
            )}
          </div>

          <div className="flex items-center justify-between pt-2 border-t border-slate-800/80">
            <div className="flex items-center gap-4">
              <span className="flex items-center gap-1.5 text-slate-200" title="Pedras comuns restantes">
                <Circle className="w-3.5 h-3.5 fill-white text-white" />
                <span className="text-base sm:text-lg font-black font-mono">{counts.whitePedras}</span>
              </span>
              <span className="flex items-center gap-1.5 text-amber-300" title="Damas coroadas restantes">
                <Crown className="w-4 h-4 text-amber-400 fill-amber-400" />
                <span className="text-base sm:text-lg font-black font-mono">{counts.whiteDamas}</span>
              </span>
            </div>
            <div className="text-xs sm:text-sm font-black text-slate-100 bg-slate-800/90 px-2.5 py-1 rounded-xl border border-slate-700/60 shadow-inner">
              Peças: {counts.whiteTotal}
            </div>
          </div>
        </div>

        {/* Black Player Panel */}
        <div
          className={`p-3.5 sm:p-4 rounded-2xl border-2 transition-all ${
            currentTurn === 'black'
              ? 'bg-slate-900/95 border-indigo-400 shadow-lg shadow-indigo-500/15 ring-2 ring-indigo-400/20'
              : 'bg-slate-900/50 border-slate-800 opacity-85'
          }`}
        >
          <div className="flex items-center justify-between mb-2.5">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-zinc-800 border border-zinc-700 flex items-center justify-center shrink-0">
                {gameMode === 'ai' ? (
                  <Bot className="w-4.5 h-4.5 text-indigo-400" />
                ) : (
                  <User className="w-4.5 h-4.5 text-indigo-400" />
                )}
              </div>
              <span className="text-sm sm:text-base font-extrabold text-white truncate">
                {getPlayerLabel('black')}
              </span>
            </div>
            {settings.timerMode !== 'none' && timers && (
              <span className={`text-xs font-mono font-bold px-2.5 py-1 rounded-lg ${timers.black < 30 ? 'bg-rose-500/25 text-rose-300 animate-pulse' : 'bg-slate-800 text-slate-200'}`}>
                {formatTime(timers.black)}
              </span>
            )}
          </div>

          <div className="flex items-center justify-between pt-2 border-t border-slate-800/80">
            <div className="flex items-center gap-4">
              <span className="flex items-center gap-1.5 text-slate-200" title="Pedras comuns restantes">
                <Circle className="w-3.5 h-3.5 fill-zinc-600 text-zinc-500" />
                <span className="text-base sm:text-lg font-black font-mono">{counts.blackPedras}</span>
              </span>
              <span className="flex items-center gap-1.5 text-amber-300" title="Damas coroadas restantes">
                <Crown className="w-4 h-4 text-amber-400 fill-amber-400" />
                <span className="text-base sm:text-lg font-black font-mono">{counts.blackDamas}</span>
              </span>
            </div>
            <div className="text-xs sm:text-sm font-black text-slate-100 bg-slate-800/90 px-2.5 py-1 rounded-xl border border-slate-700/60 shadow-inner">
              Peças: {counts.blackTotal}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
