import React from 'react';
import { Sparkles, Trophy, ArrowRight } from 'lucide-react';
import { PuzzleChallenge } from '../types/game';
import { PUZZLE_CHALLENGES } from '../rules/puzzleLibrary';

interface PuzzleSelectorProps {
  onSelectChallenge: (challenge: PuzzleChallenge) => void;
  activeChallengeId?: string;
  onExitPuzzleMode: () => void;
}

export const PuzzleSelector: React.FC<PuzzleSelectorProps> = ({
  onSelectChallenge,
  activeChallengeId,
  onExitPuzzleMode,
}) => {
  const getBadgeColor = (diff: string) => {
    switch (diff) {
      case 'Iniciante':
        return 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30';
      case 'Intermediário':
        return 'bg-amber-500/20 text-amber-300 border-amber-500/30';
      case 'Avançado':
        return 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30';
      default:
        return 'bg-rose-500/20 text-rose-300 border-rose-500/30';
    }
  };

  return (
    <div className="max-w-5xl mx-auto p-4 sm:p-6 space-y-6 animate-fadeIn">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-6 bg-gradient-to-r from-slate-900 via-slate-900 to-slate-950 border border-slate-800 rounded-3xl shadow-xl">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-500 via-amber-600 to-amber-700 flex items-center justify-center shadow-lg shadow-amber-500/20 border border-amber-400/30">
            <Sparkles className="w-6 h-6 text-slate-950 stroke-[2.5]" />
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-white font-serif-title flex items-center gap-2">
              Desafios Táticos & Regras FBD
            </h2>
            <p className="text-xs sm:text-sm text-slate-400 mt-0.5">
              Pratique e domine as peculiaridades e capturas obrigatórias das Regras Oficiais Brasileiras.
            </p>
          </div>
        </div>

        <button
          onClick={onExitPuzzleMode}
          className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-200 text-xs font-semibold border border-slate-700 transition-all"
        >
          Voltar a Partida Livre
        </button>
      </div>

      {/* Grid of Challenges */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {PUZZLE_CHALLENGES.map(challenge => {
          const isActive = activeChallengeId === challenge.id;

          return (
            <div
              key={challenge.id}
              onClick={() => onSelectChallenge(challenge)}
              className={`p-5 rounded-3xl border transition-all duration-200 flex flex-col justify-between cursor-pointer group ${
                isActive
                  ? 'bg-slate-900/95 border-amber-500/80 shadow-xl shadow-amber-500/10 ring-2 ring-amber-500/20'
                  : 'bg-slate-900/60 border-slate-800/80 hover:bg-slate-900 hover:border-slate-700 shadow-md'
              }`}
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-3">
                  <span className={`text-[11px] font-bold px-2.5 py-1 rounded-full border ${getBadgeColor(challenge.difficulty)}`}>
                    {challenge.difficulty}
                  </span>
                  <span className="text-[11px] font-mono text-slate-400">
                    Turno inicial: {challenge.initialTurn === 'white' ? 'Brancas' : 'Pretas'}
                  </span>
                </div>

                <h3 className="text-base font-bold text-white group-hover:text-amber-400 transition-colors mb-2">
                  {challenge.title}
                </h3>

                <p className="text-xs text-slate-300 leading-relaxed mb-3">
                  {challenge.description}
                </p>

                <div className="p-3 rounded-2xl bg-slate-950/80 border border-slate-800 text-xs text-amber-200/90 leading-relaxed mb-4">
                  <strong className="font-bold text-amber-400 block mb-1">Dica da Regra:</strong>
                  {challenge.ruleHighlight}
                </div>
              </div>

              <div className="flex items-center justify-between pt-3 border-t border-slate-800/80">
                <div className="flex items-center gap-1.5 text-xs font-bold text-slate-300">
                  <Trophy className="w-4 h-4 text-amber-400" />
                  <span>{challenge.objective}</span>
                </div>

                <button className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 group-hover:from-amber-400 group-hover:to-amber-500 text-slate-950 text-xs font-bold transition-all shadow-sm">
                  <span>Jogar</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
