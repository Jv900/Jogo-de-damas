import React from 'react';
import { Crown, Zap, Target } from 'lucide-react';
import { BoardPiece, BoardTheme, MoveOption, PieceStyle, PlayerColor, Position } from '../types/game';
import { BOARD_SIZE, isDarkSquare } from '../rules/damasEngine';

interface CheckersBoardProps {
  board: (BoardPiece | null)[][];
  currentTurn: PlayerColor;
  selectedPos: Position | null;
  validMovesForSelected: MoveOption[];
  allMandatoryMoves: MoveOption[];
  capturedInCurrentTurn: Position[];
  onSquareClick: (row: number, col: number) => void;
  boardTheme: BoardTheme;
  pieceStyle: PieceStyle;
  showValidMoves: boolean;
  isFlipped?: boolean;
}

export const CheckersBoard: React.FC<CheckersBoardProps> = ({
  board,
  selectedPos,
  validMovesForSelected,
  allMandatoryMoves,
  capturedInCurrentTurn,
  onSquareClick,
  boardTheme,
  pieceStyle,
  showValidMoves,
}) => {
  // Theme color maps with high contrast borders and authentic textures
  const themeStyles: Record<BoardTheme, { frame: string; darkSquare: string; lightSquare: string }> = {
    classic: {
      frame: 'wood-frame border-[#3a2218] shadow-[0_25px_60px_rgba(0,0,0,0.85)]',
      darkSquare: 'bg-[#5c3a21] hover:bg-[#6c4427]',
      lightSquare: 'bg-[#e6c594]',
    },
    emerald: {
      frame: 'bg-gradient-to-br from-slate-900 via-emerald-950 to-slate-900 border-emerald-600/40 shadow-[0_25px_60px_rgba(4,120,87,0.35)]',
      darkSquare: 'bg-[#0f5132] hover:bg-[#13653f]',
      lightSquare: 'bg-[#d1e7dd]',
    },
    royal: {
      frame: 'bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 border-indigo-600/40 shadow-[0_25px_60px_rgba(67,56,202,0.35)]',
      darkSquare: 'bg-[#311b92] hover:bg-[#3d23b5]',
      lightSquare: 'bg-[#ede7f6]',
    },
    midnight: {
      frame: 'bg-gradient-to-br from-zinc-950 via-slate-900 to-black border-slate-700/60 shadow-[0_25px_60px_rgba(0,0,0,0.95)]',
      darkSquare: 'bg-slate-800 hover:bg-slate-750',
      lightSquare: 'bg-slate-300',
    },
    walnut: {
      frame: 'bg-gradient-to-br from-[#2b1810] to-[#1a0e09] border-[#5c3a21]/60 shadow-[0_25px_60px_rgba(0,0,0,0.85)]',
      darkSquare: 'bg-[#3d2314] hover:bg-[#4a2b19]',
      lightSquare: 'bg-[#c8a97e]',
    },
  };

  const getPieceStyleClass = (color: PlayerColor) => {
    if (pieceStyle === 'red_white') {
      return color === 'white' ? 'piece-white' : 'piece-red';
    }
    if (pieceStyle === 'gold_obsidian') {
      return color === 'white' ? 'piece-gold' : 'piece-black';
    }
    // classic_ivory_ebony
    return color === 'white' ? 'piece-white' : 'piece-black';
  };

  const activeTheme = themeStyles[boardTheme] || themeStyles.classic;

  const colLabels = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'];
  const rowLabels = ['8', '7', '6', '5', '4', '3', '2', '1'];

  // Check if a square has a piece that MUST move (mandatory capture piece)
  const isMandatoryPiece = (r: number, c: number) => {
    return allMandatoryMoves.some(m => m.from.row === r && m.from.col === c && m.isCapture);
  };

  return (
    <div className="w-full flex flex-col items-center justify-center select-none py-1 sm:py-2">
      {/* Board Outer Container - LARGE and Centered */}
      <div className={`p-2 sm:p-4 md:p-5 rounded-3xl border-[3px] sm:border-[4px] ${activeTheme.frame} transition-all duration-300 relative max-w-[660px] sm:max-w-[720px] md:max-w-[780px] lg:max-w-[820px] w-full aspect-square flex flex-col justify-between mx-auto shadow-2xl`}>
        
        {/* Top Letters Column Header (A-H) */}
        <div className="grid grid-cols-8 pb-1 sm:pb-2 text-center text-xs sm:text-sm font-extrabold font-mono text-amber-200/90 tracking-wider">
          {colLabels.map((label, idx) => (
            <span key={idx} className="flex items-center justify-center">
              {label}
            </span>
          ))}
        </div>

        {/* Board 8x8 Grid with Side Number Labels (1-8) */}
        <div className="flex flex-1 relative rounded-2xl overflow-hidden border-2 sm:border-4 border-black/50 shadow-inner bg-black/70">
          {/* Left Side Row Numbers */}
          <div className="flex flex-col justify-around px-1 sm:px-2.5 bg-black/50 text-xs sm:text-sm font-extrabold font-mono text-amber-200/90">
            {rowLabels.map((label, idx) => (
              <span key={idx} className="flex items-center justify-center h-full">
                {label}
              </span>
            ))}
          </div>

          {/* Actual 64 Squares Grid - FIXED ORIENTATION */}
          <div className="grid grid-cols-8 grid-rows-8 flex-1 aspect-square">
            {Array.from({ length: BOARD_SIZE }).map((_, rIdx) => {
              const r = rIdx;
              return Array.from({ length: BOARD_SIZE }).map((_, cIdx) => {
                const c = cIdx;
                const piece = board[r][c];
                const isDark = isDarkSquare(r, c);
                const isSelected = selectedPos?.row === r && selectedPos?.col === c;
                const validMove = validMovesForSelected.find(m => m.to.row === r && m.to.col === c);
                const isJumpedInTurn = capturedInCurrentTurn.some(p => p.row === r && p.col === c);
                const mustCapture = isMandatoryPiece(r, c);

                return (
                  <div
                    key={`${r}-${c}`}
                    onClick={() => onSquareClick(r, c)}
                    className={`relative w-full h-full flex items-center justify-center transition-colors duration-150 cursor-pointer ${
                      isDark ? activeTheme.darkSquare : activeTheme.lightSquare
                    } ${
                      isSelected
                        ? 'ring-4 sm:ring-6 ring-inset ring-amber-400 bg-amber-500/30 shadow-inner'
                        : validMove && showValidMoves
                        ? 'ring-2 sm:ring-4 ring-inset ring-emerald-400/90 bg-emerald-500/25'
                        : ''
                    }`}
                  >
                    {/* Square coordinate text in corner of each dark square on larger screens */}
                    {isDark && (
                      <span className="absolute top-0.5 left-1 text-[8px] sm:text-[10px] font-mono text-white/35 font-semibold hidden md:block pointer-events-none">
                        {colLabels[c]}{rowLabels[r]}
                      </span>
                    )}

                    {/* Valid Target Move Marker - LARGE and easy to tap */}
                    {validMove && showValidMoves && !piece && (
                      <div className="absolute inset-0 flex items-center justify-center pointer-events-none animate-pulse z-10">
                        {validMove.isCapture ? (
                          <div className="w-8 h-8 sm:w-11 sm:h-11 rounded-full border-2 sm:border-[3px] border-rose-500 bg-rose-500/35 flex items-center justify-center shadow-lg shadow-rose-500/50 scale-105 sm:scale-110">
                            <Target className="w-5 h-5 sm:w-6 sm:h-6 text-rose-200 animate-spin" />
                          </div>
                        ) : (
                          <div className="w-5 h-5 sm:w-7 sm:h-7 rounded-full bg-emerald-400/90 shadow-[0_0_16px_rgba(52,211,153,1)] border-2 sm:border-[3px] border-white/80" />
                        )}
                      </div>
                    )}

                    {/* Piece Rendering - LARGE PIECES (86% of square size) */}
                    {piece && (
                      <div
                        className={`w-[84%] h-[84%] sm:w-[86%] sm:h-[86%] rounded-full relative flex items-center justify-center transition-all duration-200 ${getPieceStyleClass(
                          piece.color
                        )} ${
                          isSelected
                            ? 'scale-110 shadow-[0_0_25px_rgba(251,191,36,0.95)] z-20 ring-2 sm:ring-4 ring-amber-300'
                            : 'hover:scale-105 shadow-lg'
                        } ${
                          isJumpedInTurn
                            ? 'opacity-35 filter grayscale scale-85 border-2 border-dashed border-rose-500'
                            : ''
                        }`}
                      >
                        {/* Mandatory Capture Ring Indicator */}
                        {mustCapture && !isSelected && (
                          <div className="absolute -inset-1 sm:-inset-1.5 rounded-full border-[3px] border-rose-500 animate-pulse-ring pointer-events-none z-10 shadow-[0_0_10px_rgba(244,63,94,0.8)]" />
                        )}

                        {/* Inner concentric ring texture to simulate real Checkers/Damas chips */}
                        <div className="w-[68%] h-[68%] rounded-full border sm:border-2 border-black/20 dark:border-white/25 flex items-center justify-center relative">
                          {/* Dama Crown Badge */}
                          {piece.type === 'dama' ? (
                            <div className="flex items-center justify-center dama-glow transform scale-125 sm:scale-135">
                              <Crown
                                className={`w-5 h-5 sm:w-7 sm:h-7 stroke-[2.5] ${
                                  piece.color === 'white'
                                    ? 'text-amber-500 fill-amber-400'
                                    : 'text-amber-400 fill-amber-300'
                                }`}
                              />
                            </div>
                          ) : (
                            /* Normal Pedra Center Indentation */
                            <div className="w-[46%] h-[46%] rounded-full bg-black/10 dark:bg-white/15 shadow-inner" />
                          )}
                        </div>

                        {/* Jumped piece indicator cross */}
                        {isJumpedInTurn && (
                          <div className="absolute inset-0 flex items-center justify-center bg-rose-950/70 rounded-full">
                            <Zap className="w-6 h-6 sm:w-8 sm:h-8 text-rose-400 animate-bounce" />
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                );
              });
            })}
          </div>

          {/* Right Side Row Numbers */}
          <div className="flex flex-col justify-around px-1 sm:px-2.5 bg-black/50 text-xs sm:text-sm font-extrabold font-mono text-amber-200/90">
            {rowLabels.map((label, idx) => (
              <span key={idx} className="flex items-center justify-center h-full">
                {label}
              </span>
            ))}
          </div>
        </div>

        {/* Bottom Letters Column Footer */}
        <div className="grid grid-cols-8 pt-1 sm:pt-2 text-center text-xs sm:text-sm font-extrabold font-mono text-amber-200/90 tracking-wider">
          {colLabels.map((label, idx) => (
            <span key={idx} className="flex items-center justify-center">
              {label}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
};
