import React from 'react';
import { History, Zap, Crown, ChevronRight, Download } from 'lucide-react';
import { BoardPiece, HistoryEntry } from '../types/game';

interface MoveHistoryProps {
  history: HistoryEntry[];
  onSelectSnapshot?: (board: (BoardPiece | null)[][]) => void;
  onExportPGN?: () => void;
}

export const MoveHistory: React.FC<MoveHistoryProps> = ({
  history,
  onSelectSnapshot,
  onExportPGN,
}) => {
  // Group moves into turns (Turn 1: White move, Black move)
  const turns: { turnNum: number; white?: HistoryEntry; black?: HistoryEntry }[] = [];
  
  history.forEach(entry => {
    let turn = turns.find(t => t.turnNum === entry.turnNumber);
    if (!turn) {
      turn = { turnNum: entry.turnNumber };
      turns.push(turn);
    }
    if (entry.color === 'white') {
      turn.white = entry;
    } else {
      turn.black = entry;
    }
  });

  return (
    <div className="w-full bg-slate-900/90 rounded-2xl border border-slate-800/80 p-4 shadow-lg flex flex-col h-full max-h-[420px] sm:max-h-[520px]">
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-800/80 mb-3">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-lg bg-amber-500/10 border border-amber-500/20">
            <History className="w-4 h-4 text-amber-400" />
          </div>
          <h3 className="text-sm font-bold text-white tracking-tight">
            Histórico da Partida
          </h3>
        </div>
        {onExportPGN && history.length > 0 && (
          <button
            onClick={onExportPGN}
            className="flex items-center gap-1 px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-750 text-[11px] font-semibold text-slate-300 border border-slate-700/80 transition-all"
            title="Copiar notação da partida"
          >
            <Download className="w-3 h-3 text-amber-400" />
            <span>Copiar PGN</span>
          </button>
        )}
      </div>

      {/* Moves Table List */}
      {history.length === 0 ? (
        <div className="flex-1 flex flex-col items-center justify-center py-10 text-center text-slate-500 text-xs">
          <History className="w-8 h-8 stroke-1 text-slate-600 mb-2 opacity-50" />
          <p>Nenhum movimento registrado.</p>
          <p className="text-[11px] text-slate-600 mt-0.5">Faça a sua primeira jogada no tabuleiro!</p>
        </div>
      ) : (
        <div className="flex-1 overflow-y-auto space-y-1.5 pr-1">
          {turns.map(turn => (
            <div
              key={turn.turnNum}
              className="grid grid-cols-[38px_1fr_1fr] gap-1.5 items-center p-1.5 rounded-xl bg-slate-950/60 border border-slate-800/60 text-xs font-mono"
            >
              {/* Turn Number */}
              <div className="text-slate-500 font-bold text-center border-r border-slate-800 pr-1">
                {turn.turnNum}.
              </div>

              {/* White Move */}
              {turn.white ? (
                <button
                  onClick={() => onSelectSnapshot?.(turn.white!.boardSnapshot)}
                  className="flex items-center justify-between px-2 py-1 rounded-lg bg-slate-900/80 hover:bg-slate-800 text-slate-200 border border-slate-800/80 transition-all group"
                  title="Clique para rever esta posição"
                >
                  <span className="font-semibold group-hover:text-amber-300 transition-colors">
                    {turn.white.notation}
                  </span>
                  <div className="flex items-center gap-1">
                    {turn.white.capturedCount > 0 && (
                      <span className="flex items-center text-[10px] bg-rose-500/20 text-rose-300 px-1 py-0.2 rounded font-sans">
                        <Zap className="w-2.5 h-2.5 mr-0.5 text-rose-400" />
                        {turn.white.capturedCount}
                      </span>
                    )}
                    {turn.white.promoted && (
                      <Crown className="w-3 h-3 text-amber-400 fill-amber-400" />
                    )}
                  </div>
                </button>
              ) : (
                <div className="text-slate-600 text-center py-1">—</div>
              )}

              {/* Black Move */}
              {turn.black ? (
                <button
                  onClick={() => onSelectSnapshot?.(turn.black!.boardSnapshot)}
                  className="flex items-center justify-between px-2 py-1 rounded-lg bg-slate-900/80 hover:bg-slate-800 text-slate-200 border border-slate-800/80 transition-all group"
                  title="Clique para rever esta posição"
                >
                  <span className="font-semibold group-hover:text-amber-300 transition-colors">
                    {turn.black.notation}
                  </span>
                  <div className="flex items-center gap-1">
                    {turn.black.capturedCount > 0 && (
                      <span className="flex items-center text-[10px] bg-rose-500/20 text-rose-300 px-1 py-0.2 rounded font-sans">
                        <Zap className="w-2.5 h-2.5 mr-0.5 text-rose-400" />
                        {turn.black.capturedCount}
                      </span>
                    )}
                    {turn.black.promoted && (
                      <Crown className="w-3 h-3 text-amber-400 fill-amber-400" />
                    )}
                  </div>
                </button>
              ) : (
                <div className="text-slate-600 text-center py-1">—</div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Footer Info */}
      <div className="mt-3 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
        <span>Total de Lances: <strong className="text-slate-200 font-mono">{history.length}</strong></span>
        <span className="flex items-center gap-1 text-amber-400">
          <span>Notação Padrão</span>
          <ChevronRight className="w-3 h-3" />
        </span>
      </div>
    </div>
  );
};
