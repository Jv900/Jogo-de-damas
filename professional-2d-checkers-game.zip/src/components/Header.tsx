import React from 'react';
import { Bot, Users, BookOpen, Settings, Volume2, VolumeX, Sparkles, Trophy } from 'lucide-react';
import { GameMode, GameSettings } from '../types/game';

interface HeaderProps {
  gameMode: GameMode;
  onSelectMode: (mode: GameMode) => void;
  settings: GameSettings;
  onUpdateSettings: (newSettings: Partial<GameSettings>) => void;
  onOpenRules: () => void;
  onOpenSettings: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  gameMode,
  onSelectMode,
  settings,
  onUpdateSettings,
  onOpenRules,
  onOpenSettings,
}) => {
  return (
    <header className="border-b border-slate-800/80 bg-slate-900/90 backdrop-blur-md sticky top-0 z-40 shadow-xl">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-3">
        {/* Brand & Title */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 via-amber-600 to-amber-700 flex items-center justify-center shadow-lg shadow-amber-500/20 border border-amber-400/30">
            <Trophy className="w-5 h-5 text-slate-950 stroke-[2.5]" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg sm:text-xl font-bold tracking-tight text-white font-serif-title">
                DAMAS <span className="text-amber-400">OFICIAL</span>
              </h1>
              <span className="hidden sm:inline-block px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider bg-amber-500/10 text-amber-300 rounded-full border border-amber-500/20">
                FBD 64
              </span>
            </div>
            <p className="text-[11px] text-slate-400 hidden sm:block">
              Regras Oficiais da Federação Brasileira de Damas
            </p>
          </div>
        </div>

        {/* Game Mode Selector Tabs */}
        <div className="hidden md:flex items-center bg-slate-950/80 p-1 rounded-xl border border-slate-800/80 shadow-inner">
          <button
            onClick={() => onSelectMode('ai')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all duration-200 ${
              gameMode === 'ai'
                ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 shadow-md shadow-amber-500/20 font-bold'
                : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <Bot className="w-4 h-4" />
            <span>Contra Robô IA</span>
          </button>

          <button
            onClick={() => onSelectMode('pvp')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all duration-200 ${
              gameMode === 'pvp'
                ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 shadow-md shadow-amber-500/20 font-bold'
                : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>2 Jogadores (PvP)</span>
          </button>

          <button
            onClick={() => onSelectMode('puzzle')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all duration-200 ${
              gameMode === 'puzzle'
                ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 shadow-md shadow-amber-500/20 font-bold'
                : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <Sparkles className="w-4 h-4" />
            <span>Desafios & Táticas</span>
          </button>
        </div>

        {/* Quick Action Buttons */}
        <div className="flex items-center gap-2">
          {/* Sound Toggle */}
          <button
            onClick={() => onUpdateSettings({ soundEnabled: !settings.soundEnabled })}
            title={settings.soundEnabled ? 'Desativar Som' : 'Ativar Som'}
            className={`p-2 rounded-xl border transition-all ${
              settings.soundEnabled
                ? 'bg-slate-800/80 border-slate-700 text-amber-400 hover:bg-slate-800'
                : 'bg-slate-900 border-slate-800 text-slate-500 hover:text-slate-300'
            }`}
          >
            {settings.soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>

          {/* Rules Guide Button */}
          <button
            onClick={onOpenRules}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-800/80 hover:bg-slate-800 border border-slate-700/80 text-slate-200 text-xs font-medium transition-all shadow-sm"
          >
            <BookOpen className="w-4 h-4 text-amber-400" />
            <span className="hidden sm:inline">Regras FBD</span>
          </button>

          {/* Settings Button */}
          <button
            onClick={onOpenSettings}
            title="Configurações e Temas"
            className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-800 border border-slate-700/80 text-slate-200 transition-all shadow-sm"
          >
            <Settings className="w-4 h-4 text-slate-300" />
          </button>
        </div>
      </div>

      {/* Mobile Mode Selector Bottom Strip */}
      <div className="md:hidden flex items-center justify-around border-t border-slate-800/80 bg-slate-950/90 px-2 py-1.5">
        <button
          onClick={() => onSelectMode('ai')}
          className={`flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-medium ${
            gameMode === 'ai'
              ? 'bg-amber-500 text-slate-950 font-bold shadow'
              : 'text-slate-400'
          }`}
        >
          <Bot className="w-3.5 h-3.5" />
          <span>Robô IA</span>
        </button>

        <button
          onClick={() => onSelectMode('pvp')}
          className={`flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-medium ${
            gameMode === 'pvp'
              ? 'bg-amber-500 text-slate-950 font-bold shadow'
              : 'text-slate-400'
          }`}
        >
          <Users className="w-3.5 h-3.5" />
          <span>2 Jogadores</span>
        </button>

        <button
          onClick={() => onSelectMode('puzzle')}
          className={`flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-medium ${
            gameMode === 'puzzle'
              ? 'bg-amber-500 text-slate-950 font-bold shadow'
              : 'text-slate-400'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>Desafios</span>
        </button>
      </div>
    </header>
  );
};
