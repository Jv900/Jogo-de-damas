import React from 'react';
import { X, BookOpen, ShieldAlert, Zap, Crown, CheckCircle2, Award, Info } from 'lucide-react';

interface RulesModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const RulesModal: React.FC<RulesModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl max-w-3xl w-full max-h-[90vh] flex flex-col overflow-hidden">
        
        {/* Modal Header */}
        <div className="px-6 py-4.5 bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center">
              <BookOpen className="w-5 h-5 text-amber-400" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white font-serif-title flex items-center gap-2">
                Regras Oficiais da FBD
                <span className="text-xs px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-sans font-bold">
                  Damas 64
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Federação Brasileira de Damas — Livro de Regras e Disciplina
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-750 text-slate-400 hover:text-white transition-all border border-slate-700/60"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body / Encyclopedia Scrollable Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6 text-sm text-slate-300 leading-relaxed">
          
          {/* Section 1: Tabuleiro e Posição Inicial */}
          <section className="space-y-2 bg-slate-950/60 p-4 rounded-2xl border border-slate-800/60">
            <h3 className="text-base font-bold text-amber-400 flex items-center gap-2">
              <Award className="w-4 h-4 text-amber-400" />
              1. O Tabuleiro e Posição Inicial
            </h3>
            <p>
              O jogo de Damas Brasileiras (ou Damas 64) é praticado sobre um tabuleiro quadrado dividido em 64 casas iguais, alternadamente claras e escuras (8 linhas por 8 colunas).
            </p>
            <ul className="list-disc list-inside space-y-1 text-xs text-slate-300 ml-2">
              <li><strong>Casas Ativas:</strong> O jogo desenrola-se <span className="text-amber-300 font-semibold">exclusivamente nas 32 casas escuras</span>. A casa escura do canto inferior esquerdo deve ficar sempre à esquerda de cada jogador.</li>
              <li><strong>Peças:</strong> Cada jogador começa com 12 peças (pedras) dispostas nas 3 primeiras fileiras da sua defesa, restando as 2 fileiras centrais livres para os confrontos iniciais. O condutor das peças claras (Brancas) tem o direito de fazer o primeiro movimento da partida.</li>
            </ul>
          </section>

          {/* Section 2: Movimentação das Pedras Comuns */}
          <section className="space-y-2 bg-slate-950/60 p-4 rounded-2xl border border-slate-800/60">
            <h3 className="text-base font-bold text-emerald-400 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              2. Movimentação da Pedra Comum
            </h3>
            <p>
              A pedra move-se apenas na diagonal, <strong className="text-white">uma casa para a frente</strong> por turno, sempre para uma casa escura vazia adjacente.
            </p>
            <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-xs text-amber-200">
              <strong className="font-bold flex items-center gap-1 mb-1">
                <Info className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                Atenção à Captura para Trás:
              </strong>
              Diferentemente de algumas variantes estrangeiras (como o Checkers Americano), em Damas Brasileiras a pedra comum <strong>PODE E DEVE CAPTURAR PARA TRÁS</strong>!
            </div>
          </section>

          {/* Section 3: Captura Obrigatória e a Lei da Maioria */}
          <section className="space-y-2 bg-slate-950/60 p-4 rounded-2xl border border-rose-500/30">
            <h3 className="text-base font-bold text-rose-400 flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-rose-400" />
              3. Captura Obrigatória e a "Lei da Maioria"
            </h3>
            <p>
              Em torneios oficiais, a tomada de peças adversárias é sempre <strong className="text-rose-300 font-extrabold underline">OBRIGATÓRIA</strong>. Quando um jogador tem a oportunidade de capturar uma ou mais peças, ele não é livre para mover outra peça.
            </p>
            <ul className="list-disc list-inside space-y-1.5 text-xs text-slate-300 ml-2">
              <li>
                <strong className="text-white">Lei da Maioria:</strong> Se houver duas ou mais opções de captura no tabuleiro, o jogador é <strong>obrigado a escolher o caminho que tome a MAIOR quantidade possível de peças</strong>. Por exemplo: se puder tomar 2 peças de um lado ou 3 peças de outro, é imperativo capturar as 3 peças!
              </li>
              <li>
                A pedra ou Dama não tem prioridade entre si quanto à obrigação de capturar — o critério absoluto é o número máximo de peças capturadas.
              </li>
            </ul>
          </section>

          {/* Section 4: Captura Múltipla e Remoção no Final */}
          <section className="space-y-2 bg-slate-950/60 p-4 rounded-2xl border border-slate-800/60">
            <h3 className="text-base font-bold text-amber-400 flex items-center gap-2">
              <Zap className="w-4 h-4 text-amber-400" />
              4. Captura Múltipla e Remoção das Peças
            </h3>
            <p>
              Se, após capturar uma peça, a pedra ou Dama atingir uma casa a partir da qual possa capturar outra peça adversária, a jogada continua automaticamente no mesmo turno (<strong className="text-amber-300">Captura em Cadeia</strong>).
            </p>
            <ul className="list-disc list-inside space-y-1.5 text-xs text-slate-300 ml-2">
              <li>
                <strong className="text-white">Remoção no Final ("Pega e tira no final"):</strong> As peças saltadas durante uma captura múltipla permanecem no tabuleiro até a conclusão de todo o movimento. Ou seja, você não pode saltar duas vezes sobre a mesma peça já capturada!
              </li>
              <li>
                No entanto, é permitido passar mais de uma vez pela mesma casa vazia durante a trajetória do lance.
              </li>
            </ul>
          </section>

          {/* Section 5: A Coroação e Passagem sem Parar */}
          <section className="space-y-2 bg-slate-950/60 p-4 rounded-2xl border border-amber-500/30">
            <h3 className="text-base font-bold text-amber-300 flex items-center gap-2">
              <Crown className="w-4 h-4 text-amber-400 fill-amber-400" />
              5. A Dama Voadora e a Coroação
            </h3>
            <p>
              Quando uma pedra atinge a oitava fileira (a linha mais distante de sua defesa) como <strong>destino final de seu turno</strong>, ela é coroada <strong className="text-amber-300">Dama</strong> imediatamente, recebendo poderes amplificados.
            </p>
            <ul className="list-disc list-inside space-y-1.5 text-xs text-slate-300 ml-2">
              <li>
                <strong className="text-rose-300">Passagem pela Coroação sem Parar:</strong> Se uma pedra, durante uma captura múltipla, passa pela casa de coroação sem parar (pois ainda há outra peça para ser tomada na sequência), <strong>ela NÃO é coroada Dama</strong> e deve continuar capturando como uma pedra comum!
              </li>
              <li>
                <strong className="text-white">Poder da Dama Voadora:</strong> A Dama pode mover-se quantas casas vazias quiser na diagonal, tanto para a frente quanto para trás. Para capturar, ela pode saltar uma peça distante desde que a linha esteja livre até a peça e haja pelo menos uma casa vazia após ela.
              </li>
            </ul>
          </section>

          {/* Section 6: Vitória e Empates */}
          <section className="space-y-2 bg-slate-950/60 p-4 rounded-2xl border border-slate-800/60">
            <h3 className="text-base font-bold text-indigo-400 flex items-center gap-2">
              <Award className="w-4 h-4 text-indigo-400" />
              6. Condições de Vitória e Empate
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="p-3 bg-slate-900/80 rounded-xl border border-slate-800">
                <strong className="text-emerald-400 block mb-1">Como Vencer:</strong>
                Capturar todas as peças adversárias ou deixá-las completamente bloqueadas ("Afogamento / Bloqueio Total"), impossibilitando qualquer movimento legal no turno de jogo do oponente.
              </div>
              <div className="p-3 bg-slate-900/80 rounded-xl border border-slate-800">
                <strong className="text-amber-400 block mb-1">Casos de Empate:</strong>
                • <strong>Repetição de Posição:</strong> Se a mesma posição repetir 3 vezes com o mesmo jogador a jogar. <br/>
                • <strong>Regra dos 20 Lances:</strong> 20 lances sucessivos de cada lado com apenas Damas em jogo sem captura nem movimento de pedra.
              </div>
            </div>
          </section>
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-4 bg-slate-950 border-t border-slate-800 flex items-center justify-between">
          <span className="text-xs text-slate-400">
            Sistema em conformidade 100% com o Regulamento Oficial da FBD
          </span>
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs transition-all shadow-md shadow-amber-500/20"
          >
            Entendido, Vamos Jogar!
          </button>
        </div>
      </div>
    </div>
  );
};
