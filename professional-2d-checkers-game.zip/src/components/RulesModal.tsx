import { useState } from "react";
import { X, BookOpen, Award, RotateCcw, AlertCircle } from "lucide-react";

interface RulesModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function RulesModal({ isOpen, onClose }: RulesModalProps) {
  const [activeTab, setActiveTab] = useState<"geral" | "movimento" | "captura" | "empate">("geral");

  if (!isOpen) return null;

  const tabs = [
    { id: "geral", label: "Regras Gerais", icon: BookOpen },
    { id: "movimento", label: "Movimentação", icon: Award },
    { id: "captura", label: "Captura Obrigatória", icon: AlertCircle },
    { id: "empate", label: "Empates", icon: RotateCcw },
  ] as const;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/65 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-700/50 rounded-2xl shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-800 bg-slate-950/60">
          <div className="flex items-center gap-3">
            <span className="p-2 rounded-lg bg-amber-500/10 text-amber-500">
              <BookOpen className="w-5 h-5" />
            </span>
            <h2 className="text-xl font-bold text-white tracking-wide">
              Regras Oficiais — Damas Profissional
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-slate-800 bg-slate-950/20 overflow-x-auto scrollbar-thin">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-5 py-3 text-sm font-medium whitespace-nowrap border-b-2 transition-all ${
                  isActive
                    ? "border-amber-500 text-amber-400 bg-amber-500/5"
                    : "border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-800/30"
                }`}
              >
                <Icon className="w-4 h-4" />
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto flex-1 text-slate-300 text-sm leading-relaxed space-y-4">
          {activeTab === "geral" && (
            <div className="space-y-4 animate-fade-in">
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                <p className="font-semibold text-white mb-2 text-base">O Tabuleiro e as Peças</p>
                <ul className="list-disc pl-5 space-y-2">
                  <li>O jogo é praticado em um tabuleiro de <strong className="text-amber-400">8x8 casas (64 casas)</strong> alternadas claras e escuras.</li>
                  <li>As peças jogam <strong className="text-amber-400">exclusivamente nas casas escuras</strong>.</li>
                  <li>Cada jogador inicia com <strong className="text-amber-400">12 peças</strong> posicionadas nas três primeiras fileiras escuras de seu lado.</li>
                  <li>A grande diagonal escura (diagonal principal) corre de baixo-esquerda para cima-direita do jogador das peças Brancas. O canto inferior direito do tabuleiro deve ser uma <strong className="text-amber-400">casa clara</strong>.</li>
                </ul>
              </div>

              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                <p className="font-semibold text-white mb-2 text-base">Objetivo do Jogo</p>
                <p>
                  Capturar todas as peças do oponente <strong className="text-amber-400">OU</strong> bloquear totalmente todas as peças do adversário, deixando-o sem nenhum movimento válido no seu turno.
                </p>
              </div>
            </div>
          )}

          {activeTab === "movimento" && (
            <div className="space-y-4 animate-fade-in">
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                <p className="font-semibold text-white mb-2 text-base">Peça Comum (Pedra)</p>
                <ul className="list-disc pl-5 space-y-2">
                  <li>Move-se apenas <strong className="text-amber-400">uma casa diagonal para frente</strong> por turno (em direção ao lado do oponente).</li>
                  <li><span className="text-rose-400 font-semibold">Atenção:</span> Pedras normais <strong className="text-rose-400">não podem recuar</strong> em movimentos simples de caminhada.</li>
                  <li>Se uma pedra comum atinge a última fileira adversária (fileira de coroação), ela é promovida a <strong className="text-amber-400">Dama</strong> imediatamente.</li>
                </ul>
              </div>

              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                <p className="font-semibold text-white mb-2 text-base">Dama (A Rainha do Tabuleiro)</p>
                <ul className="list-disc pl-5 space-y-2">
                  <li>Tem movimentos amplos: <strong className="text-amber-400">pode mover-se quantas casas vazias quiser</strong> em qualquer uma das quatro direções diagonais (como o Bispo no xadrez).</li>
                  <li>Pode mover-se tanto para frente quanto para trás de forma livre.</li>
                </ul>
              </div>
            </div>
          )}

          {activeTab === "captura" && (
            <div className="space-y-4 animate-fade-in">
              <div className="p-4 rounded-xl bg-rose-500/5 border border-rose-500/20">
                <p className="font-bold text-rose-400 mb-2 text-base flex items-center gap-2">
                  <AlertCircle className="w-5 h-5" />
                  Captura Obrigatória ("Sopro" não existe!)
                </p>
                <p className="text-slate-300">
                  Sempre que houver possibilidade de capturar uma peça adversária, <strong className="text-white">a captura é estritamente OBRIGATÓRIA</strong>. O jogador não pode optar por fazer um movimento simples se houver capturas no tabuleiro. A regra do "sopro" (eliminar a peça por não capturar) é antiga e NÃO existe nas regras oficiais modernas.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                <p className="font-semibold text-white mb-2 text-base">Como Funciona a Captura</p>
                <ul className="list-disc pl-5 space-y-2">
                  <li><strong className="text-amber-400">Pedra Comum:</strong> Pode capturar peças adversárias saltando sobre elas tanto <strong className="text-amber-400">para frente quanto para trás</strong>, aterrissando na casa imediatamente posterior.</li>
                  <li><strong className="text-amber-400">Lei da Maioria:</strong> Se você tiver mais de um caminho de captura disponível, a regra oficial obriga a <strong className="text-amber-400">escolher a rota que capture o MAIOR número de peças</strong>. Se um caminho captura 3 peças e outro captura 2, você deve obrigatoriamente fazer o lance de 3 capturas, mesmo que isso mude a peça usada ou leve a uma posição vulnerável.</li>
                  <li><strong className="text-amber-400">Capturas Múltiplas:</strong> Se após a captura a sua peça estiver em posição de capturar outra peça inimiga, ela <strong className="text-amber-400">deve continuar saltando</strong> no mesmo turno.</li>
                  <li><strong className="text-amber-400">Peças Fantasmas:</strong> Durante uma captura múltipla, as peças capturadas <strong className="text-rose-400">permanecem no tabuleiro</strong> até o final do movimento completo e não podem ser puladas duas vezes. Elas agem como barreiras durante o turno e são retiradas do tabuleiro apenas quando o turno acaba.</li>
                  <li><strong className="text-amber-400">Captura com Dama:</strong> A Dama pode capturar à distância. Ela salta por cima de uma peça oponente que esteja distante (desde que a diagonal esteja livre) e pode aterrissar em <strong className="text-amber-400">qualquer casa vazia atrás da peça capturada</strong>, podendo mudar de direção para fazer mais capturas na sequência.</li>
                </ul>
              </div>
            </div>
          )}

          {activeTab === "empate" && (
            <div className="space-y-4 animate-fade-in">
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                <p className="font-semibold text-white mb-2 text-base">Condições de Empate Oficial</p>
                <ul className="list-disc pl-5 space-y-2">
                  <li><strong className="text-amber-400">Regra de 20 Lances:</strong> Se ambos os jogadores realizarem <strong className="text-amber-400">20 lances sucessivos apenas com Damas</strong>, sem efetuar nenhuma captura de peça e sem movimentar nenhuma pedra comum, o jogo é declarado empate.</li>
                  <li><strong className="text-amber-400">Repetição de Posição:</strong> Se a mesma exata posição das peças no tabuleiro ocorrer 3 vezes durante a partida, o jogo é empatado automaticamente.</li>
                  <li><strong className="text-amber-400">Finais Especiais:</strong> No final do jogo, se restar apenas 1 Dama contra 1 Dama, ou posições nas quais é impossível forçar a vitória, o empate é decretado.</li>
                </ul>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/80 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold transition-all shadow-lg shadow-amber-500/10 active:scale-95 text-sm"
          >
            Entendi, Vamos Jogar!
          </button>
        </div>
      </div>
    </div>
  );
}
