import React from 'react';
import { X, Palette, Bot, Clock, ShieldAlert, Sparkles, Sliders } from 'lucide-react';
import { AIDifficulty, BoardTheme, GameSettings, PieceStyle, TimerMode } from '../types/game';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: GameSettings;
  onUpdateSettings: (newSettings: Partial<GameSettings>) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
}) => {
  if (!isOpen) return null;

  const boardThemes: { id: BoardTheme; name: string; colors: string }[] = [
    { id: 'classic', name: 'Madeira Clássica', colors: 'from-[#5c3a21] to-[#e6c594]' },
    { id: 'emerald', name: 'Verde Torneio FBD', colors: 'from-[#0f5132] to-[#d1e7dd]' },
    { id: 'royal', name: 'Veludo Real', colors: 'from-[#311b92] to-[#ede7f6]' },
    { id: 'midnight', name: 'Obsidiana Noturna', colors: 'from-slate-800 to-slate-300' },
    { id: 'walnut', name: 'Estúdio Nogueira', colors: 'from-[#3d2314] to-[#c8a97e]' },
  ];

  const pieceStyles: { id: PieceStyle; name: string; preview: string }[] = [
    { id: 'classic_ivory_ebony', name: 'Marfim & Ébano', preview: 'bg-white vs bg-zinc-900' },
    { id: 'red_white', name: 'Vermelho & Branco', preview: 'bg-rose-600 vs bg-white' },
    { id: 'gold_obsidian', name: 'Ouro Imperial', preview: 'bg-amber-400 vs bg-black' },
  ];

  const aiLevels: { id: AIDifficulty; name: string; desc: string }[] = [
    { id: 'easy', name: 'Iniciante (Fácil)', desc: 'Erra jogadas simples e joga rápido.' },
    { id: 'medium', name: 'Intermediário (Médio)', desc: 'Estratégia básica e não erra capturas.' },
    { id: 'hard', name: 'Avançado (Difícil)', desc: 'Planeja 4-5 lances à frente com sacrifícios.' },
    { id: 'master', name: 'Mestre FBD', desc: 'Táticas de torneio oficial, profundidade máxima.' },
  ];

  const timerModes: { id: TimerMode; name: string; desc: string }[] = [
    { id: 'none', name: 'Sem Tempo', desc: 'Jogue no seu próprio ritmo' },
    { id: 'blitz_3m', name: 'Blitz (3 Minutos)', desc: 'Partida super rápida e emocionante' },
    { id: 'rapid_10m', name: 'Rápido (10 Minutos)', desc: 'Ideal para partidas casuais focado' },
    { id: 'classic_20m', name: 'Clássico (20 Minutos)', desc: 'Tempo oficial para reflexão profunda' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl max-w-2xl w-full max-h-[90vh] flex flex-col overflow-hidden">
        
        {/* Modal Header */}
        <div className="px-6 py-4.5 bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center">
              <Sliders className="w-5 h-5 text-amber-400" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white font-serif-title">
                Personalização & Regras
              </h2>
              <p className="text-xs text-slate-400">
                Ajuste temas visuais, nível do robô e controles de partida
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-750 text-slate-400 hover:text-white transition-all border border-slate-700/60"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          
          {/* Section 1: Visual Themes */}
          <div className="space-y-3">
            <h3 className="text-sm font-bold text-slate-200 flex items-center gap-2">
              <Palette className="w-4 h-4 text-amber-400" />
              <span>Estilo do Tabuleiro</span>
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
              {boardThemes.map(theme => (
                <button
                  key={theme.id}
                  onClick={() => onUpdateSettings({ boardTheme: theme.id })}
                  className={`p-3 rounded-2xl border text-left transition-all flex flex-col justify-between ${
                    settings.boardTheme === theme.id
                      ? 'bg-slate-800 border-amber-500 shadow-md shadow-amber-500/10 ring-2 ring-amber-500/20'
                      : 'bg-slate-950/60 border-slate-800/80 hover:bg-slate-900'
                  }`}
                >
                  <div className={`w-full h-8 rounded-lg bg-gradient-to-r ${theme.colors} mb-2 shadow-inner border border-black/20`} />
                  <span className="text-xs font-bold text-white">{theme.name}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Section 2: Piece Styles */}
          <div className="space-y-3">
            <h3 className="text-sm font-bold text-slate-200 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span>Conjunto de Peças</span>
            </h3>
            <div className="grid grid-cols-3 gap-2.5">
              {pieceStyles.map(style => (
                <button
                  key={style.id}
                  onClick={() => onUpdateSettings({ pieceStyle: style.id })}
                  className={`p-3 rounded-2xl border text-center transition-all ${
                    settings.pieceStyle === style.id
                      ? 'bg-slate-800 border-amber-500 shadow-md ring-2 ring-amber-500/20 font-bold text-white'
                      : 'bg-slate-950/60 border-slate-800/80 hover:bg-slate-900 text-slate-300'
                  }`}
                >
                  <span className="text-xs">{style.name}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Section 3: AI Difficulty */}
          <div className="space-y-3">
            <h3 className="text-sm font-bold text-slate-200 flex items-center gap-2">
              <Bot className="w-4 h-4 text-indigo-400" />
              <span>Inteligência do Robô IA</span>
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {aiLevels.map(lvl => (
                <button
                  key={lvl.id}
                  onClick={() => onUpdateSettings({ aiDifficulty: lvl.id })}
                  className={`p-3.5 rounded-2xl border text-left transition-all ${
                    settings.aiDifficulty === lvl.id
                      ? 'bg-indigo-950/40 border-indigo-500 shadow-md ring-2 ring-indigo-500/20'
                      : 'bg-slate-950/60 border-slate-800/80 hover:bg-slate-900'
                  }`}
                >
                  <span className="text-xs font-extrabold text-white block">{lvl.name}</span>
                  <span className="text-[11px] text-slate-400 mt-0.5 block leading-tight">{lvl.desc}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Section 4: Timer Modes */}
          <div className="space-y-3">
            <h3 className="text-sm font-bold text-slate-200 flex items-center gap-2">
              <Clock className="w-4 h-4 text-emerald-400" />
              <span>Relógio de Partida</span>
            </h3>
            <div className="grid grid-cols-2 gap-2.5">
              {timerModes.map(timer => (
                <button
                  key={timer.id}
                  onClick={() => onUpdateSettings({ timerMode: timer.id })}
                  className={`p-3 rounded-2xl border text-left transition-all ${
                    settings.timerMode === timer.id
                      ? 'bg-emerald-950/40 border-emerald-500 shadow-md ring-2 ring-emerald-500/20'
                      : 'bg-slate-950/60 border-slate-800/80 hover:bg-slate-900'
                  }`}
                >
                  <span className="text-xs font-extrabold text-white block">{timer.name}</span>
                  <span className="text-[11px] text-slate-400 mt-0.5 block">{timer.desc}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Section 5: Rules & Assistance Toggles */}
          <div className="space-y-3 pt-2 border-t border-slate-800/80">
            <h3 className="text-sm font-bold text-slate-200 flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-rose-400" />
              <span>Opções de Jogo & Assistência</span>
            </h3>
            <div className="space-y-2.5">
              
              {/* Majority Rule Toggle */}
              <label className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-950/60 border border-slate-800/80 cursor-pointer hover:bg-slate-900/80 transition-colors">
                <div>
                  <span className="text-xs font-bold text-white block">
                    Lei da Maioria (Captura Obrigatória Máxima)
                  </span>
                  <span className="text-[11px] text-slate-400">
                    Obrigatório optar sempre pela sequência com o maior número de peças tomadas
                  </span>
                </div>
                <input
                  type="checkbox"
                  checked={settings.enforceMajorityRule}
                  onChange={e => onUpdateSettings({ enforceMajorityRule: e.target.checked })}
                  className="w-5 h-5 rounded border-slate-700 text-amber-500 focus:ring-amber-500 cursor-pointer"
                />
              </label>

              {/* Show Valid Moves Toggle */}
              <label className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-950/60 border border-slate-800/80 cursor-pointer hover:bg-slate-900/80 transition-colors">
                <div>
                  <span className="text-xs font-bold text-white block">
                    Destacar Movimentos Válidos
                  </span>
                  <span className="text-[11px] text-slate-400">
                    Exibe marcações verdes/vermelhas nas casas de destino da peça selecionada
                  </span>
                </div>
                <input
                  type="checkbox"
                  checked={settings.showValidMoves}
                  onChange={e => onUpdateSettings({ showValidMoves: e.target.checked })}
                  className="w-5 h-5 rounded border-slate-700 text-amber-500 focus:ring-amber-500 cursor-pointer"
                />
              </label>

              {/* Fixed Board Orientation Info */}
              <div className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 text-xs text-slate-300">
                <div>
                  <span className="font-bold text-amber-400 block mb-0.5">
                    Orientação Fixa do Tabuleiro (Sem Inversão)
                  </span>
                  <span className="text-[11px] text-slate-400 leading-relaxed block">
                    Peças Brancas sempre na parte inferior (linhas 1, 2 e 3) e Pretas na parte superior (linhas 6, 7 e 8) em todos os turnos.
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-4 bg-slate-950 border-t border-slate-800 flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs transition-all shadow-md shadow-amber-500/20"
          >
            Salvar & Fechar
          </button>
        </div>
      </div>
    </div>
  );
};
