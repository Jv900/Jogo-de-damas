import React from 'react';
import { RotateCcw, Pause, Play, LogOut, Undo2, Lightbulb, Handshake } from 'lucide-react';
import { GameMode } from '../types/game';

interface ControlsProps {
  gameStatus: 'idle' | 'playing' | 'paused' | 'won' | 'draw';
  gameMode: GameMode;
  onRestart: () => void;
  onPauseToggle: () => void;
  onExit: () => void;
  onUndo: () => void;
  onHint: () => void;
  onOfferDraw: () => void;
  canUndo: boolean;
}

export const Controls: React.FC<ControlsProps> = ({
  gameStatus,
  gameMode,
  onRestart,
  onPauseToggle,
  onExit,
  onUndo,
  onHint,
  onOfferDraw,
  canUndo,
}) => {
  return (
    <div className="w-full flex flex-wrap items-center justify-between gap-2.5 p-3.5 sm:p-4 bg-slate-900/95 rounded-2xl border-2 border-slate-800 shadow-xl">
      {/* Primary Action Buttons */}
      <div className="flex items-center gap-2 flex-wrap">
        <button
          onClick={onRestart}
          className="flex items-center gap-2 px-3.5 sm:px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-750 border border-slate-700 text-slate-100 text-xs sm:text-sm font-bold transition-all shadow-sm hover:border-amber-400 min-h-[44px]"
          title="Reiniciar Partida Atual"
        >
          <RotateCcw className="w-4.5 h-4.5 text-amber-400 shrink-0" />
          <span>Reiniciar</span>
        </button>

        {gameStatus === 'playing' || gameStatus === 'paused' ? (
          <button
            onClick={onPauseToggle}
            className={`flex items-center gap-2 px-3.5 sm:px-4 py-2.5 rounded-xl border text-xs sm:text-sm font-bold transition-all shadow-sm min-h-[44px] ${
              gameStatus === 'paused'
                ? 'bg-amber-500 border-amber-300 text-slate-950 shadow-md shadow-amber-500/20'
                : 'bg-slate-800 hover:bg-slate-750 border-slate-700 text-slate-100'
            }`}
          >
            {gameStatus === 'paused' ? (
              <>
                <Play className="w-4.5 h-4.5 fill-slate-950 shrink-0" />
                <span>Continuar</span>
              </>
            ) : (
              <>
                <Pause className="w-4.5 h-4.5 text-amber-400 shrink-0" />
                <span>Pausar</span>
              </>
            )}
          </button>
        ) : null}

        <button
          onClick={onExit}
          className="flex items-center gap-2 px-3.5 sm:px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-rose-950/40 border border-slate-700 hover:border-rose-500/50 text-slate-300 hover:text-rose-200 text-xs sm:text-sm font-bold transition-all shadow-sm min-h-[44px]"
          title="Sair para a tela inicial"
        >
          <LogOut className="w-4.5 h-4.5 text-rose-400 shrink-0" />
          <span>Sair</span>
        </button>
      </div>

      {/* Secondary Strategic Buttons */}
      <div className="flex items-center gap-2 flex-wrap">
        {gameMode !== 'puzzle' && (
          <button
            onClick={onUndo}
            disabled={!canUndo}
            className={`flex items-center gap-2 px-3.5 sm:px-4 py-2.5 rounded-xl border text-xs sm:text-sm font-bold transition-all shadow-sm min-h-[44px] ${
              canUndo
                ? 'bg-slate-800 hover:bg-slate-750 border-slate-700 text-slate-100 hover:border-indigo-400'
                : 'bg-slate-950/80 border-slate-900 text-slate-600 cursor-not-allowed'
            }`}
            title="Desfazer Último Lance"
          >
            <Undo2 className="w-4.5 h-4.5 text-indigo-400 shrink-0" />
            <span>Desfazer</span>
          </button>
        )}

        <button
          onClick={onHint}
          className="flex items-center gap-2 px-3.5 sm:px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-amber-950/50 border border-slate-700 hover:border-amber-400 text-slate-100 hover:text-amber-300 text-xs sm:text-sm font-bold transition-all shadow-sm min-h-[44px]"
          title="Pedir Sugestão de Jogada para o Robô Mestre"
        >
          <Lightbulb className="w-4.5 h-4.5 text-amber-400 shrink-0" />
          <span>Dica IA</span>
        </button>

        {gameMode === 'pvp' && (
          <button
            onClick={onOfferDraw}
            className="flex items-center gap-2 px-3.5 sm:px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-750 border border-slate-700 text-slate-300 hover:text-white text-xs sm:text-sm font-bold transition-all shadow-sm min-h-[44px]"
            title="Propor Acordo de Empate entre os dois jogadores"
          >
            <Handshake className="w-4.5 h-4.5 text-emerald-400 shrink-0" />
            <span>Empate</span>
          </button>
        )}
      </div>
    </div>
  );
};
