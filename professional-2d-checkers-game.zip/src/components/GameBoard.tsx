import { Crown, Skull } from "lucide-react";
import {
  Board,
  Player,
  Position,
  Move,
  MoveStep,
} from "../utils/checkersRules";

interface GameBoardProps {
  board: Board;
  turn: Player;
  selectedPiece: Position | null;
  validMoves: Move[];
  currentSteps: MoveStep[];
  ghosts: Set<string>;
  lastMove: Move | null;
  theme: "wood" | "green" | "slate" | "cyber";
  showSuggestions: boolean;
  onCellClick: (row: number, col: number) => void;
  isAiThinking: boolean;
  paused: boolean;
  gameEnded: boolean;
}

export default function GameBoard({
  board,
  selectedPiece,
  validMoves,
  currentSteps,
  ghosts,
  lastMove,
  theme,
  showSuggestions,
  onCellClick,
  isAiThinking,
  paused,
  gameEnded,
}: GameBoardProps) {
  // Theme styling configurations
  const themeStyles = {
    wood: {
      border: "bg-amber-950 border-amber-900 text-amber-100 board-border-wood",
      lightCell: "bg-[#f4ebd0]",
      darkCell: "bg-[#6b4226]",
      labelColor: "text-amber-200/70",
      activeRing: "ring-amber-400 shadow-[0_0_15px_#f59e0b]",
      suggestDot: "bg-amber-400/80 shadow-[0_0_8px_#f59e0b]",
    },
    green: {
      border: "bg-emerald-950 border-emerald-900 text-emerald-100 board-border-wood",
      lightCell: "bg-[#efebe4]",
      darkCell: "bg-[#1f563d]",
      labelColor: "text-emerald-200/70",
      activeRing: "ring-yellow-400 shadow-[0_0_15px_#facc15]",
      suggestDot: "bg-yellow-400/80 shadow-[0_0_8px_#facc15]",
    },
    slate: {
      border: "bg-slate-900 border-slate-800 text-slate-100 board-border-wood",
      lightCell: "bg-slate-200",
      darkCell: "bg-slate-750 bg-[#1e293b]",
      labelColor: "text-slate-400",
      activeRing: "ring-sky-400 shadow-[0_0_15px_#38bdf8]",
      suggestDot: "bg-sky-400/80 shadow-[0_0_8px_#38bdf8]",
    },
    cyber: {
      border: "bg-zinc-950 border-purple-900 text-purple-200 shadow-[0_0_20px_rgba(168,85,247,0.3)]",
      lightCell: "bg-zinc-850 bg-[#27272a]",
      darkCell: "bg-[#18002d]",
      labelColor: "text-purple-400",
      activeRing: "ring-fuchsia-500 shadow-[0_0_15px_#d946ef]",
      suggestDot: "bg-fuchsia-500/80 shadow-[0_0_8px_#d946ef]",
    },
  };

  const style = themeStyles[theme];

  // Letters and numbers for coordinates
  const columns = ["A", "B", "C", "D", "E", "F", "G", "H"];
  const rows = ["8", "7", "6", "5", "4", "3", "2", "1"];

  // Helper to determine if a cell is highlighted as a valid destination
  const getSuggestedDestinations = (): Set<string> => {
    if (!selectedPiece || !showSuggestions || paused || gameEnded || isAiThinking) {
      return new Set();
    }

    const destinations = new Set<string>();

    if (currentSteps.length === 0) {
      // Find normal moves or first-step capture moves starting from selectedPiece
      const pieceMoves = validMoves.filter(
        (m) => m.start.row === selectedPiece.row && m.start.col === selectedPiece.col
      );

      for (const move of pieceMoves) {
        if (move.isCapture && move.steps.length > 0) {
          const step = move.steps[0];
          destinations.add(`${step.to.row},${step.to.col}`);
        } else {
          destinations.add(`${move.end.row},${move.end.col}`);
        }
      }
    } else {
      // We are in the middle of a multiple capture
      // Show only the next step of matching paths
      const matchingMoves = validMoves.filter((move) => {
        if (move.steps.length <= currentSteps.length) return false;
        for (let i = 0; i < currentSteps.length; i++) {
          const s1 = move.steps[i];
          const s2 = currentSteps[i];
          if (
            s1.from.row !== s2.from.row ||
            s1.from.col !== s2.from.col ||
            s1.to.row !== s2.to.row ||
            s1.to.col !== s2.to.col
          ) {
            return false;
          }
        }
        return true;
      });

      for (const move of matchingMoves) {
        const nextStep = move.steps[currentSteps.length];
        destinations.add(`${nextStep.to.row},${nextStep.to.col}`);
      }
    }

    return destinations;
  };

  const suggestedDests = getSuggestedDestinations();

  // Helper to check if a cell was the start or end of the last move
  const isLastMoveCell = (r: number, c: number): boolean => {
    if (!lastMove) return false;
    return (
      (lastMove.start.row === r && lastMove.start.col === c) ||
      (lastMove.end.row === r && lastMove.end.col === c)
    );
  };

  return (
    <div className="relative w-full aspect-square max-w-[560px] mx-auto">
      {/* Outer elegant wooden frame */}
      <div className={`w-full h-full rounded-2xl p-4 md:p-6 ${style.border} flex flex-col justify-between transition-all duration-300 relative`}>
        {/* Coordinates - Top Letters */}
        <div className="flex justify-between px-4 md:px-6 py-1">
          <div className="w-4 md:w-6"></div> {/* corner spacer */}
          {columns.map((letter) => (
            <div
              key={`col-top-${letter}`}
              className={`w-full text-center text-xs md:text-sm font-bold tracking-wider select-none ${style.labelColor}`}
            >
              {letter}
            </div>
          ))}
          <div className="w-4 md:w-6"></div> {/* corner spacer */}
        </div>

        {/* Board Main Area (Left numbers + Board + Right numbers) */}
        <div className="flex flex-1 items-stretch">
          {/* Left Side Numbers */}
          <div className="flex flex-col justify-between py-1 pr-1.5 md:pr-3 text-right">
            {rows.map((num) => (
              <div
                key={`row-left-${num}`}
                className={`h-full flex items-center justify-end text-xs md:text-sm font-bold select-none ${style.labelColor}`}
                style={{ minWidth: "12px" }}
              >
                {num}
              </div>
            ))}
          </div>

          {/* Actual 8x8 Chessboard */}
          <div className="flex-1 grid grid-cols-8 grid-rows-8 border border-black/40 shadow-inner rounded-md overflow-hidden relative bg-black/5">
            {Array(8)
              .fill(null)
              .map((_, rowIndex) => {
                return Array(8)
                  .fill(null)
                  .map((_, colIndex) => {
                    const isDarkCell = (rowIndex + colIndex) % 2 === 1;
                    const piece = board[rowIndex][colIndex];
                    const isSelected =
                      selectedPiece?.row === rowIndex &&
                      selectedPiece?.col === colIndex;

                    const isGhost = ghosts.has(`${rowIndex},${colIndex}`);
                    const isLastMoved = isLastMoveCell(rowIndex, colIndex);
                    const isSuggested = suggestedDests.has(`${rowIndex},${colIndex}`);

                    return (
                      <div
                        key={`cell-${rowIndex}-${colIndex}`}
                        onClick={() => onCellClick(rowIndex, colIndex)}
                        className={`relative aspect-square flex items-center justify-center cursor-pointer transition-all duration-150 select-none ${
                          isDarkCell ? style.darkCell : style.lightCell
                        } ${isLastMoved ? "ring-2 ring-amber-400/40 bg-amber-400/10" : ""}`}
                      >
                        {/* Hover Overlay */}
                        {isDarkCell && !paused && !gameEnded && !isAiThinking && (
                          <div className="absolute inset-0 bg-white/0 hover:bg-white/5 transition-colors duration-150" />
                        )}

                        {/* Suggestion Indicator */}
                        {isSuggested && (
                          <div className="absolute z-10 flex items-center justify-center w-full h-full">
                            {piece ? (
                              // Jump Capture Indicator (pulsing red border around target)
                              <div className="w-[85%] h-[85%] rounded-full border-4 border-rose-500/80 animate-pulse-glow" />
                            ) : (
                              // Empty Land Guide (green/amber dot)
                              <div className={`w-3.5 h-3.5 md:w-5 md:h-5 rounded-full ${style.suggestDot} scale-95 hover:scale-110 transition-transform duration-100`} />
                            )}
                          </div>
                        )}

                        {/* Piece Design */}
                        {piece && (
                          <div
                            className={`relative w-[80%] h-[80%] rounded-full transition-all duration-300 flex items-center justify-center ${
                              isGhost ? "opacity-35 scale-90" : "hover:scale-105 active:scale-95"
                            } ${
                              piece.player === 1
                                ? "bg-gradient-to-br from-slate-50 via-neutral-100 to-slate-300 text-slate-800 shadow-piece-white"
                                : "bg-gradient-to-br from-neutral-850 via-zinc-800 to-neutral-950 text-slate-200 shadow-piece-black"
                            } ${isSelected ? style.activeRing : ""}`}
                          >
                            {/* Inner circle for nice professional aesthetic */}
                            <div
                              className={`absolute w-[76%] h-[76%] rounded-full border border-black/5 flex items-center justify-center ${
                                piece.player === 1
                                  ? "bg-gradient-to-tr from-slate-200/50 to-white/70"
                                  : "bg-gradient-to-tr from-zinc-900/30 to-zinc-700/40"
                              }`}
                            >
                              {/* Even more inner design lines for checker feel */}
                              <div className="w-[70%] h-[70%] rounded-full border border-dashed border-black/10 flex items-center justify-center">
                                {/* Dama (Queen) Crown */}
                                {piece.isQueen ? (
                                  <div className="animate-crown-float flex flex-col items-center">
                                    <Crown className="w-5 h-5 md:w-7 md:h-7 text-amber-500 fill-amber-400 drop-shadow-[0_2px_4px_rgba(0,0,0,0.4)]" />
                                  </div>
                                ) : (
                                  // Normal check-lines
                                  <div className={`w-[50%] h-[50%] rounded-full border-2 ${piece.player === 1 ? "border-slate-300" : "border-zinc-700"}`} />
                                )}
                              </div>
                            </div>

                            {/* Skull overlay for multi-capture ghosts */}
                            {isGhost && (
                              <div className="absolute inset-0 bg-rose-900/40 rounded-full flex items-center justify-center border-2 border-rose-600 animate-pulse">
                                <Skull className="w-5 h-5 md:w-6 md:h-6 text-rose-200 filter drop-shadow" />
                              </div>
                            )}

                            {/* Decorative shiny glare */}
                            {!isGhost && (
                              <div className="absolute top-1 left-2 w-3 h-1.5 bg-white/40 rounded-full rotate-[-15deg] blur-[0.5px]" />
                            )}
                          </div>
                        )}
                      </div>
                    );
                  });
              })}



            {/* Paused Overlay */}
            {paused && !gameEnded && (
              <div className="absolute inset-0 z-20 flex flex-col items-center justify-center bg-slate-950/80 transition-all">
                <span className="text-xl md:text-2xl font-black text-amber-500 mb-2 tracking-widest uppercase">
                  Jogo Pausado
                </span>
                <span className="text-slate-300 text-xs md:text-sm max-w-xs text-center px-4">
                  Clique no botão "Retomar" no painel de controle para continuar a partida.
                </span>
              </div>
            )}
          </div>

          {/* Right Side Numbers */}
          <div className="flex flex-col justify-between py-1 pl-1.5 md:pl-3 text-left">
            {rows.map((num) => (
              <div
                key={`row-right-${num}`}
                className={`h-full flex items-center justify-start text-xs md:text-sm font-bold select-none ${style.labelColor}`}
                style={{ minWidth: "12px" }}
              >
                {num}
              </div>
            ))}
          </div>
        </div>

        {/* Coordinates - Bottom Letters */}
        <div className="flex justify-between px-4 md:px-6 py-1">
          <div className="w-4 md:w-6"></div> {/* corner spacer */}
          {columns.map((letter) => (
            <div
              key={`col-bottom-${letter}`}
              className={`w-full text-center text-xs md:text-sm font-bold tracking-wider select-none ${style.labelColor}`}
            >
              {letter}
            </div>
          ))}
          <div className="w-4 md:w-6"></div> {/* corner spacer */}
        </div>
      </div>
    </div>
  );
}
