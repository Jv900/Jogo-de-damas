export type PlayerColor = 'white' | 'black';
export type PieceType = 'pedra' | 'dama';

export interface Position {
  row: number;
  col: number;
}

export interface BoardPiece {
  id: string;
  color: PlayerColor;
  type: PieceType;
  row: number;
  col: number;
}

export interface MoveOption {
  from: Position;
  to: Position;
  path: Position[]; // [from, step1, step2, ... to]
  capturedPositions: Position[]; // positions of all jumped pieces
  isCapture: boolean;
  captureCount: number;
  promoted: boolean; // if piece becomes Dama at the end of this sequence
}

export type GameMode = 'ai' | 'pvp' | 'puzzle';
export type AIDifficulty = 'easy' | 'medium' | 'hard' | 'master';
export type BoardTheme = 'classic' | 'emerald' | 'royal' | 'midnight' | 'walnut';
export type PieceStyle = 'classic_ivory_ebony' | 'red_white' | 'gold_obsidian';
export type TimerMode = 'none' | 'blitz_3m' | 'rapid_10m' | 'classic_20m';

export interface HistoryEntry {
  id: string;
  turnNumber: number;
  color: PlayerColor;
  from: Position;
  to: Position;
  notation: string; // e.g. c3-d4 or e3xg5xc1
  capturedCount: number;
  wasKing: boolean;
  promoted: boolean;
  boardSnapshot: (BoardPiece | null)[][];
}

export interface GameSettings {
  enforceMajorityRule: boolean; // Lei da Maioria (Obrigatório capturar maior nº de peças)
  showValidMoves: boolean;
  soundEnabled: boolean;
  aiDifficulty: AIDifficulty;
  aiPlayerColor: PlayerColor; // normally black when playing against AI
  boardTheme: BoardTheme;
  pieceStyle: PieceStyle;
  timerMode: TimerMode;
  autoFlipBoard: boolean; // flip board for player 2 in PvP
}

export interface PuzzleChallenge {
  id: string;
  title: string;
  description: string;
  difficulty: 'Iniciante' | 'Intermediário' | 'Avançado' | 'Oficial';
  ruleHighlight: string;
  initialTurn: PlayerColor;
  boardSetup: (BoardPiece | null)[][];
  objective: string; // e.g. "Ganhe em 3 lances aplicando a Lei da Maioria"
  expectedSolutionMoves?: string[]; // notation steps
}
